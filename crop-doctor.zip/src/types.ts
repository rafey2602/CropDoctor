export type AppScreen =
  | 'landing'
  | 'splash'
  | 'onboarding'
  | 'language'
  | 'language-select'
  | 'profile'
  | 'farmer-profile'
  | 'dashboard'
  | 'scan'
  | 'quality-check'
  | 'analysis-loading'
  | 'loading'
  | 'result'
  | 'differential'
  | 'severity'
  | 'explainable-ai'
  | 'progression'
  | 'weather'
  | 'actions'
  | 'treatment'
  | 'timeline'
  | 'history'
  | 'field-map'
  | 'alerts'
  | 'assistant'
  | 'voice'
  | 'expert-verification'
  | 'report'
  | 'settings'
  | 'offline'
  | 'unknown-condition'
  | 'low-confidence';

export type SupportedLanguage =
  | 'en'
  | 'hi'
  | 'mr'
  | 'ur'
  | 'gu'
  | 'ta'
  | 'te'
  | 'kn'
  | 'bn';

export interface LanguageOption {
  code: SupportedLanguage;
  name: string;
  nativeName: string;
  subtext: string;
}

export interface FarmerProfile {
  name: string;
  location: string;
  state: string;
  preferredLanguage: SupportedLanguage;
  crop: string;
  cropVariety: string;
  fieldSize: string; // e.g. "4.5 Acres"
  sowingDate: string; // e.g. "June 12"
  cropAgeDays: number;
  growthStage: string; // e.g. "Flowering & Boll formation"
  irrigationType: 'Drip' | 'Flood' | 'Sprinkler' | 'Rainfed';
  soilType: string;
}

export interface WeatherData {
  temperature: number; // in Celsius
  humidity: number; // in %
  rainfall: string; // "12 mm (Last 24h)"
  rainForecast: string; // "Showers expected in 36 hrs"
  windSpeed: string; // "11 km/h NW"
  leafWetnessDuration: string; // "9.5 hours/day"
  fungalGrowthRisk: 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';
  diseaseFavorabilityScore: number; // 0-100
}

export interface QualityAssessment {
  score: number;
  isBlurAcceptable: boolean;
  isLightingGood: boolean;
  isLeafCentered: boolean;
  isDiseaseRegionVisible: boolean;
  isBackgroundClean: boolean;
  feedbackTitle: string;
  feedbackNote: string;
  issues: string[];
}

export interface DifferentialItem {
  condition: string;
  type: 'fungal' | 'bacterial' | 'nutrient' | 'pest' | 'water' | 'other';
  probability: number; // 0 - 100
  color: string;
  keyIndicators: string[];
}

export interface ProgressionStep {
  timeframe: string; // "Today", "48 Hours", "3-5 Days"
  riskLevel: 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';
  riskPercent: number;
  visualNote: string;
  leafImpactArea: number; // %
  description: string;
}

export interface PrioritizedAction {
  id: string;
  level: 1 | 2 | 3 | 4;
  urgencyLabel: 'DO NOW' | 'WITHIN 24 HOURS' | 'MONITOR' | 'IF SYMPTOMS SPREAD';
  urgencyBadge: string;
  title: string;
  description: string;
  impact: string;
  category: 'cultural' | 'ventilation' | 'biological' | 'scouting' | 'expert';
  isCompleted?: boolean;
}

export interface TreatmentCategory {
  type: 'chemical' | 'organic' | 'prevention';
  title: string;
  subtitle: string;
  options: {
    name: string;
    purpose: string;
    dosageNote: string;
    applicationGuidance: string;
    precautions: string[];
    environmentalNote: string;
    efficacyRating: number; // 1-5
  }[];
}

export interface ScanRecord {
  id: string;
  date: string;
  timestamp: number;
  crop: string;
  cropStage: string;
  imageUrl: string;
  leafType: string;
  healthScore: number; // 0 - 100
  healthStatus: 'Excellent' | 'Mild Stress' | 'Moderate Stress' | 'Severe Risk' | 'Unknown';
  primaryFinding: string;
  findingType: 'Fungal' | 'Bacterial' | 'Nutrient' | 'Environmental' | 'Unknown';
  confidence: number; // 0 - 100
  severityPercent: number; // 0 - 100
  severityLevel: 'HEALTHY' | 'EARLY' | 'MODERATE' | 'SEVERE';
  progressionRiskPercent: number;
  affectedAreaEstimate: string;
  weatherRisk: 'LOW' | 'MODERATE' | 'HIGH';
  isUnknownCondition?: boolean;
  isLowConfidence?: boolean;
  summaryMessage: string;
}

export interface FieldZone {
  id: string;
  name: string;
  area: string;
  cropStage?: string;
  healthScore: number;
  status: 'HEALTHY' | 'EARLY_STRESS' | 'HIGH_RISK' | 'healthy' | 'moderate' | 'high-risk';
  coordinates?: { x: number; y: number; width: number; height: number };
  detectedCondition?: string;
  notes?: string;
  lastScanned: string;
}

export interface EarlyWarningAlert {
  id: string;
  title: string;
  severity: 'high' | 'moderate' | 'info';
  time: string;
  description: string;
  recommendedAction: string;
  isRead?: boolean;
}

export interface AppAlert {
  id: string;
  priority: 'HIGH' | 'WEATHER' | 'MONITOR' | 'INFO';
  title: string;
  timeAgo: string;
  description: string;
  metricBadge?: string;
  ctaText: string;
  actionScreen: AppScreen;
  isRead?: boolean;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant' | 'ai';
  text: string;
  timestamp: string;
  suggestedAction?: {
    label: string;
    screen: AppScreen;
  };
  audioAvailable?: boolean;
}
