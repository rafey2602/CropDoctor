import {
  FarmerProfile,
  WeatherData,
  ScanRecord,
  QualityAssessment,
  DifferentialItem,
  ProgressionStep,
  PrioritizedAction,
  TreatmentCategory,
  FieldZone,
  AppAlert,
  LanguageOption
} from '../types';

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  { code: 'en', name: 'English', nativeName: 'English', subtext: 'Default international' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', subtext: 'भारत की प्रमुख भाषा' },
  { code: 'mr', name: 'Marathi', nativeName: 'मराठी', subtext: 'महाराष्ट्राची राज्यभाषा' },
  { code: 'gu', name: 'Gujarati', nativeName: 'ગુજરાતી', subtext: 'ગુજરાત રાજ્ય' },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు', subtext: 'ఆంధ్ర & తెలంగాణ' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்', subtext: 'தமிழ்நாடு' },
  { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ', subtext: 'ಕರ್ನಾಟಕ' },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা', subtext: 'পশ্চিমবঙ্গ' },
  { code: 'ur', name: 'Urdu', nativeName: 'اردو', subtext: 'قومی و علاقائی زبان' },
];

export const INITIAL_FARMER_PROFILE: FarmerProfile = {
  name: 'Rahul Patil',
  location: 'Panvel, Raigad',
  state: 'Maharashtra',
  preferredLanguage: 'en',
  crop: 'Cotton (BT Cotton-II)',
  cropVariety: 'Kaveri Jadoo',
  fieldSize: '4.5 Acres',
  sowingDate: 'June 18',
  cropAgeDays: 62,
  growthStage: 'Flowering & Early Boll Formation',
  irrigationType: 'Drip',
  soilType: 'Black Cotton Clay Loam'
};
export const DEFAULT_FARMER_PROFILE = INITIAL_FARMER_PROFILE;

export const CURRENT_WEATHER: WeatherData = {
  temperature: 28,
  humidity: 82,
  rainfall: '12 mm (Past 24h)',
  rainForecast: 'Moderate showers predicted in next 36 hrs',
  windSpeed: '11 km/h NW',
  leafWetnessDuration: '9.2 hrs continuous wetness',
  fungalGrowthRisk: 'HIGH',
  diseaseFavorabilityScore: 84
};
export const DEFAULT_WEATHER = CURRENT_WEATHER;

// Preset Scenarios
export const PRESET_SCENARIOS: Record<string, ScanRecord> = {
  default_early_leaf_spot: {
    id: 'scan-cotton-01',
    date: '10 Sept 2026',
    timestamp: Date.now() - 1000 * 60 * 30,
    crop: 'Cotton',
    cropStage: 'Flowering',
    imageUrl: 'https://images.unsplash.com/photo-1597848212624-a19eb35e2651?auto=format&fit=crop&w=800&q=80',
    leafType: 'Gossypium hirsutum leaf',
    healthScore: 74,
    healthStatus: 'Moderate Stress',
    primaryFinding: 'Early-stage Cercospora Leaf Spot',
    findingType: 'Fungal',
    confidence: 91,
    severityPercent: 28,
    severityLevel: 'MODERATE',
    progressionRiskPercent: 72,
    affectedAreaEstimate: '~28% of lower canopy leaf surface',
    weatherRisk: 'HIGH',
    summaryMessage: 'Your crop is showing early symptoms. Current environmental conditions (82% humidity, warm damp nights) may support rapid fungal progression.'
  },
  healthy_wheat: {
    id: 'scan-wheat-02',
    date: '08 Sept 2026',
    timestamp: Date.now() - 1000 * 60 * 60 * 48,
    crop: 'Wheat',
    cropStage: 'Tillering',
    imageUrl: 'https://images.unsplash.com/photo-1574943320219-553eb213f72d?auto=format&fit=crop&w=800&q=80',
    leafType: 'Triticum aestivum',
    healthScore: 94,
    healthStatus: 'Excellent',
    primaryFinding: 'Healthy Vigorous Foliage',
    findingType: 'Environmental',
    confidence: 96,
    severityPercent: 2,
    severityLevel: 'HEALTHY',
    progressionRiskPercent: 12,
    affectedAreaEstimate: '< 2% natural senescence on basal sheath',
    weatherRisk: 'LOW',
    summaryMessage: 'Crop vigor index is optimal. No active pathogenic fungal or bacterial lesions detected in canopy.'
  },
  nutrient_deficiency_rice: {
    id: 'scan-rice-03',
    date: '05 Sept 2026',
    timestamp: Date.now() - 1000 * 60 * 60 * 120,
    crop: 'Rice',
    cropStage: 'Panicle Initiation',
    imageUrl: 'https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?auto=format&fit=crop&w=800&q=80',
    leafType: 'Oryza sativa',
    healthScore: 62,
    healthStatus: 'Moderate Stress',
    primaryFinding: 'Interveinal Zinc & Nitrogen Deficiency',
    findingType: 'Nutrient',
    confidence: 88,
    severityPercent: 36,
    severityLevel: 'MODERATE',
    progressionRiskPercent: 44,
    affectedAreaEstimate: '~36% chlorotic yellowing along midrib',
    weatherRisk: 'MODERATE',
    summaryMessage: 'Symptom pattern reveals physiological nutrient deficiency rather than infectious pathogen. Micronutrient foliar spray is recommended.'
  },
  severe_late_blight_tomato: {
    id: 'scan-tomato-04',
    date: '01 Sept 2026',
    timestamp: Date.now() - 1000 * 60 * 60 * 200,
    crop: 'Tomato',
    cropStage: 'Fruiting',
    imageUrl: 'https://images.unsplash.com/photo-1592841200221-a6898f307baa?auto=format&fit=crop&w=800&q=80',
    leafType: 'Solanum lycopersicum',
    healthScore: 42,
    healthStatus: 'Severe Risk',
    primaryFinding: 'Advanced Late Blight (Phytophthora infestans)',
    findingType: 'Fungal',
    confidence: 94,
    severityPercent: 68,
    severityLevel: 'SEVERE',
    progressionRiskPercent: 88,
    affectedAreaEstimate: '~68% necrotic water-soaked margins',
    weatherRisk: 'HIGH',
    summaryMessage: 'High systemic infection detected. Immediate quarantine and targeted protective fungicide spray required to prevent total crop loss.'
  },
  unknown_condition: {
    id: 'scan-unknown-05',
    date: 'Just Now',
    timestamp: Date.now(),
    crop: 'Cotton',
    cropStage: 'Flowering',
    imageUrl: 'https://images.unsplash.com/photo-1605000797499-95a51c5269ae?auto=format&fit=crop&w=800&q=80',
    leafType: 'Unusual symptom pattern',
    healthScore: 50,
    healthStatus: 'Unknown',
    primaryFinding: 'Unknown Anomalous Crop Condition',
    findingType: 'Unknown',
    confidence: 38,
    severityPercent: 30,
    severityLevel: 'EARLY',
    progressionRiskPercent: 55,
    affectedAreaEstimate: 'Irregular marginal discoloration',
    weatherRisk: 'MODERATE',
    isUnknownCondition: true,
    summaryMessage: 'This image does not sufficiently match conditions in our verified knowledge base. The AI avoids false diagnosis and recommends agronomist verification.'
  },
  low_confidence: {
    id: 'scan-lowconf-06',
    date: 'Just Now',
    timestamp: Date.now(),
    crop: 'Cotton',
    cropStage: 'Flowering',
    imageUrl: 'https://images.unsplash.com/photo-1500651230702-0e2d8a49d4ad?auto=format&fit=crop&w=800&q=80',
    leafType: 'Sub-optimal lighting sample',
    healthScore: 68,
    healthStatus: 'Moderate Stress',
    primaryFinding: 'Ambiguous Foliar Spotting',
    findingType: 'Fungal',
    confidence: 48,
    severityPercent: 22,
    severityLevel: 'EARLY',
    progressionRiskPercent: 60,
    affectedAreaEstimate: 'Indeterminate leaf area',
    weatherRisk: 'HIGH',
    isLowConfidence: true,
    summaryMessage: 'AI confidence is only 48% due to shadow angle and partial canopy occlusion. Retake under direct diffused daylight or consult an agricultural officer.'
  }
};

export const DEFAULT_QUALITY_ASSESSMENT: QualityAssessment = {
  score: 82,
  isBlurAcceptable: true,
  isLightingGood: true,
  isLeafCentered: true,
  isDiseaseRegionVisible: true,
  isBackgroundClean: false,
  feedbackTitle: 'Field Image Suitable for Health Intelligence',
  feedbackNote: 'The targeted leaf and symptom spots are in focus with sufficient natural ambient illumination.',
  issues: [
    '✓ Leaf boundary clearly detected and segmented',
    '✓ Good natural lighting without harsh flash glare',
    '✓ Cercospora disease lesion region visible with sharp margins',
    '⚠ Background slightly complex (dry soil & secondary weed foliar shadows detected)'
  ]
};

export const DIFFERENTIAL_DIAGNOSIS_DATA: DifferentialItem[] = [
  {
    condition: 'Fungal Cercospora / Alternaria',
    type: 'fungal',
    probability: 72,
    color: '#D97706',
    keyIndicators: ['Circular necrotic lesions with purple halo', 'Concentrated on older/middle canopy leaves', 'Rapid spore proliferation under >80% humidity']
  },
  {
    condition: 'Potassium / Zinc Deficiency',
    type: 'nutrient',
    probability: 17,
    color: '#0284C7',
    keyIndicators: ['Interveinal bronze flecking along margins', 'No concentric target-ring pattern on spots']
  },
  {
    condition: 'Moisture Stress / Waterlogging',
    type: 'water',
    probability: 8,
    color: '#059669',
    keyIndicators: ['Root zone hypoxia signs', 'Mild marginal leaf curling']
  },
  {
    condition: 'Other / Insect Micro-punctures',
    type: 'other',
    probability: 3,
    color: '#6B7280',
    keyIndicators: ['Minor jassid or thrip mechanical feeding marks']
  }
];

export const PROGRESSION_STEPS: ProgressionStep[] = [
  {
    timeframe: 'TODAY',
    riskLevel: 'MODERATE',
    riskPercent: 58,
    visualNote: 'Initial circular brown spots (1-3mm), ~28% surface area',
    leafImpactArea: 28,
    description: 'Pathogen is actively germinating in epidermal stomata under recent warm precipitation.'
  },
  {
    timeframe: '48 HOURS',
    riskLevel: 'HIGH',
    riskPercent: 74,
    visualNote: 'Spot coalescing, yellow chlorotic halo widening to 45% canopy',
    leafImpactArea: 45,
    description: 'If relative humidity remains >80%, secondary conidia release will spread to middle canopy nodes.'
  },
  {
    timeframe: '3–5 DAYS',
    riskLevel: 'CRITICAL',
    riskPercent: 81,
    visualNote: 'Premature defoliation risk, boll shedding on lower branches',
    leafImpactArea: 65,
    description: 'Without cultural airflow management or protective spray, photosynthetic capacity could drop by 35%.'
  }
];

export const PRIORITIZED_ACTIONS: PrioritizedAction[] = [
  {
    id: 'act-01',
    level: 1,
    urgencyLabel: 'DO NOW',
    urgencyBadge: 'bg-red-50 text-red-700 border-red-200',
    title: 'Inspect nearby 20 plants for circular brown halos',
    description: 'Walk across the row in a zig-zag pattern. Check whether lesions are confined to lower shaded leaves or climbing up to productive flowering squares.',
    impact: 'Prevents unnoticed farm-wide spore migration',
    category: 'scouting'
  },
  {
    id: 'act-02',
    level: 2,
    urgencyLabel: 'WITHIN 24 HOURS',
    urgencyBadge: 'bg-amber-50 text-amber-700 border-amber-200',
    title: 'Improve furrow airflow & delay overhead/flood irrigation',
    description: 'Do not flood irrigate while nighttime relative humidity is 82%. Allow lower soil surface to breathe and prune heavily shaded bottom suckers.',
    impact: 'Reduces continuous leaf wetness hours from 9.2h to <5h',
    category: 'ventilation'
  },
  {
    id: 'act-03',
    level: 3,
    urgencyLabel: 'MONITOR',
    urgencyBadge: 'bg-blue-50 text-blue-700 border-blue-200',
    title: 'Re-scan marked leaf in 48 hours to evaluate halo expansion',
    description: 'Tie a soft colored ribbon on this branch. Open Crop Doctor and use "Compare Scan" to quantify if spot diameter increases beyond 4mm.',
    impact: 'Validates if natural defense or biocontrol halted progression',
    category: 'cultural'
  },
  {
    id: 'act-04',
    level: 4,
    urgencyLabel: 'IF SYMPTOMS SPREAD',
    urgencyBadge: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    title: 'Consult local Krishi Vigyan Kendra (KVK) officer before spraying',
    description: 'Show this Crop Doctor diagnostic report to your district agronomist to get authorized regional pesticide batch recommendations.',
    impact: 'Ensures responsible chemical stewardship and prevents pesticide resistance',
    category: 'expert'
  }
];

export const TREATMENT_CATEGORIES: TreatmentCategory[] = [
  {
    type: 'organic',
    title: 'Organic & Bio-Control Solutions',
    subtitle: 'Safe for pollinators, soil biology, and export standards',
    options: [
      {
        name: 'Trichoderma viride / harzianum (Bio-Fungicide)',
        purpose: 'Colonizes leaf surface to physically outcompete fungal spores and parasitic mycelium.',
        dosageNote: 'Typical rate: 2.5 kg per hectare or 5g/liter foliar spray (verify local KVK guidelines).',
        applicationGuidance: 'Spray in late afternoon (after 4:30 PM) when UV rays are low so beneficial microbes stay viable.',
        precautions: ['Do NOT mix with synthetic chemical copper or sulfur fungicides', 'Store culture in cool dry shade'],
        environmentalNote: 'Zero withholding period. 100% bee-safe.',
        efficacyRating: 4
      },
      {
        name: 'Cold-Pressed Neem Oil (10,000 PPM Azadirachtin)',
        purpose: 'Creates a protective natural organic barrier that inhibits spore germination and suppresses sucking pests.',
        dosageNote: '3 to 5 ml per liter with 1 ml organic surfactant / mild soap.',
        applicationGuidance: 'Ensure thorough coverage of leaf undersides where fungal humidity builds up.',
        precautions: ['Test on single branch first during intense heat waves'],
        environmentalNote: 'Biodegradable, promotes predatory beneficial ladybird beetles.',
        efficacyRating: 4
      }
    ]
  },
  {
    type: 'chemical',
    title: 'Targeted Chemical Fungicides',
    subtitle: 'Use only as targeted intervention if spots cross 35% canopy threshold',
    options: [
      {
        name: 'Copper Oxychloride 50% WP (Contact Protectant)',
        purpose: 'Multisite contact action prevents fungal spores from establishing germ tubes.',
        dosageNote: 'Representative guide: 2.5g to 3g per liter of clean water.',
        applicationGuidance: 'Apply prior to forecasted heavy rain when leaf surfaces dry. Maintain fine mist nozzle.',
        precautions: [
          'Wear protective nitrile gloves, mask and eye goggles during mixing',
          'Observe strict 14-day pre-harvest interval (PHI)'
        ],
        environmentalNote: 'Avoid spraying near aquaculture ponds or bee foraging zones during peak midday bloom.',
        efficacyRating: 4
      },
      {
        name: 'Azoxystrobin + Difenoconazole (Systemic + Curative)',
        purpose: 'Inhibits fungal respiration and sterol biosynthesis to arrest lesion growth.',
        dosageNote: 'Representative guide: 1 ml per liter (Follow registered CIB&RC label recommendation).',
        applicationGuidance: 'Best used early in disease cycle when spot count is low. Avoid repeating more than twice to prevent resistance.',
        precautions: ['Do not apply during windy conditions exceeding 15 km/h'],
        environmentalNote: 'Moderate aquatic toxicity risk; keep away from drainage channels.',
        efficacyRating: 5
      }
    ]
  },
  {
    type: 'prevention',
    title: 'Preventive Cultural Practices',
    subtitle: 'Long-term agroecological farm management',
    options: [
      {
        name: 'Canopy Thinning & Inter-row Air Drainage',
        purpose: 'Improves sunlight penetration into the lower vegetative layer, accelerating dew evaporation.',
        dosageNote: 'Zero chemical cost. Manual field labor.',
        applicationGuidance: 'De-sucker non-bearing vegetative branches below node 6.',
        precautions: ['Sanitize pruning tools with 70% alcohol or bleach between plants'],
        environmentalNote: 'Completely natural and builds long-term plant resilience.',
        efficacyRating: 5
      },
      {
        name: 'Balanced Potassium & Silicon Foliar Nourishment',
        purpose: 'Thickens leaf cuticle cell walls, forming physical barrier against hyphal penetration.',
        dosageNote: '00-00-50 Potassium Sulphate @ 5g/L + Potassium Silicate @ 2ml/L.',
        applicationGuidance: 'Spray in early morning with uniform coverage.',
        precautions: ['Ensure tank pH is between 6.0 and 6.8 for optimal uptake'],
        environmentalNote: 'Non-toxic nutrition boosting plant immunity.',
        efficacyRating: 4
      }
    ]
  }
];

export const HISTORICAL_HEALTH_TIMELINE = [
  { day: 'Day 1', date: '01 Sept', score: 92, status: 'Healthy', note: 'Canopy vigorous, low humidity (58%), clear weather' },
  { day: 'Day 4', date: '04 Sept', score: 87, status: 'Mild Stress', note: 'Monsoon showers arrived (34mm), first leaf wetness spike' },
  { day: 'Day 7', date: '07 Sept', score: 78, status: 'Moderate Stress', note: 'First micro-lesions noticed on lower cotton foliage' },
  { day: 'Day 10 (Today)', date: '10 Sept', score: 74, status: 'Moderate Stress', note: 'Early Cercospora Leaf Spot confirmed; 72% progression risk' }
];

export const FIELD_ZONES: FieldZone[] = [
  {
    id: 'zone-a',
    name: 'North Terrace (Plot A)',
    area: '1.8 Acres',
    cropStage: 'Flowering',
    healthScore: 91,
    status: 'HEALTHY',
    coordinates: { x: 8, y: 10, width: 42, height: 38 },
    detectedCondition: 'Healthy Canopy (No active spots)',
    lastScanned: 'Yesterday, 4:15 PM'
  },
  {
    id: 'zone-b',
    name: 'East Ridge (Plot B)',
    area: '1.2 Acres',
    cropStage: 'Flowering & Boll',
    healthScore: 78,
    status: 'EARLY_STRESS',
    coordinates: { x: 54, y: 10, width: 40, height: 42 },
    detectedCondition: 'Early Nitrogen Deficiency & Sparse Yellowing',
    lastScanned: '2 days ago'
  },
  {
    id: 'zone-c',
    name: 'South-West Lowland (Plot C)',
    area: '1.5 Acres',
    cropStage: 'Flowering & Boll',
    healthScore: 71,
    status: 'HIGH_RISK',
    coordinates: { x: 18, y: 52, width: 68, height: 40 },
    detectedCondition: 'Active Leaf Spot Cluster & Moisture Accumulation',
    lastScanned: 'Today, 9:30 AM'
  }
];

export const APP_ALERTS: AppAlert[] = [
  {
    id: 'alt-01',
    priority: 'HIGH',
    title: 'Disease Progression Risk Increased (+14%)',
    timeAgo: '42 mins ago',
    description: 'High humidity (82%) combined with 28°C night temperatures created favorable fungal sporulation conditions in Plot C.',
    metricBadge: 'Risk: 72%',
    ctaText: 'Review Action Plan',
    actionScreen: 'actions'
  },
  {
    id: 'alt-02',
    priority: 'WEATHER',
    title: 'Heavy Rainfall Warning in 36 Hours',
    timeAgo: '3 hours ago',
    description: 'Maharashtra IMD radar forecasts 25-35mm rainfall. Complete necessary bio-protective sprays or drainage clearing today.',
    metricBadge: 'Rain: 85% Chance',
    ctaText: 'Inspect Field Weather',
    actionScreen: 'weather'
  },
  {
    id: 'alt-03',
    priority: 'MONITOR',
    title: 'Crop Health Decreased 8% Over 7 Days',
    timeAgo: '1 day ago',
    description: 'Overall field health index dipped from 82 to 74. Check timeline chart to see historical correlation with rain events.',
    metricBadge: 'Health: 74/100',
    ctaText: 'View Health Timeline',
    actionScreen: 'timeline'
  }
];

export const PAST_SCAN_RECORDS: ScanRecord[] = [
  PRESET_SCENARIOS.default_early_leaf_spot,
  PRESET_SCENARIOS.healthy_wheat,
  PRESET_SCENARIOS.nutrient_deficiency_rice,
  PRESET_SCENARIOS.severe_late_blight_tomato
];

export const AI_SUGGESTED_QUESTIONS = [
  'Why are my cotton leaves developing circular spots with halos?',
  'Is it safe to spray bio-fungicide before tomorrow evening rain?',
  'How do I differentiate between fungal leaf spot and potassium deficiency?',
  'What is the immediate action I should take in Plot C today?',
  'Explain why the AI gave a 91% confidence score on this leaf.'
];

export interface TreatmentOption {
  id: string;
  title: string;
  category: 'organic' | 'prevention' | 'chemical';
  purpose: string;
  whenToUse: string;
  applicationGuidance: string;
  precautions: string;
  environmentalConsiderations: string;
}

export const TREATMENT_OPTIONS: TreatmentOption[] = [
  {
    id: 'tr-01',
    title: 'Trichoderma viride / harzianum (Bio-Fungicide)',
    category: 'organic',
    purpose: 'Biological competitive inhibition of fungal spore germination',
    whenToUse: 'At first appearance of 1-3mm leaf lesions (Early / Moderate severity)',
    applicationGuidance: 'Mix 5g/L clean water with organic surfactant. Foliar spray in late afternoon (after 4:30 PM) to protect beneficial microbes from solar UV degradation.',
    precautions: 'Do NOT tank-mix with synthetic chemical copper or sulfur fungicides.',
    environmentalConsiderations: 'Zero withholding period. Completely harmless to honeybees, soil earthworms, and groundwater.'
  },
  {
    id: 'tr-02',
    title: 'Cold-Pressed Neem Seed Kernel Extract (10,000 PPM)',
    category: 'organic',
    purpose: 'Anti-sporulation, insect feeding deterrent, natural cuticle shield',
    whenToUse: 'Prophylactic application during persistent high relative humidity (>75%)',
    applicationGuidance: '3-5 ml/L water with mild soap emulsifier. Ensure thorough coverage of leaf undersides where microclimates shelter fungal hyphae.',
    precautions: 'Avoid spraying during intense midday heat above 35°C to prevent foliar scorching.',
    environmentalConsiderations: 'Biodegradable within 72 hours. Encourages beneficial predatory ladybird beetles.'
  },
  {
    id: 'tr-03',
    title: 'Canopy Pruning & Aeration Management',
    category: 'prevention',
    purpose: 'Accelerates morning dew dry-off and reduces leaf wetness hours',
    whenToUse: 'Immediately when lower vegetative canopy becomes overly dense or shaded',
    applicationGuidance: 'Carefully prune unproductive lower senescent leaves (bottom 6 nodes) and maintain furrow weed clearance.',
    precautions: 'Disinfect pruning shears with mild bleach solution between rows to avoid mechanical transfer.',
    environmentalConsiderations: 'Zero chemical runoff, preserves soil biome, completely eco-friendly.'
  },
  {
    id: 'tr-04',
    title: 'Potassium & Silicon Foliar Strengthening',
    category: 'prevention',
    purpose: 'Reinforces epidermal cell wall thickness against hyphal penetration',
    whenToUse: 'During flowering and vegetative transitions when nutrient demand peaks',
    applicationGuidance: 'Spray Potassium Schoenite (0-0-23) or Potassium Sulphate @ 5g/L in early morning.',
    precautions: 'Ensure tank spray water pH is between 6.0 and 6.8 for optimal stomatal absorption.',
    environmentalConsiderations: 'Nutritional supplement; enhances overall plant systemic acquired resistance.'
  },
  {
    id: 'tr-05',
    title: 'Copper Oxychloride 50% WP (Protective Barrier)',
    category: 'chemical',
    purpose: 'Multisite contact protectant preventing secondary infection cycles',
    whenToUse: 'When disease severity crosses 35% and wet weather is forecast for 3+ consecutive days',
    applicationGuidance: '2.5g to 3g per liter. Spray with fine cone nozzle for complete canopy coverage.',
    precautions: 'Wear full personal protective equipment (gloves, mask, eye goggles). Strict 14-day pre-harvest interval (PHI).',
    environmentalConsiderations: 'Toxic to aquatic organisms; avoid spraying within 15 meters of open farm wells or ponds.'
  },
  {
    id: 'tr-06',
    title: 'Azoxystrobin + Difenoconazole (Curative Systemic)',
    category: 'chemical',
    purpose: 'Arrests mycelial respiration inside leaf tissue for rapid knockdown',
    whenToUse: 'Rescue treatment only if lesion spread threatens main productive canopy',
    applicationGuidance: '1 ml/L water. Maximum 2 applications per crop season to prevent fungal strain resistance.',
    precautions: 'Do not spray when wind velocity exceeds 15 km/h to prevent spray drift onto neighboring crops.',
    environmentalConsiderations: 'Strictly follow CIB&RC regional safety intervals; observe chemical disposal protocols.'
  }
];

export const TIMELINE_EVENTS = [
  {
    id: 'tl-1',
    day: 'Day 1',
    date: '01 Sept',
    score: 92,
    title: 'Vegetative Emergence & Clean Canopy',
    description: 'Cotton crop established with strong root vigor. Field humidity low (58%). No pathogen signs detected.',
    actionTaken: 'Standard basal organic manure applied'
  },
  {
    id: 'tl-2',
    day: 'Day 14',
    date: '14 Sept',
    score: 87,
    title: 'Heavy Monsoon Showers & Leaf Wetness Spike',
    description: '34mm rainfall recorded. Continuous leaf wetness reached 11 hours. Minor microclimate alert issued.',
    actionTaken: 'Furrow drainage channels cleared to prevent waterlogging'
  },
  {
    id: 'tl-3',
    day: 'Day 28',
    date: '28 Sept',
    score: 78,
    title: 'Initial Foliar Lesions Observed on Lower Leaves',
    description: 'First 1-2mm necrotic spots detected in Plot C. Yellow halo emergence around spot margins.',
    actionTaken: 'Lower leaf sample tagged for monitoring'
  },
  {
    id: 'tl-4',
    day: 'Day 30 (Today)',
    date: '10 Oct',
    score: 74,
    title: 'Early Cercospora Leaf Spot Confirmed (28% Severity)',
    description: 'AI model validated fungal etiology with 91% confidence. Progression risk elevated to 72%.',
    actionTaken: 'Action Plan generated; biological biocontrol prioritized'
  }
];

export const MOCK_HISTORY_RECORDS: ScanRecord[] = [
  PRESET_SCENARIOS.default_early_leaf_spot,
  PRESET_SCENARIOS.healthy_wheat,
  PRESET_SCENARIOS.nutrient_deficiency_rice,
  PRESET_SCENARIOS.severe_late_blight_tomato,
  PRESET_SCENARIOS.unknown_condition,
  PRESET_SCENARIOS.low_confidence
];

export interface FieldZoneData {
  id: string;
  name: string;
  area: string;
  healthScore: number;
  status: 'healthy' | 'moderate' | 'high-risk';
  notes: string;
  lastScanned: string;
}

export const MOCK_FIELD_ZONES: FieldZoneData[] = [
  {
    id: 'zone-a',
    name: 'Zone A (North Plot)',
    area: '1.2 Acres',
    healthScore: 88,
    status: 'healthy',
    notes: 'Vigorous vegetative growth, clean leaf lamina, zero fungal lesions.',
    lastScanned: 'Yesterday'
  },
  {
    id: 'zone-b',
    name: 'Zone B (East Ridge)',
    area: '1.0 Acres',
    healthScore: 84,
    status: 'healthy',
    notes: 'Good canopy aeration, minor dry leaf margins, no pathogen activity.',
    lastScanned: '2 days ago'
  },
  {
    id: 'zone-c',
    name: 'Zone C (South Lowland)',
    area: '1.5 Acres',
    healthScore: 58,
    status: 'high-risk',
    notes: 'Hotspot: Cercospora Leaf Spot cluster detected in lower foliage. 72% spread risk.',
    lastScanned: 'Today, 9:30 AM'
  },
  {
    id: 'zone-d',
    name: 'Zone D (West Drip Sector)',
    area: '0.8 Acres',
    healthScore: 72,
    status: 'moderate',
    notes: 'Mild interveinal chlorosis (nutrient stress). Spore risk moderate.',
    lastScanned: '3 days ago'
  }
];

export interface EarlyWarningAlert {
  id: string;
  title: string;
  severity: 'high' | 'moderate' | 'info';
  time: string;
  description: string;
  recommendedAction: string;
  isRead?: boolean;
}

export const MOCK_ALERTS: EarlyWarningAlert[] = [
  {
    id: 'al-1',
    title: 'Fungal Spore Germination Risk: HIGH (Plot C)',
    severity: 'high',
    time: '25 mins ago',
    description: 'Current 82% humidity and 28°C nocturnal temperatures cross the biological threshold for rapid Cercospora incubation.',
    recommendedAction: 'Inspect Plot C lower canopy; apply bio-fungicide before evening dew.',
    isRead: false
  },
  {
    id: 'al-2',
    title: 'Continuous Leaf Wetness Exceeded 9.5 Hours',
    severity: 'moderate',
    time: '2 hours ago',
    description: 'Dense row spacing in the south quadrant has trapped overnight moisture longer than the 6-hour safe dry-off window.',
    recommendedAction: 'Prune shaded lower vegetative suckers to improve inter-row air circulation.',
    isRead: false
  },
  {
    id: 'al-3',
    title: 'Regional Outbreak Advisory (Panvel Taluka)',
    severity: 'moderate',
    time: '5 hours ago',
    description: 'Agricultural extension officers report widespread early leaf spot in neighboring cotton farms within a 15km radius.',
    recommendedAction: 'Conduct preventative scouting on field boundary perimeters.',
    isRead: true
  }
];

export const MOCK_CHAT_MESSAGES = [
  {
    id: 'msg-1',
    sender: 'ai' as const,
    text: 'Namaste Rahul! I am your Crop Doctor agricultural advisor. Your cotton field in Panvel shows early leaf spot symptoms in Plot C with 82% humidity. How can I assist you with your field management today?',
    timestamp: '10:00 AM'
  },
  {
    id: 'msg-2',
    sender: 'user' as const,
    text: 'Can I spray fungicide today? Rain is expected soon.',
    timestamp: '10:02 AM'
  },
  {
    id: 'msg-3',
    sender: 'ai' as const,
    text: 'Because moderate rainfall is forecast within 36 hours, avoid applying water-soluble synthetic chemical fungicides today as rain will wash off the active ingredients into the soil. Instead, apply an organic bio-fungicide like Trichoderma viride with a natural sticker agent in the late afternoon.',
    timestamp: '10:03 AM'
  }
];

