import React, { useState } from 'react';
import { Download, Share2, Check, ArrowRight, Printer, MapPin, Calendar, Sprout, ShieldCheck, CloudSun, AlertTriangle } from 'lucide-react';
import { FarmerProfile, ScanRecord, WeatherData, AppScreen } from '../../types';

interface ReportSummaryScreenProps {
  farmer: FarmerProfile;
  scan: ScanRecord;
  weather: WeatherData;
  onNavigate: (screen: AppScreen) => void;
}

export const ReportSummaryScreen: React.FC<ReportSummaryScreenProps> = ({
  farmer,
  scan,
  weather,
  onNavigate
}) => {
  const [isCopied, setIsCopied] = useState(false);

  const handleShare = () => {
    const text = `*CROP DOCTOR HEALTH INTELLIGENCE REPORT*\nFarmer: ${farmer.name}\nLocation: ${farmer.location}, ${farmer.state}\nCrop: ${scan.crop}\nPrimary Finding: ${scan.primaryFinding}\nHealth Score: ${scan.healthScore}/100\nSeverity: ${scan.severityPercent}%\nProgression Risk: ${scan.progressionRiskPercent}%\nWeather: ${weather.temperature}°C, ${weather.humidity}% RH\nAction: Inspect lower canopy; apply biological Trichoderma before evening dew.`;
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-5 sm:py-7 space-y-6 animate-fadeIn pb-24 md:pb-12">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-bold font-mono">
            OFFICIAL AGRONOMIC AUDIT
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-gray-900 font-['Outfit'] mt-1">
            Crop Health Report
          </h2>
          <p className="text-xs text-gray-500">
            Certified digital health certificate ready for agricultural extension, insurance, or KVK review.
          </p>
        </div>

        <button
          onClick={handlePrint}
          className="p-2.5 rounded-xl border border-gray-300 text-gray-700 hover:bg-gray-100 transition-colors hidden sm:flex items-center gap-1.5 text-xs font-bold"
        >
          <Printer className="w-4 h-4" />
          <span>Print</span>
        </button>
      </div>

      {/* Printable Report Document Card */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-gray-300 shadow-sm space-y-6 text-gray-800 print:border-none print:shadow-none">
        {/* Certificate Header Bar */}
        <div className="flex items-start justify-between border-b-2 border-[#1B4332] pb-4">
          <div>
            <span className="text-xl font-black tracking-tight font-['Outfit'] text-[#1B4332] block">
              CROP DOCTOR
            </span>
            <span className="text-[11px] font-mono text-gray-500">
              CROP HEALTH INTELLIGENCE & EARLY-ACTION ENGINE
            </span>
          </div>
          <div className="text-right">
            <span className="text-[10px] font-mono font-bold text-gray-400 uppercase block">REPORT ID</span>
            <span className="text-xs font-mono font-bold text-gray-900">#CP-2026-MH841</span>
          </div>
        </div>

        {/* Section 1: Farmer & Field Details */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-gray-50 p-3.5 rounded-xl border border-gray-200">
          <div>
            <span className="text-[10px] text-gray-400 uppercase font-mono block">FARMER</span>
            <strong className="text-gray-900">{farmer.name}</strong>
          </div>
          <div>
            <span className="text-[10px] text-gray-400 uppercase font-mono block">LOCATION</span>
            <strong className="text-gray-900">{farmer.location}, {farmer.state}</strong>
          </div>
          <div>
            <span className="text-[10px] text-gray-400 uppercase font-mono block">CROP & VARIETY</span>
            <strong className="text-gray-900">{scan.crop} ({farmer.cropVariety})</strong>
          </div>
          <div>
            <span className="text-[10px] text-gray-400 uppercase font-mono block">DATE & TIME</span>
            <strong className="text-gray-900">{scan.date}</strong>
          </div>
        </div>

        {/* Section 2: Scanned Crop Visual & Diagnostic Outcome */}
        <div className="flex flex-col sm:flex-row items-center gap-4 border-b border-gray-200 pb-5">
          <img
            src={scan.imageUrl}
            alt="Report leaf sample"
            className="w-32 h-32 rounded-2xl object-cover border border-gray-200 shrink-0"
          />

          <div className="space-y-2 text-xs flex-1">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-800 text-[10px] font-bold font-mono">
                DIAGNOSIS
              </span>
              <span className="font-mono text-gray-500">AI Confidence: {scan.confidence}%</span>
            </div>
            <h3 className="text-xl font-bold text-gray-900 font-['Outfit']">
              {scan.primaryFinding}
            </h3>
            <p className="text-gray-600 leading-relaxed">
              {scan.summaryMessage}
            </p>

            <div className="grid grid-cols-3 gap-2 pt-1 font-mono text-[11px]">
              <div className="p-2 bg-gray-50 rounded border border-gray-100">
                <span className="text-gray-400 block text-[9px]">HEALTH SCORE</span>
                <strong className="text-sm text-gray-900">{scan.healthScore}/100</strong>
              </div>
              <div className="p-2 bg-gray-50 rounded border border-gray-100">
                <span className="text-gray-400 block text-[9px]">CANOPY SEVERITY</span>
                <strong className="text-sm text-amber-700">{scan.severityPercent}%</strong>
              </div>
              <div className="p-2 bg-gray-50 rounded border border-gray-100">
                <span className="text-gray-400 block text-[9px]">PROGRESSION RISK</span>
                <strong className="text-sm text-red-600">{scan.progressionRiskPercent}%</strong>
              </div>
            </div>
          </div>
        </div>

        {/* Section 3: Weather Context */}
        <div className="p-3.5 bg-cyan-50/50 rounded-xl border border-cyan-100 text-xs space-y-1">
          <div className="flex items-center gap-1.5 font-bold text-cyan-950 font-mono text-[11px]">
            <CloudSun className="w-3.5 h-3.5 text-cyan-700" />
            <span>WEATHER & ENVIRONMENTAL CONTEXT</span>
          </div>
          <p className="text-cyan-900">
            {weather.temperature}°C &bull; {weather.humidity}% Relative Humidity &bull; Recent 12mm rain recorded. Fungal favorability index: <strong>HIGH ({weather.diseaseFavorabilityScore}/100)</strong>.
          </p>
        </div>

        {/* Section 4: Recommended Action Sequence */}
        <div className="space-y-2 text-xs">
          <span className="text-[11px] font-mono font-bold text-gray-400 uppercase block">
            OFFICIAL AGRONOMIC RECOMMENDATIONS
          </span>
          <ol className="list-decimal list-inside space-y-1.5 text-gray-700">
            <li><strong>Immediate (Day 1):</strong> Inspect lower foliage in adjacent rows to establish infection perimeter.</li>
            <li><strong>Within 24 Hours:</strong> Minimize overhead flood irrigation; improve canopy ventilation.</li>
            <li><strong>Bio-Control Application:</strong> Foliar spray Trichoderma viride formulation at 5g/L during late afternoon.</li>
            <li><strong>Monitoring:</strong> Conduct follow-up optical scan in 48 hours to confirm cessation of lesion growth.</li>
          </ol>
        </div>

        {/* Stamp / Verification Footer */}
        <div className="pt-4 border-t border-gray-200 flex items-center justify-between text-[10px] text-gray-400 font-mono">
          <span>Crop Doctor Autonomous AI Engine v2.4</span>
          <span>Verified against ICAR & KVK Protocols</span>
        </div>
      </div>

      {/* Share Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
        <button
          onClick={handleShare}
          className="py-3.5 px-6 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm flex items-center justify-center gap-2 transition-all active:scale-98"
        >
          <Share2 className="w-4 h-4" />
          <span>Share on WhatsApp</span>
        </button>

        <button
          onClick={handlePrint}
          className="py-3.5 px-6 rounded-xl bg-[#1B4332] hover:bg-[#255742] text-white font-bold text-xs shadow-sm flex items-center justify-center gap-2 transition-all active:scale-98"
        >
          <Download className="w-4 h-4 text-emerald-300" />
          <span>Download PDF / Print</span>
        </button>
      </div>
    </div>
  );
};
