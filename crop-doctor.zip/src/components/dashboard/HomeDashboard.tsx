import React from 'react';
import {
  Camera,
  AlertTriangle,
  ArrowRight,
  TrendingDown,
  CloudSun,
  Droplets,
  Wind,
  Layers,
  History,
  Bell,
  Sparkles,
  MapPin,
  FileSpreadsheet,
  Activity,
  Bot,
  ChevronRight,
  ShieldCheck,
  Zap
} from 'lucide-react';
import { AppScreen, FarmerProfile, WeatherData, ScanRecord } from '../../types';
import { TRANSLATIONS } from '../../data/translations';

interface HomeDashboardProps {
  farmerProfile: FarmerProfile;
  weather: WeatherData;
  activeScenario: ScanRecord;
  onNavigate: (screen: AppScreen) => void;
  onOpenVoice: () => void;
  onOpenScenarioModal: () => void;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  farmerProfile,
  weather,
  activeScenario,
  onNavigate,
  onOpenVoice,
  onOpenScenarioModal
}) => {
  const t = TRANSLATIONS[farmerProfile.preferredLanguage] || TRANSLATIONS.en;

  // Pipeline stages
  const pipelineStages = [
    { name: 'OBSERVE', active: true, desc: 'Camera & Field' },
    { name: 'ANALYZE', active: true, desc: 'Visual Symptoms' },
    { name: 'UNDERSTAND', active: true, desc: 'Cause vs Stress' },
    { name: 'PREDICT', active: true, desc: '48h Spread Risk' },
    { name: 'ACT', active: true, desc: 'Prioritized Steps' },
    { name: 'MONITOR', active: true, desc: 'Health Trajectory' }
  ];

  // Radial calculation for health gauge
  const score = activeScenario.healthScore;
  const radius = 58;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  // Color selection based on health score
  const getScoreColor = (val: number) => {
    if (val >= 85) return '#10B981'; // Emerald
    if (val >= 65) return '#F59E0B'; // Amber
    return '#EF4444'; // Red
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-5 sm:py-8 space-y-6 animate-fadeIn pb-24 md:pb-12">
      {/* 1. Top Greeting & Field Context */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 sm:p-5 rounded-2xl border border-gray-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-gray-500 mb-0.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>FIELD SENSOR & SATELLITE LIVE FEED</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900 font-['Outfit']">
            {t.goodMorning}, {farmerProfile.name}
          </h1>
          <div className="flex items-center gap-2 mt-1 text-xs text-gray-600">
            <span className="flex items-center gap-1 font-medium text-emerald-800">
              <MapPin className="w-3.5 h-3.5 text-emerald-600" />
              {farmerProfile.location}, {farmerProfile.state}
            </span>
            <span className="text-gray-300">&bull;</span>
            <span className="font-semibold text-gray-700 bg-gray-100 px-2 py-0.5 rounded">
              {farmerProfile.crop}
            </span>
          </div>
        </div>

        {/* Quick Scenario Picker Button */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenScenarioModal}
            className="text-xs font-bold px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 rounded-xl border border-emerald-200 transition-colors flex items-center gap-1.5 shadow-2xs"
          >
            <Zap className="w-3.5 h-3.5 text-emerald-600" />
            <span>Simulate Cases</span>
          </button>
        </div>
      </div>

      {/* 2. Weather & Environmental Microclimate Card */}
      <div
        onClick={() => onNavigate('weather')}
        className="bg-gradient-to-br from-[#1B3B2B] to-[#142C20] text-white p-4 sm:p-5 rounded-2xl shadow-md border border-emerald-600/30 cursor-pointer hover:border-emerald-400/50 transition-all group"
      >
        <div className="flex items-center justify-between mb-3 border-b border-white/10 pb-2.5">
          <div className="flex items-center gap-2">
            <CloudSun className="w-5 h-5 text-emerald-300" />
            <span className="text-xs font-bold tracking-wider text-emerald-200 uppercase font-mono">
              MICROCLIMATE & DISEASE FAVORABILITY
            </span>
          </div>
          <span className="text-xs font-bold text-emerald-300 flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
            <span>Forecast details</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center sm:text-left">
          {/* Temperature */}
          <div className="bg-white/5 p-2.5 rounded-xl border border-white/5">
            <span className="text-[11px] text-emerald-200/80 block">Temperature</span>
            <div className="text-xl sm:text-2xl font-black text-white mt-0.5 font-['Outfit']">
              {weather.temperature}°C
            </div>
            <span className="text-[10px] text-emerald-300">Warm day, cool night</span>
          </div>

          {/* Humidity */}
          <div className="bg-white/5 p-2.5 rounded-xl border border-white/5">
            <span className="text-[11px] text-emerald-200/80 block">Relative Humidity</span>
            <div className="text-xl sm:text-2xl font-black text-white mt-0.5 font-['Outfit']">
              {weather.humidity}%
            </div>
            <span className="text-[10px] text-amber-300 font-semibold">High vapor pressure</span>
          </div>

          {/* Rain Expected */}
          <div className="bg-white/5 p-2.5 rounded-xl border border-white/5">
            <span className="text-[11px] text-emerald-200/80 block">Rainfall Outlook</span>
            <div className="text-sm font-bold text-white mt-1.5 flex items-center gap-1">
              <Droplets className="w-4 h-4 text-cyan-300" />
              <span>Rain Expected</span>
            </div>
            <span className="text-[10px] text-cyan-200">Showers in 36h</span>
          </div>

          {/* Disease-Favorable Conditions */}
          <div className="bg-red-950/40 border border-red-500/40 p-2.5 rounded-xl text-left">
            <span className="text-[10px] uppercase font-bold tracking-wider text-red-300 block">
              Fungal Conditions
            </span>
            <div className="text-lg font-extrabold text-red-300 mt-0.5 flex items-center gap-1.5 font-['Outfit']">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
              <span>HIGH RISK</span>
            </div>
            <span className="text-[10px] text-red-200/90 leading-none">Spore germination active</span>
          </div>
        </div>
      </div>

      {/* 3. Main Hero Card: CROP HEALTH (Circular/Radial Health Visualization) */}
      <div className="bg-white p-5 sm:p-7 rounded-3xl border border-gray-200/80 shadow-md relative overflow-hidden">
        {/* Subtle decorative field topographic line overlay */}
        <div className="absolute top-0 right-0 w-64 h-64 opacity-5 pointer-events-none">
          <svg viewBox="0 0 100 100" className="w-full h-full stroke-emerald-900 fill-none stroke-[0.75]">
            <circle cx="50" cy="50" r="20" />
            <circle cx="50" cy="50" r="35" />
            <circle cx="50" cy="50" r="48" />
          </svg>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-6 relative z-10">
          {/* Radial Health Gauge */}
          <div className="relative w-44 h-44 shrink-0 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 140 140">
              {/* Background track */}
              <circle
                cx="70"
                cy="70"
                r={radius}
                stroke="#E5E7EB"
                strokeWidth="11"
                fill="transparent"
              />
              {/* Animated Progress arc */}
              <circle
                cx="70"
                cy="70"
                r={radius}
                stroke={getScoreColor(score)}
                strokeWidth="11"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                fill="transparent"
                className="transition-all duration-1000 ease-out"
              />
            </svg>

            {/* Center score labels */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-[11px] font-bold tracking-wider uppercase text-gray-500">
                {t.cropHealth}
              </span>
              <span className="text-4xl font-black text-gray-900 font-['Outfit'] -my-1">
                {score}
              </span>
              <span className="text-xs font-semibold text-gray-400">/ 100</span>
            </div>
          </div>

          {/* Status & Diagnostic Details */}
          <div className="flex-1 text-center sm:text-left space-y-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-bold">
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
              <span>Status: {activeScenario.healthStatus}</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 font-['Outfit'] leading-tight">
              {activeScenario.primaryFinding}
            </h2>

            <p className="text-xs sm:text-sm text-gray-600 leading-relaxed max-w-lg">
              {activeScenario.summaryMessage}
            </p>

            {/* 7-Day Trend Graph & Stat */}
            <div className="pt-2 flex flex-wrap items-center gap-4 text-xs">
              <div className="flex items-center gap-1.5 text-amber-700 bg-amber-50/80 px-3 py-1.5 rounded-lg border border-amber-200">
                <TrendingDown className="w-4 h-4" />
                <span className="font-semibold">
                  Crop health has decreased 8% in the last 7 days.
                </span>
              </div>

              {/* Sparkline visualization */}
              <div className="flex items-end gap-1 h-6 px-2 py-0.5 bg-gray-50 rounded border border-gray-200" title="Last 4 scans trend">
                <span className="w-1.5 bg-emerald-500 rounded-t h-5" title="Day 1: 92" />
                <span className="w-1.5 bg-emerald-400 rounded-t h-4" title="Day 4: 87" />
                <span className="w-1.5 bg-amber-500 rounded-t h-3.5" title="Day 7: 78" />
                <span className="w-1.5 bg-amber-600 rounded-t h-3" title="Day 10: 74" />
              </div>
            </div>
          </div>
        </div>

        {/* Action Link to Full Result Breakdown */}
        <div className="mt-5 pt-4 border-t border-gray-100 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3 text-gray-500">
            <span>Confidence: <strong className="text-gray-900">{activeScenario.confidence}%</strong></span>
            <span>&bull;</span>
            <span>Severity: <strong className="text-gray-900">{activeScenario.severityPercent}%</strong></span>
          </div>

          <button
            onClick={() => onNavigate('result')}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 py-1"
          >
            <span>Inspect Complete Diagnostic Breakdown</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 4. EARLY WARNING Card */}
      <div className="bg-gradient-to-r from-red-50 via-amber-50 to-orange-50 p-4 sm:p-5 rounded-2xl border border-amber-300 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2.5 rounded-xl bg-red-100 text-red-700 shrink-0">
            <AlertTriangle className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-red-700 font-mono">
                {t.earlyWarning}
              </span>
              <span className="px-2 py-0.5 bg-red-600 text-white rounded text-[10px] font-black">
                RISK: {activeScenario.progressionRiskPercent}%
              </span>
            </div>
            <h3 className="font-bold text-sm sm:text-base text-gray-900 mt-0.5">
              Fungal disease progression risk is increasing in lower canopy.
            </h3>
            <p className="text-xs text-gray-600 mt-0.5">
              Warm nocturnal humidity will accelerate spore incubation within next 48 hours.
            </p>
          </div>
        </div>

        <button
          onClick={() => onNavigate('progression')}
          className="px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl shadow-xs shrink-0 flex items-center justify-center gap-1.5 transition-colors"
        >
          <span>View Risk</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* 5. MAIN CTA: "SCAN YOUR CROP" (Large camera button) */}
      <div className="text-center py-2">
        <button
          onClick={() => onNavigate('scan')}
          className="w-full max-w-xl mx-auto py-5 px-6 rounded-2xl bg-gradient-to-r from-[#1B4332] via-[#2D6A4F] to-[#1B4332] hover:from-[#153628] hover:to-[#245841] text-white font-extrabold text-lg sm:text-xl shadow-xl shadow-emerald-950/20 flex items-center justify-center gap-3.5 transition-all transform active:scale-98 group border border-emerald-500/30"
        >
          <div className="w-12 h-12 rounded-xl bg-emerald-400/20 border border-emerald-300/40 flex items-center justify-center group-hover:scale-110 transition-transform">
            <Camera className="w-7 h-7 text-emerald-300" />
          </div>
          <div className="text-left">
            <span className="block font-black font-['Outfit'] tracking-wide">
              {t.scanYourCrop}
            </span>
            <span className="block text-xs font-medium text-emerald-200 -mt-0.5">
              Capture or upload affected leaf &bull; Multi-factor AI analysis
            </span>
          </div>
        </button>
      </div>

      {/* 6. Pipeline Indicator: OBSERVE → ANALYZE → UNDERSTAND → PREDICT → ACT → MONITOR */}
      <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-2xs">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-bold text-gray-400 tracking-wider font-mono uppercase">
            CROP DOCTOR INTELLIGENCE PIPELINE
          </span>
          <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded">
            Autonomous Pipeline Active
          </span>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5 text-center">
          {pipelineStages.map((stage, i) => (
            <div
              key={stage.name}
              className={`p-2 rounded-xl border transition-all ${
                stage.active
                  ? 'bg-emerald-50/80 border-emerald-300/80 text-emerald-900'
                  : 'bg-gray-50 border-gray-200 text-gray-400'
              }`}
            >
              <span className="text-[9px] font-mono text-emerald-700 font-bold block">
                0{i + 1}
              </span>
              <span className="text-xs font-black block tracking-tight font-['Outfit']">
                {stage.name}
              </span>
              <span className="text-[9px] text-gray-500 hidden sm:block truncate">
                {stage.desc}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* 7. Secondary Quick Actions Grid */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider font-mono">
            Direct Farmer Modules
          </h3>
          <span className="text-xs text-emerald-700 font-medium">Full System Access</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {/* My Crops & Field Map */}
          <button
            onClick={() => onNavigate('field-map')}
            className="p-3.5 bg-white rounded-xl border border-gray-200 hover:border-emerald-400 hover:shadow-xs transition-all text-left group"
          >
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center mb-2 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
              <MapPin className="w-4 h-4" />
            </div>
            <h4 className="text-xs font-bold text-gray-900">{t.fieldMap}</h4>
            <p className="text-[11px] text-gray-500 mt-0.5">Top-down zone risk map</p>
          </button>

          {/* History */}
          <button
            onClick={() => onNavigate('history')}
            className="p-3.5 bg-white rounded-xl border border-gray-200 hover:border-emerald-400 hover:shadow-xs transition-all text-left group"
          >
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center mb-2 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
              <History className="w-4 h-4" />
            </div>
            <h4 className="text-xs font-bold text-gray-900">{t.history}</h4>
            <p className="text-[11px] text-gray-500 mt-0.5">Filter past leaf records</p>
          </button>

          {/* Alerts */}
          <button
            onClick={() => onNavigate('alerts')}
            className="p-3.5 bg-white rounded-xl border border-gray-200 hover:border-emerald-400 hover:shadow-xs transition-all text-left group relative"
          >
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center mb-2 group-hover:bg-amber-600 group-hover:text-white transition-colors">
              <Bell className="w-4 h-4" />
            </div>
            <span className="absolute top-3.5 right-3.5 w-2 h-2 rounded-full bg-red-500" />
            <h4 className="text-xs font-bold text-gray-900">{t.alerts}</h4>
            <p className="text-[11px] text-gray-500 mt-0.5">3 early warnings active</p>
          </button>

          {/* Ask AI / Voice */}
          <button
            onClick={() => onNavigate('assistant')}
            className="p-3.5 bg-white rounded-xl border border-gray-200 hover:border-emerald-400 hover:shadow-xs transition-all text-left group"
          >
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center mb-2 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
              <Bot className="w-4 h-4" />
            </div>
            <h4 className="text-xs font-bold text-gray-900">{t.askAI}</h4>
            <p className="text-[11px] text-gray-500 mt-0.5">Voice & chat agronomist</p>
          </button>
        </div>

        {/* Additional Secondary Links Row */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
          <button
            onClick={() => onNavigate('timeline')}
            className="p-2.5 bg-white rounded-xl border border-gray-200 text-xs font-medium text-gray-700 hover:bg-gray-50 flex items-center gap-2"
          >
            <Activity className="w-4 h-4 text-emerald-600" />
            <span>Health Timeline</span>
          </button>
          <button
            onClick={() => onNavigate('actions')}
            className="p-2.5 bg-white rounded-xl border border-gray-200 text-xs font-medium text-gray-700 hover:bg-gray-50 flex items-center gap-2"
          >
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Prioritized Actions (4)</span>
          </button>
          <button
            onClick={() => onNavigate('report')}
            className="p-2.5 bg-white rounded-xl border border-gray-200 text-xs font-medium text-gray-700 hover:bg-gray-50 flex items-center gap-2 col-span-2 sm:col-span-1"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Export Farmer Report</span>
          </button>
        </div>
      </div>
    </div>
  );
};
