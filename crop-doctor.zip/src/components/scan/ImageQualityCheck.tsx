import React from 'react';
import { CheckCircle2, AlertTriangle, ArrowRight, RefreshCw, Sparkles, ShieldCheck, Eye } from 'lucide-react';
import { QualityAssessment } from '../../types';
import { DEFAULT_QUALITY_ASSESSMENT } from '../../data/mockData';

interface ImageQualityCheckProps {
  capturedImage: string;
  assessment?: QualityAssessment;
  onProceed: () => void;
  onRetake: () => void;
}

export const ImageQualityCheck: React.FC<ImageQualityCheckProps> = ({
  capturedImage,
  assessment = DEFAULT_QUALITY_ASSESSMENT,
  onProceed,
  onRetake
}) => {
  const qualityItems = [
    { label: 'Leaf Boundary Detected', ok: assessment.isLeafCentered, note: 'Target lamina centered in optical frame' },
    { label: 'Ambient Lighting', ok: assessment.isLightingGood, note: 'No over-saturated solar reflection or flash glint' },
    { label: 'Disease Region Visibility', ok: assessment.isDiseaseRegionVisible, note: 'Micro-lesions clearly distinguishable' },
    { label: 'Sharpness & Blur Check', ok: assessment.isBlurAcceptable, note: 'Within acceptable Laplacian variance' },
    { label: 'Background Complexity', ok: assessment.isBackgroundClean, note: 'Soil texture & secondary weeds present', isWarning: !assessment.isBackgroundClean }
  ];

  return (
    <div className="max-w-xl mx-auto px-4 py-5 sm:py-7 space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="text-center space-y-1">
        <span className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold font-mono">
          <ShieldCheck className="w-3.5 h-3.5" />
          PRE-ANALYSIS QUALITY GATE
        </span>
        <h2 className="text-2xl font-bold text-gray-900 font-['Outfit']">
          Image Quality Assessment
        </h2>
        <p className="text-xs text-gray-500 max-w-sm mx-auto">
          Agricultural field conditions require quality pre-checks to avoid inaccurate diagnostic confidence.
        </p>
      </div>

      {/* Center Leaf Preview with Quality Overlays */}
      <div className="relative aspect-[4/3] rounded-3xl overflow-hidden border-2 border-emerald-500/40 shadow-lg bg-black">
        <img
          src={capturedImage}
          alt="Candidate leaf scan"
          className="w-full h-full object-cover"
        />

        {/* Floating Quality Score Tag */}
        <div className="absolute top-3 left-3 bg-black/75 backdrop-blur-md text-white px-3 py-1.5 rounded-xl border border-white/20 flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
          <div>
            <span className="text-[10px] uppercase font-bold text-emerald-300 block leading-none font-mono">
              Quality Score
            </span>
            <span className="text-base font-black text-white font-['Outfit']">
              {assessment.score}%
            </span>
          </div>
        </div>

        {/* Reticle guide on leaf spot */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-32 h-32 border-2 border-dashed border-emerald-400/80 rounded-full flex items-center justify-center">
            <span className="text-[10px] text-white bg-black/60 px-2 py-0.5 rounded">
              Lesion in focus
            </span>
          </div>
        </div>
      </div>

      {/* Assessment Checklist Card */}
      <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between border-b border-gray-100 pb-2">
          <h3 className="text-xs font-bold text-gray-700 uppercase tracking-wider font-mono">
            Optical Diagnostic Validation
          </h3>
          <span className="text-xs font-extrabold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
            SUITABLE FOR INFERENCE
          </span>
        </div>

        <div className="space-y-2">
          {qualityItems.map((item, idx) => (
            <div
              key={idx}
              className="flex items-start justify-between gap-3 text-xs p-2 rounded-xl bg-gray-50/80"
            >
              <div className="flex items-center gap-2">
                {item.ok ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
                )}
                <div>
                  <span className="font-bold text-gray-800 block">{item.label}</span>
                  <span className="text-[11px] text-gray-500">{item.note}</span>
                </div>
              </div>
              <span
                className={`text-[11px] font-bold px-1.5 py-0.5 rounded ${
                  item.ok
                    ? 'text-emerald-700 bg-emerald-100'
                    : 'text-amber-800 bg-amber-100'
                }`}
              >
                {item.ok ? 'PASS' : 'FAIR'}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Actions: Analyze Anyway or Retake Photo */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
        {/* Main CTA: Analyze Anyway */}
        <button
          onClick={onProceed}
          className="py-3.5 px-6 rounded-xl bg-[#1B4332] hover:bg-[#255742] text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 transition-all active:scale-98"
        >
          <span>Analyze Anyway</span>
          <ArrowRight className="w-4 h-4 text-emerald-300" />
        </button>

        {/* Secondary: Retake Photo */}
        <button
          onClick={onRetake}
          className="py-3.5 px-6 rounded-xl bg-white hover:bg-gray-50 text-gray-700 font-bold text-sm border border-gray-300 shadow-2xs flex items-center justify-center gap-2 transition-all active:scale-98"
        >
          <RefreshCw className="w-4 h-4 text-gray-500" />
          <span>Retake Photo</span>
        </button>
      </div>
    </div>
  );
};
