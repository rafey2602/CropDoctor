import React, { useState, useEffect } from 'react';
import { Check, Sparkles, Activity } from 'lucide-react';

interface AIAnalysisLoadingProps {
  onComplete: () => void;
  leafImage: string;
}

export const AIAnalysisLoading: React.FC<AIAnalysisLoadingProps> = ({ onComplete, leafImage }) => {
  const steps = [
    { id: '01', title: 'Image processing & normalization' },
    { id: '02', title: 'Leaf segmentation & background removal' },
    { id: '03', title: 'Symptom & lesion feature extraction' },
    { id: '04', title: 'Disease classification vs nutrient deficiency' },
    { id: '05', title: 'Physiological stress analysis' },
    { id: '06', title: 'Severity & affected area estimation' },
    { id: '07', title: 'Environmental microclimate risk integration' },
    { id: '08', title: 'Disease progression prediction modeling' }
  ];

  const [activeStepIndex, setActiveStepIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveStepIndex((prev) => {
        if (prev < steps.length - 1) {
          return prev + 1;
        } else {
          clearInterval(interval);
          setTimeout(onComplete, 600);
          return prev;
        }
      });
    }, 450);

    return () => clearInterval(interval);
  }, [onComplete, steps.length]);

  return (
    <div className="max-w-md mx-auto px-4 py-8 space-y-6 animate-fadeIn min-h-[75vh] flex flex-col justify-center">
      {/* Visual Scanning Animation over Leaf */}
      <div className="relative w-56 h-56 mx-auto rounded-3xl overflow-hidden border-2 border-emerald-500 shadow-2xl bg-[#0F241A]">
        <img
          src={leafImage}
          alt="Target leaf scanning"
          className="w-full h-full object-cover opacity-75 filter contrast-125"
        />

        {/* Animated Laser Scanning Line */}
        <div className="absolute inset-0 pointer-events-none">
          <div
            className="w-full h-1 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_15px_#34D399] animate-pulse"
            style={{
              position: 'absolute',
              top: `${(activeStepIndex / (steps.length - 1)) * 90 + 5}%`,
              transition: 'top 0.4s ease-in-out'
            }}
          />
        </div>

        {/* Dynamic segmentation bounding boxes simulating computer vision */}
        <div className="absolute top-1/4 left-1/3 w-16 h-16 border-2 border-amber-400/80 rounded-lg animate-pulse" />
        <div className="absolute top-1/4 left-1/3 -mt-4 text-[9px] font-mono text-amber-300 font-bold bg-black/70 px-1 rounded">
          Lesion #1 (89%)
        </div>

        <div className="absolute bottom-1/4 right-1/4 w-12 h-12 border-2 border-emerald-400/80 rounded-lg" />

        {/* Center Progress HUD */}
        <div className="absolute bottom-2 left-2 right-2 bg-black/70 backdrop-blur-xs text-white text-[11px] font-mono px-2 py-1 rounded-xl flex items-center justify-between">
          <span className="text-emerald-300 flex items-center gap-1">
            <Activity className="w-3.5 h-3.5 animate-spin" />
            <span>Multi-modal Tensor</span>
          </span>
          <span className="font-bold">
            {Math.round(((activeStepIndex + 1) / steps.length) * 100)}%
          </span>
        </div>
      </div>

      {/* Main Title */}
      <div className="text-center space-y-1">
        <h2 className="text-2xl font-black text-gray-900 font-['Outfit'] flex items-center justify-center gap-2">
          <Sparkles className="w-5 h-5 text-emerald-600 animate-spin" />
          <span>Understanding your crop…</span>
        </h2>
        <p className="text-xs text-gray-500">
          Synthesizing visual symptoms with local microclimate data
        </p>
      </div>

      {/* Sequential 8-Step Pipeline Checklist */}
      <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm space-y-2 max-w-sm mx-auto w-full">
        {steps.map((step, idx) => {
          const isDone = idx < activeStepIndex;
          const isCurrent = idx === activeStepIndex;
          return (
            <div
              key={step.id}
              className={`flex items-center justify-between text-xs py-1 px-2 rounded-lg transition-colors ${
                isCurrent
                  ? 'bg-emerald-50 text-emerald-950 font-bold'
                  : isDone
                  ? 'text-gray-700'
                  : 'text-gray-400'
              }`}
            >
              <div className="flex items-center gap-2">
                <span className="font-mono text-[10px] text-gray-400 font-semibold">
                  {step.id}
                </span>
                <span className="truncate">{step.title}</span>
              </div>
              <div>
                {isDone ? (
                  <span className="w-4 h-4 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px]">
                    <Check className="w-3 h-3 stroke-[3]" />
                  </span>
                ) : isCurrent ? (
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                ) : (
                  <span className="w-2 h-2 rounded-full bg-gray-200" />
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
