import React, { useState, useRef } from 'react';
import {
  Camera,
  Upload,
  Sun,
  Maximize2,
  Sparkles,
  Eye,
  AlertCircle,
  CheckCircle2,
  RefreshCw,
  Layers,
  ArrowLeft
} from 'lucide-react';
import { AppScreen, ScanRecord } from '../../types';
import { PRESET_SCENARIOS } from '../../data/mockData';

interface ScanCropScreenProps {
  onImageCaptured: (imageSrc: string, customData?: Partial<ScanRecord>) => void;
  onBack: () => void;
}

export const ScanCropScreen: React.FC<ScanCropScreenProps> = ({ onImageCaptured, onBack }) => {
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [isWholePlantMode, setIsWholePlantMode] = useState(false);
  const [selectedPreset, setSelectedPreset] = useState<string>('cotton_leaf_spot');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const samplePresets = [
    {
      id: 'cotton_leaf_spot',
      label: 'Cotton Leaf (Early Spot)',
      url: PRESET_SCENARIOS.default_early_leaf_spot.imageUrl,
      data: PRESET_SCENARIOS.default_early_leaf_spot
    },
    {
      id: 'wheat_healthy',
      label: 'Wheat (Healthy Canopy)',
      url: PRESET_SCENARIOS.healthy_wheat.imageUrl,
      data: PRESET_SCENARIOS.healthy_wheat
    },
    {
      id: 'rice_chlorosis',
      label: 'Rice Leaf (Zinc Deficiency)',
      url: PRESET_SCENARIOS.nutrient_deficiency_rice.imageUrl,
      data: PRESET_SCENARIOS.nutrient_deficiency_rice
    },
    {
      id: 'tomato_blight',
      label: 'Tomato Leaf (Late Blight)',
      url: PRESET_SCENARIOS.severe_late_blight_tomato.imageUrl,
      data: PRESET_SCENARIOS.severe_late_blight_tomato
    },
    {
      id: 'unknown_sample',
      label: 'Unusual Leaf (Unknown Anomaly)',
      url: PRESET_SCENARIOS.unknown_condition.imageUrl,
      data: PRESET_SCENARIOS.unknown_condition
    }
  ];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        onImageCaptured(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCaptureSample = () => {
    const current = samplePresets.find((p) => p.id === selectedPreset) || samplePresets[0];
    onImageCaptured(current.url, current.data);
  };

  return (
    <div className="max-w-xl mx-auto px-4 py-4 sm:py-6 space-y-5 animate-fadeIn">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="p-1.5 rounded-lg text-gray-600 hover:bg-gray-100"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-gray-900 font-['Outfit']">
              Check your crop
            </h2>
            <p className="text-xs text-gray-500">
              Capture or upload affected leaf for multimodal health analysis
            </p>
          </div>
        </div>

        {/* Analyze entire plant switch */}
        <button
          onClick={() => setIsWholePlantMode(!isWholePlantMode)}
          className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold border transition-all flex items-center gap-1.5 ${
            isWholePlantMode
              ? 'bg-[#1B4332] text-white border-[#1B4332]'
              : 'bg-white text-gray-600 border-gray-300 hover:bg-gray-50'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>{isWholePlantMode ? 'Whole Plant' : 'Single Leaf'}</span>
        </button>
      </div>

      {/* Main Camera Viewport Area */}
      <div className="relative w-full aspect-[4/3] sm:aspect-[16/11] bg-[#0E1F16] rounded-3xl overflow-hidden border-2 border-emerald-600/40 shadow-xl flex flex-col justify-between p-4">
        {/* Active leaf sample preview or camera feed */}
        <img
          src={samplePresets.find((p) => p.id === selectedPreset)?.url}
          alt="Target crop foliage"
          className="absolute inset-0 w-full h-full object-cover opacity-80"
        />

        {/* Viewfinder Overlay & Framing Grid */}
        <div className="absolute inset-0 pointer-events-none p-4 sm:p-6 flex flex-col justify-between">
          {/* Top Status inside viewfinder */}
          <div className="flex items-center justify-between z-10">
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-xs text-emerald-300 text-[11px] font-mono font-medium">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>AI SCAN READY</span>
            </span>

            <span className="px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-xs text-white text-[11px] font-mono">
              {isWholePlantMode ? 'Canopy Mode' : 'Leaf Targeting'}
            </span>
          </div>

          {/* Central Botanical Reticle with Corner Brackets */}
          <div className="relative w-48 h-48 sm:w-60 sm:h-60 mx-auto my-auto flex items-center justify-center">
            {/* 4 Corner Markers */}
            <div className="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 border-emerald-400" />
            <div className="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-emerald-400" />
            <div className="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-emerald-400" />
            <div className="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 border-emerald-400" />

            {/* Subtle center crosshair */}
            <div className="w-8 h-8 border border-dashed border-emerald-300/60 rounded-full flex items-center justify-center animate-pulse">
              <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full" />
            </div>

            {/* Subtle guidance text inside reticle */}
            <div className="absolute bottom-2 text-center text-[10px] text-white/90 bg-black/50 px-2 py-0.5 rounded backdrop-blur-xs">
              Frame leaf lesions here
            </div>
          </div>

          {/* Bottom viewfinder instruction */}
          <div className="z-10 text-center text-xs text-white font-medium bg-black/60 backdrop-blur-xs py-1.5 px-3 rounded-xl max-w-sm mx-auto">
            Capture a clear image of the affected leaf or plant.
          </div>
        </div>
      </div>

      {/* Preset Leaf Selector for Realistic Evaluation */}
      <div className="bg-white p-3 rounded-2xl border border-gray-200">
        <label className="block text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-2 font-mono">
          Or Select Real Field Test Image:
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {samplePresets.map((preset) => (
            <button
              key={preset.id}
              onClick={() => setSelectedPreset(preset.id)}
              className={`p-2 rounded-xl text-left border transition-all text-xs flex items-center gap-2 ${
                selectedPreset === preset.id
                  ? 'bg-emerald-50 border-emerald-600 font-bold text-emerald-950 shadow-2xs'
                  : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
              }`}
            >
              <img
                src={preset.url}
                alt={preset.label}
                className="w-7 h-7 rounded-lg object-cover shrink-0"
              />
              <span className="truncate">{preset.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Primary Capture Action Buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
        {/* Take Photo Button */}
        <button
          onClick={handleCaptureSample}
          className="py-4 px-6 rounded-2xl bg-gradient-to-r from-[#1B4332] to-[#2D6A4F] hover:from-[#143527] hover:to-[#22553E] text-white font-bold text-base shadow-lg shadow-emerald-950/20 flex items-center justify-center gap-2.5 transition-all active:scale-98"
        >
          <Camera className="w-5 h-5 text-emerald-300" />
          <span>TAKE PHOTO</span>
        </button>

        {/* Upload Image Button */}
        <button
          onClick={() => fileInputRef.current?.click()}
          className="py-4 px-6 rounded-2xl bg-white hover:bg-gray-50 text-gray-800 font-bold text-base border-2 border-gray-300 hover:border-gray-400 shadow-xs flex items-center justify-center gap-2.5 transition-all active:scale-98"
        >
          <Upload className="w-5 h-5 text-gray-600" />
          <span>UPLOAD IMAGE</span>
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleFileUpload}
        />
      </div>

      {/* Field Photography Tips (Visually Designed) */}
      <div className="bg-[#F4F8F5] p-4 rounded-2xl border border-emerald-100 space-y-2">
        <h4 className="text-xs font-bold text-emerald-900 uppercase tracking-wider font-mono">
          Field Capture Best Practices:
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-gray-700">
          <div className="flex items-center gap-2">
            <Sun className="w-4 h-4 text-amber-600 shrink-0" />
            <span>Use diffuse natural morning/evening light</span>
          </div>
          <div className="flex items-center gap-2">
            <Eye className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Keep targeted leaf flat and in sharp focus</span>
          </div>
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-blue-600 shrink-0" />
            <span>Avoid deep shadows from your phone body</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Capture both healthy and affected foliage</span>
          </div>
        </div>
      </div>
    </div>
  );
};
