import React from 'react';
import { X, CheckCircle2, AlertTriangle, HelpCircle, ShieldAlert, Sparkles, WifiOff } from 'lucide-react';
import { ScanRecord } from '../../types';
import { PRESET_SCENARIOS } from '../../data/mockData';

interface ScenarioModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeScenarioId: string;
  onSelectScenario: (scenario: ScanRecord) => void;
  isOffline: boolean;
  onToggleOffline: () => void;
}

export const ScenarioModal: React.FC<ScenarioModalProps> = ({
  isOpen,
  onClose,
  activeScenarioId,
  onSelectScenario,
  isOffline,
  onToggleOffline
}) => {
  if (!isOpen) return null;

  const scenarios = [
    {
      data: PRESET_SCENARIOS.default_early_leaf_spot,
      badge: 'Signature Case',
      badgeColor: 'bg-amber-100 text-amber-800',
      icon: AlertTriangle,
      tag: 'Cotton &bull; Early Leaf Spot (74/100) &bull; 72% Progression Risk'
    },
    {
      data: PRESET_SCENARIOS.healthy_wheat,
      badge: 'Healthy Baseline',
      badgeColor: 'bg-emerald-100 text-emerald-800',
      icon: CheckCircle2,
      tag: 'Wheat &bull; Optimal Canopy (94/100) &bull; Low Environmental Risk'
    },
    {
      data: PRESET_SCENARIOS.nutrient_deficiency_rice,
      badge: 'Deficiency Differentiation',
      badgeColor: 'bg-blue-100 text-blue-800',
      icon: Sparkles,
      tag: 'Rice &bull; Zinc & Nitrogen Chlorosis (62/100) &bull; Non-pathogenic'
    },
    {
      data: PRESET_SCENARIOS.severe_late_blight_tomato,
      badge: 'Critical Outbreak',
      badgeColor: 'bg-red-100 text-red-800',
      icon: ShieldAlert,
      tag: 'Tomato &bull; Late Blight (42/100) &bull; Severe Necrosis &bull; Immediate Action'
    },
    {
      data: PRESET_SCENARIOS.unknown_condition,
      badge: 'Safety Edge Case',
      badgeColor: 'bg-purple-100 text-purple-800',
      icon: HelpCircle,
      tag: 'Cotton &bull; Unknown Condition (38% Conf) &bull; Refuses False Diagnosis'
    },
    {
      data: PRESET_SCENARIOS.low_confidence,
      badge: 'Quality Alert',
      badgeColor: 'bg-amber-100 text-amber-800',
      icon: AlertTriangle,
      tag: 'Cotton &bull; Sub-optimal Lighting & Shadow (48% Conf) &bull; Expert Review Prompt'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden border border-gray-100">
        {/* Header */}
        <div className="p-4 bg-[#1B4332] text-white flex items-center justify-between">
          <div>
            <h3 className="font-bold text-base font-['Outfit'] flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-300" />
              <span>Interactive Evaluation Scenarios</span>
            </h3>
            <p className="text-xs text-emerald-200 mt-0.5">
              Switch between research-backed agricultural conditions & edge cases
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-emerald-200 hover:text-white hover:bg-[#254A39]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content list */}
        <div className="p-4 overflow-y-auto space-y-3 flex-1">
          {/* Offline Mode Switch */}
          <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-amber-100 text-amber-800 rounded-lg">
                <WifiOff className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-amber-900">Simulate Rural Offline Mode</h4>
                <p className="text-[11px] text-amber-700">Tests low-connectivity queuing and local storage</p>
              </div>
            </div>
            <button
              onClick={onToggleOffline}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors ${
                isOffline
                  ? 'bg-amber-600 text-white'
                  : 'bg-white text-gray-700 border border-gray-300'
              }`}
            >
              {isOffline ? 'ACTIVE' : 'OFF'}
            </button>
          </div>

          <div className="text-xs font-bold text-gray-400 uppercase tracking-wider px-1 pt-1">
            Crop Health Scenarios
          </div>

          {scenarios.map((sc, i) => {
            const isSelected = activeScenarioId === sc.data.id;
            const Icon = sc.icon;
            return (
              <div
                key={i}
                onClick={() => {
                  onSelectScenario(sc.data);
                  onClose();
                }}
                className={`p-3 rounded-xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'border-emerald-600 bg-emerald-50/70 ring-1 ring-emerald-500 shadow-sm'
                    : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div className={`p-1.5 rounded-lg ${isSelected ? 'bg-emerald-600 text-white' : 'bg-gray-100 text-gray-700'}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <span className={`inline-block px-1.5 py-0.5 text-[10px] font-bold rounded ${sc.badgeColor}`}>
                        {sc.badge}
                      </span>
                      <h4 className="text-xs font-bold text-gray-900 mt-0.5">
                        {sc.data.primaryFinding}
                      </h4>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-extrabold text-gray-800">
                      {sc.data.healthScore}/100
                    </span>
                    <span className="block text-[10px] text-gray-500">
                      {sc.data.severityPercent}% sev
                    </span>
                  </div>
                </div>
                <p className="text-[11px] text-gray-600 mt-1.5" dangerouslySetInnerHTML={{ __html: sc.tag }} />
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-3 bg-gray-50 border-t border-gray-100 flex items-center justify-between text-xs text-gray-500">
          <span>Demonstrates complete diagnostic pipeline</span>
          <button
            onClick={onClose}
            className="px-3 py-1.5 bg-[#1B4332] text-white rounded-lg text-xs font-medium"
          >
            Apply & View
          </button>
        </div>
      </div>
    </div>
  );
};
