import React from 'react';
import {
  ArrowLeft,
  WifiOff,
  Globe,
  Mic,
  Sparkles,
  Info,
  Layers,
  Bell,
  Settings
} from 'lucide-react';
import { AppScreen, SupportedLanguage, FarmerProfile } from '../../types';
import { TRANSLATIONS } from '../../data/translations';

interface TopAppBarProps {
  currentScreen?: AppScreen;
  onNavigate?: (screen: AppScreen) => void;
  language?: SupportedLanguage;
  currentLanguage?: SupportedLanguage;
  onOpenLanguage?: () => void;
  onOpenVoice?: () => void;
  farmerProfile?: FarmerProfile;
  farmerName?: string;
  location?: string;
  isOffline?: boolean;
  onToggleOffline?: () => void;
  onOpenScenarioModal?: () => void;
  onOpenSettings?: () => void;
  onOpenAlerts?: () => void;
  unreadAlertsCount?: number;
}

export const TopAppBar: React.FC<TopAppBarProps> = ({
  currentScreen = 'dashboard',
  onNavigate = (_screen: AppScreen) => {},
  language = 'en',
  currentLanguage,
  onOpenLanguage = () => {},
  onOpenVoice = () => {},
  farmerProfile,
  farmerName,
  location,
  isOffline = false,
  onToggleOffline = () => {},
  onOpenScenarioModal = () => {},
  onOpenSettings,
  onOpenAlerts,
  unreadAlertsCount = 3
}) => {
  const activeLang = language || currentLanguage || farmerProfile?.preferredLanguage || 'en';
  const t = TRANSLATIONS[activeLang] || TRANSLATIONS.en;
  const isHomeOrLanding = currentScreen === 'dashboard' || currentScreen === 'landing';

  return (
    <header className="sticky top-0 z-40 bg-[#173024] text-white shadow-md border-b border-[#254A39]">
      {/* Offline Alert Bar if active */}
      {isOffline && (
        <div className="bg-amber-600 text-white text-xs px-3 py-1 text-center flex items-center justify-center gap-1.5 font-medium">
          <WifiOff className="w-3.5 h-3.5" />
          <span>Offline Field Mode Active &bull; Scans will sync upon network reconnect</span>
          <button
            onClick={onToggleOffline}
            className="underline ml-2 text-[11px] hover:text-amber-200"
          >
            Go Online
          </button>
        </div>
      )}

      <div className="max-w-6xl mx-auto px-3 sm:px-6 h-14 flex items-center justify-between gap-2">
        {/* Left Side: Back button or Brand */}
        <div className="flex items-center gap-2.5">
          {!isHomeOrLanding ? (
            <button
              onClick={() => onNavigate('dashboard')}
              className="p-1.5 -ml-1 text-emerald-100 hover:text-white hover:bg-[#224434] rounded-lg transition-colors flex items-center gap-1 text-sm"
              title="Return to Dashboard"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="hidden sm:inline font-medium">Dashboard</span>
            </button>
          ) : null}

          <div
            onClick={() => onNavigate('dashboard')}
            className="flex items-center gap-2 cursor-pointer select-none group"
          >
            {/* Custom Crop Doctor Icon: botanical leaf with dynamic pulse dot */}
            <div className="relative w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-400 to-emerald-600 p-0.5 flex items-center justify-center shadow-inner">
              <svg viewBox="0 0 24 24" className="w-5 h-5 text-[#0F241A] fill-current">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.4z" />
              </svg>
              <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-300 rounded-full animate-ping opacity-75" />
              <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-400 rounded-full border border-[#173024]" />
            </div>

            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-base tracking-wider text-white font-['Outfit']">
                  CROP <span className="text-emerald-400">DOCTOR</span>
                </span>
                <span className="hidden md:inline-block px-1.5 py-0.5 bg-[#254A39] text-emerald-300 text-[10px] font-semibold rounded tracking-wide border border-emerald-500/20">
                  HEALTH INTELLIGENCE
                </span>
              </div>
              <p className="text-[10px] text-emerald-200/80 -mt-0.5 tracking-tight font-medium hidden xs:block">
                See &bull; Understand &bull; Predict &bull; Act
              </p>
            </div>
          </div>
        </div>

        {/* Right Side: Quick controls */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Scenarios / Demos Button */}
          <button
            onClick={onOpenScenarioModal}
            className="flex items-center gap-1 px-2 sm:px-2.5 py-1 text-xs font-medium bg-[#224434] hover:bg-[#2C5642] text-emerald-200 hover:text-white rounded-lg border border-emerald-500/30 transition-all shadow-sm"
            title="Switch Sample Cases (Healthy, Leaf Spot, Deficiency, Unknown, Low Conf)"
          >
            <Layers className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Scenarios</span>
          </button>

          {/* Voice Assistant quick icon */}
          <button
            onClick={onOpenVoice}
            className="flex items-center gap-1 px-2 sm:px-2.5 py-1 text-xs font-medium bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 hover:text-white rounded-lg border border-emerald-500/40 transition-colors"
            title={t.voiceAssistant}
          >
            <Mic className="w-3.5 h-3.5 text-emerald-300 animate-pulse" />
            <span className="hidden md:inline">{t.voiceAssistant}</span>
          </button>

          {/* Language Switcher */}
          <button
            onClick={onOpenLanguage}
            className="flex items-center gap-1 px-2 py-1 text-xs font-medium bg-[#224434] hover:bg-[#2C5642] text-emerald-100 rounded-lg border border-emerald-500/20 transition-colors"
            title="Change Language"
          >
            <Globe className="w-3.5 h-3.5 text-emerald-400" />
            <span className="uppercase text-[11px] font-bold">{activeLang}</span>
          </button>

          {/* Alerts Notification Button */}
          {onOpenAlerts && (
            <button
              onClick={onOpenAlerts}
              className="relative p-1.5 rounded-lg border border-emerald-500/20 bg-[#224434] hover:bg-[#2C5642] text-emerald-100 hover:text-white transition-colors"
              title="Early Warning Alerts"
            >
              <Bell className="w-4 h-4 text-emerald-300" />
              {unreadAlertsCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-500 text-white font-bold text-[9px] flex items-center justify-center">
                  {unreadAlertsCount}
                </span>
              )}
            </button>
          )}

          {/* Settings Button */}
          {onOpenSettings && (
            <button
              onClick={onOpenSettings}
              className="p-1.5 rounded-lg border border-emerald-500/20 bg-[#224434] hover:bg-[#2C5642] text-emerald-100 hover:text-white transition-colors"
              title="Settings"
            >
              <Settings className="w-4 h-4 text-emerald-300" />
            </button>
          )}

          {/* Product Story / Landing View Link */}
          <button
            onClick={() => onNavigate(currentScreen === 'landing' ? 'dashboard' : 'landing')}
            className={`p-1.5 rounded-lg border transition-colors ${
              currentScreen === 'landing'
                ? 'bg-emerald-500 text-[#0F241A] border-emerald-400 font-semibold'
                : 'bg-[#224434] text-emerald-200 border-emerald-500/20 hover:text-white'
            }`}
            title="Product Story / Architecture Presentation"
          >
            <Sparkles className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
