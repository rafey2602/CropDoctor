import React from 'react';
import { Home, Camera, MapPin, Bell, User, Sparkles } from 'lucide-react';
import { AppScreen } from '../../types';

interface BottomNavigationProps {
  currentScreen: AppScreen;
  onNavigate: (screen: AppScreen) => void;
  unreadAlertsCount?: number;
}

export const BottomNavigation: React.FC<BottomNavigationProps> = ({
  currentScreen,
  onNavigate,
  unreadAlertsCount = 3
}) => {
  const isScanActive = currentScreen === 'scan' || currentScreen === 'quality-check' || currentScreen === 'analysis-loading';

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-emerald-950/10 shadow-lg md:hidden">
      <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-between relative">
        {/* Home */}
        <button
          onClick={() => onNavigate('dashboard')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            currentScreen === 'dashboard'
              ? 'text-[#2D6A4F] font-bold'
              : 'text-gray-500 hover:text-gray-800'
          }`}
        >
          <Home className={`w-5 h-5 ${currentScreen === 'dashboard' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[11px] mt-0.5">Home</span>
        </button>

        {/* Crops / Field Map */}
        <button
          onClick={() => onNavigate('field-map')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            currentScreen === 'field-map' || currentScreen === 'history' || currentScreen === 'timeline'
              ? 'text-[#2D6A4F] font-bold'
              : 'text-gray-500 hover:text-gray-800'
          }`}
        >
          <MapPin className={`w-5 h-5 ${currentScreen === 'field-map' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[11px] mt-0.5">Field</span>
        </button>

        {/* Center Prominent Scan Button */}
        <div className="relative -top-5 flex-1 flex justify-center">
          <button
            onClick={() => onNavigate('scan')}
            className={`w-14 h-14 rounded-full flex flex-col items-center justify-center shadow-lg transition-transform active:scale-95 ${
              isScanActive
                ? 'bg-emerald-600 text-white ring-4 ring-emerald-200'
                : 'bg-gradient-to-tr from-[#1B4332] to-[#2D6A4F] text-white ring-4 ring-white shadow-emerald-900/20'
            }`}
            title="Scan Crop"
          >
            <Camera className="w-6 h-6 animate-pulse" />
            <span className="text-[9px] font-extrabold tracking-wider uppercase">SCAN</span>
          </button>
        </div>

        {/* Alerts */}
        <button
          onClick={() => onNavigate('alerts')}
          className={`flex flex-col items-center justify-center flex-1 py-1 relative transition-colors ${
            currentScreen === 'alerts'
              ? 'text-[#2D6A4F] font-bold'
              : 'text-gray-500 hover:text-gray-800'
          }`}
        >
          <div className="relative">
            <Bell className={`w-5 h-5 ${currentScreen === 'alerts' ? 'stroke-[2.5]' : 'stroke-2'}`} />
            {unreadAlertsCount > 0 && (
              <span className="absolute -top-1 -right-1.5 w-4 h-4 bg-amber-500 text-white rounded-full text-[9px] font-bold flex items-center justify-center">
                {unreadAlertsCount}
              </span>
            )}
          </div>
          <span className="text-[11px] mt-0.5">Alerts</span>
        </button>

        {/* Assistant / Profile */}
        <button
          onClick={() => onNavigate('assistant')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            currentScreen === 'assistant' || currentScreen === 'profile'
              ? 'text-[#2D6A4F] font-bold'
              : 'text-gray-500 hover:text-gray-800'
          }`}
        >
          <Sparkles className={`w-5 h-5 ${currentScreen === 'assistant' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[11px] mt-0.5">Ask AI</span>
        </button>
      </div>
    </nav>
  );
};
