import React from 'react';
import {
  LayoutDashboard,
  Camera,
  Layers,
  Activity,
  History,
  MapPin,
  Bell,
  Bot,
  FileSpreadsheet,
  UserCheck,
  Settings,
  CloudSun,
  ShieldCheck,
  Sparkles,
  HelpCircle
} from 'lucide-react';
import { AppScreen, FarmerProfile } from '../../types';

interface DesktopSidebarProps {
  currentScreen: AppScreen;
  onNavigate: (screen: AppScreen) => void;
  farmerProfile?: FarmerProfile;
  unreadAlertsCount?: number;
  notificationCount?: number;
}

export const DesktopSidebar: React.FC<DesktopSidebarProps> = ({
  currentScreen,
  onNavigate,
  farmerProfile,
  unreadAlertsCount,
  notificationCount = 3
}) => {
  const alertsBadge = unreadAlertsCount ?? notificationCount;
  const navSections = [
    {
      title: 'CORE INTELLIGENCE',
      items: [
        { id: 'dashboard' as AppScreen, label: 'Crop Doctor Dashboard', icon: LayoutDashboard },
        { id: 'scan' as AppScreen, label: 'Scan Leaf & Plant', icon: Camera, highlight: true },
        { id: 'result' as AppScreen, label: 'Diagnostic Findings', icon: Activity },
        { id: 'field-map' as AppScreen, label: 'Field Heat Map', icon: MapPin },
        { id: 'timeline' as AppScreen, label: 'Crop Health Timeline', icon: Activity },
      ]
    },
    {
      title: 'ANALYSIS & DECISION',
      items: [
        { id: 'differential' as AppScreen, label: 'Differential Diagnosis', icon: Layers },
        { id: 'severity' as AppScreen, label: 'Severity Scale', icon: Activity },
        { id: 'explainable-ai' as AppScreen, label: 'Explainable AI', icon: HelpCircle },
        { id: 'progression' as AppScreen, label: 'Progression Risk', icon: Activity },
        { id: 'weather' as AppScreen, label: 'Weather & Microclimate', icon: CloudSun },
        { id: 'actions' as AppScreen, label: 'Prioritized Actions', icon: ShieldCheck },
        { id: 'treatment' as AppScreen, label: 'Treatment Options', icon: ShieldCheck },
      ]
    },
    {
      title: 'MANAGEMENT & ASSISTANT',
      items: [
        { id: 'alerts' as AppScreen, label: 'Early Warnings', icon: Bell, badge: alertsBadge },
        { id: 'assistant' as AppScreen, label: 'AI Crop Assistant', icon: Bot },
        { id: 'history' as AppScreen, label: 'Scans History', icon: History },
        { id: 'report' as AppScreen, label: 'Export Health Report', icon: FileSpreadsheet },
        { id: 'expert-verification' as AppScreen, label: 'Expert Consultation', icon: UserCheck },
        { id: 'farmer-profile' as AppScreen, label: 'Farmer Profile', icon: UserCheck },
        { id: 'settings' as AppScreen, label: 'Preferences & Settings', icon: Settings },
      ]
    }
  ];

  return (
    <aside className="hidden md:flex flex-col w-64 lg:w-72 bg-white border-r border-gray-200 shrink-0 h-[calc(100vh-3.5rem)] sticky top-14 overflow-y-auto">
      {/* Farmer Active Crop Badge */}
      <div className="p-4 border-b border-gray-100 bg-[#F4F8F5]">
        <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
          <span>ACTIVE MONITORING</span>
          <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" /> Live
          </span>
        </div>
        <p className="font-bold text-gray-800 text-sm leading-tight">
          {farmerProfile?.crop || 'Cotton (Bt RCH-659)'}
        </p>
        <p className="text-xs text-gray-500 mt-0.5">
          {farmerProfile?.location || 'Panvel, Maharashtra'} &bull; {farmerProfile?.fieldSize || '4.5 Acres'}
        </p>
      </div>

      {/* Navigation Sections */}
      <div className="flex-1 px-3 py-4 space-y-5">
        {navSections.map((section, idx) => (
          <div key={idx} className="space-y-1">
            <h4 className="px-3 text-[10px] font-bold tracking-wider text-gray-400 uppercase font-mono">
              {section.title}
            </h4>
            {section.items.map((item) => {
              const Icon = item.icon;
              const isActive = currentScreen === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                    isActive
                      ? 'bg-[#1B4332] text-white shadow-sm'
                      : item.highlight
                      ? 'bg-emerald-50 text-emerald-900 hover:bg-emerald-100 font-semibold'
                      : 'text-gray-700 hover:bg-gray-100 hover:text-gray-900'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-300' : 'text-gray-500'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge ? (
                    <span className="px-1.5 py-0.2 bg-amber-500 text-white rounded-full text-[10px] font-bold">
                      {item.badge}
                    </span>
                  ) : null}
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {/* Bottom Mission Card */}
      <div className="p-3 m-3 bg-gradient-to-br from-[#1B4332] to-[#2D6A4F] text-white rounded-xl text-xs space-y-1 shadow-sm">
        <div className="flex items-center gap-1.5 text-emerald-300 font-semibold text-[11px]">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Early Action Engine</span>
        </div>
        <p className="text-[11px] text-emerald-100/90 leading-relaxed">
          Transforms disease classification into multi-factorial crop health intelligence.
        </p>
      </div>
    </aside>
  );
};
