import React from 'react';
import {
  Sparkles,
  Eye,
  Brain,
  TrendingUp,
  ShieldCheck,
  Camera,
  Activity,
  CloudSun,
  Layers,
  MapPin,
  Bot,
  UserCheck,
  ArrowRight,
  HelpCircle,
  AlertTriangle,
  CheckCircle2
} from 'lucide-react';
import { AppScreen } from '../../types';

interface ProductArchitectureScreenProps {
  onNavigate: (screen: AppScreen) => void;
}

export const ProductArchitectureScreen: React.FC<ProductArchitectureScreenProps> = ({ onNavigate }) => {
  const pillars = [
    {
      step: '01',
      action: 'SEE',
      title: 'Computer Vision & Lesion Detection',
      desc: 'High-resolution edge segmentation that isolates chlorotic halos, necrotic centers, and stomatal stress markers.',
      screen: 'scan' as AppScreen,
      cta: 'Launch Camera Scan',
      icon: Eye,
      color: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-800'
    },
    {
      step: '02',
      action: 'UNDERSTAND',
      title: 'Multimodal Sensor Fusion & Differential Matrix',
      desc: 'Differentiates pathogenic fungus from nutrient deficiency by synthesizing leaf imagery with humidity, temperature, and crop stage.',
      screen: 'differential' as AppScreen,
      cta: 'View Differential Matrix',
      icon: Brain,
      color: 'bg-blue-500/10 border-blue-500/30 text-blue-800'
    },
    {
      step: '03',
      action: 'PREDICT',
      title: 'Epidemiological 7-Day Progression Model',
      desc: 'Forecasts lesion expansion risk and potential yield impact if microclimate moisture supports spore germination.',
      screen: 'progression' as AppScreen,
      cta: 'Inspect Trajectory Curve',
      icon: TrendingUp,
      color: 'bg-amber-500/10 border-amber-500/30 text-amber-800'
    },
    {
      step: '04',
      action: 'ACT',
      title: 'Prioritized Action Engine & Safe Treatments',
      desc: 'Delivers ranked, step-by-step guidance: Do Now, Within 24 Hours, and Monitor, with biological & organic IPM remedies.',
      screen: 'actions' as AppScreen,
      cta: 'Deploy Action Engine',
      icon: ShieldCheck,
      color: 'bg-emerald-600/15 border-emerald-600/40 text-emerald-900'
    }
  ];

  const questions = [
    { q: '1. WHAT is happening?', a: 'Edge CV detects subtle lesions & symptoms before canopy yellowing becomes widespread.', target: 'severity' as AppScreen },
    { q: '2. WHY is it happening?', a: 'Multimodal context: 82% humidity, leaf wetness, and flowering stage susceptibility.', target: 'weather' as AppScreen },
    { q: '3. HOW SEVERE is it?', a: 'Quantitative canopy coverage estimate (e.g. 28% leaf surface area).', target: 'severity' as AppScreen },
    { q: '4. WHAT HAPPENS NEXT?', a: 'Dynamic 3-day and 7-day risk forecasting with yield impact prevention.', target: 'progression' as AppScreen },
    { q: '5. WHAT TO DO NOW?', a: 'Prioritized 1-2-3 countermeasure stack: Do Now, 24 Hours, Monitor.', target: 'actions' as AppScreen },
    { q: '6. IS AI CONFIDENT?', a: 'Uncertainty transparency + 1-tap Krishi Vigyan Kendra agronomist escalation.', target: 'expert-verification' as AppScreen }
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 sm:py-8 space-y-8 animate-fadeIn pb-24 md:pb-12">
      {/* Hero Presentation Banner */}
      <div className="bg-gradient-to-br from-[#0F261B] via-[#1B4332] to-[#2D6A4F] text-white p-6 sm:p-10 rounded-3xl shadow-xl relative overflow-hidden">
        <div className="relative z-10 space-y-3 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-400/20 text-emerald-300 text-xs font-mono font-bold tracking-wide border border-emerald-400/30">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400 animate-spin" />
            <span>CROP HEALTH INTELLIGENCE ARCHITECTURE</span>
          </div>

          <h1 className="text-3xl sm:text-4xl font-extrabold font-['Outfit'] tracking-tight leading-tight">
            See. Understand. Predict. Act.
          </h1>

          <p className="text-sm sm:text-base text-emerald-100/90 leading-relaxed font-normal">
            Transforming reactive plant disease detection into a predictive early-action system. Crop Doctor combines computer vision, weather telemetry, crop stage modeling, and certified agronomist oversight.
          </p>

          <div className="pt-3 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('dashboard')}
              className="py-3 px-6 rounded-xl bg-white text-[#0F261B] font-bold text-xs sm:text-sm hover:bg-emerald-50 transition-all shadow-md flex items-center gap-2 active:scale-98"
            >
              <span>Go to Live Dashboard</span>
              <ArrowRight className="w-4 h-4 text-emerald-700" />
            </button>

            <button
              onClick={() => onNavigate('scan')}
              className="py-3 px-5 rounded-xl bg-emerald-500/25 hover:bg-emerald-500/35 text-white font-bold text-xs sm:text-sm border border-emerald-400/40 transition-all flex items-center gap-2"
            >
              <Camera className="w-4 h-4 text-emerald-300" />
              <span>Simulate Leaf Scan</span>
            </button>
          </div>
        </div>

        {/* Ambient watermark icon */}
        <div className="absolute -bottom-10 -right-10 opacity-10 pointer-events-none text-white">
          <Activity className="w-72 h-72" />
        </div>
      </div>

      {/* 4 Architectural Pillars */}
      <div>
        <div className="mb-4">
          <span className="text-[11px] font-mono font-bold text-emerald-800 uppercase tracking-wider">
            THE 4-STAGE INTELLIGENCE PIPELINE
          </span>
          <h2 className="text-2xl font-black text-gray-900 font-['Outfit'] mt-0.5">
            Beyond Simple Image Classification
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {pillars.map((p) => {
            const Icon = p.icon;
            return (
              <div
                key={p.step}
                className="bg-white p-5 rounded-2xl border border-gray-200 shadow-2xs hover:border-emerald-500 hover:shadow-xs transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="px-2.5 py-1 rounded-lg bg-gray-100 text-gray-800 font-mono font-black text-xs">
                      {p.step} &bull; {p.action}
                    </span>
                    <div className={`p-2 rounded-xl border ${p.color}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                  </div>

                  <h3 className="text-base font-bold text-gray-900 font-['Outfit'] mb-1">
                    {p.title}
                  </h3>
                  <p className="text-xs text-gray-600 leading-relaxed mb-4">
                    {p.desc}
                  </p>
                </div>

                <button
                  onClick={() => onNavigate(p.screen)}
                  className="w-full py-2.5 px-3 rounded-xl bg-gray-50 hover:bg-emerald-50 text-gray-800 hover:text-emerald-900 border border-gray-200 hover:border-emerald-200 text-xs font-bold transition-all flex items-center justify-center gap-1.5"
                >
                  <span>{p.cta}</span>
                  <ArrowRight className="w-3.5 h-3.5 text-emerald-600" />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* The 6 Fundamental Questions */}
      <div className="bg-white p-6 sm:p-7 rounded-3xl border border-gray-200 shadow-sm space-y-4">
        <div>
          <span className="text-[11px] font-mono font-bold text-gray-400 uppercase tracking-wider">
            PRODUCT CORE DIRECTIVE
          </span>
          <h3 className="text-xl font-black text-gray-900 font-['Outfit'] mt-0.5">
            The 6 Questions Crop Doctor Answers
          </h3>
          <p className="text-xs text-gray-500">
            Click any question to experience that exact analytical dimension in the live application.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {questions.map((item, idx) => (
            <div
              key={idx}
              onClick={() => onNavigate(item.target)}
              className="p-3.5 rounded-xl border border-gray-200 hover:border-emerald-500 hover:bg-emerald-50/40 transition-all cursor-pointer group flex items-start justify-between gap-3"
            >
              <div>
                <span className="text-xs font-black text-emerald-950 font-['Outfit'] block group-hover:text-emerald-700 transition-colors">
                  {item.q}
                </span>
                <p className="text-xs text-gray-600 mt-0.5 leading-relaxed">
                  {item.a}
                </p>
              </div>
              <ArrowRight className="w-4 h-4 text-gray-300 group-hover:text-emerald-600 shrink-0 mt-1 transition-colors" />
            </div>
          ))}
        </div>
      </div>

      {/* Quick Navigation Directory Grid */}
      <div className="bg-gray-50 p-6 rounded-3xl border border-gray-200 space-y-3">
        <h4 className="text-xs font-bold text-gray-700 uppercase font-mono tracking-wider">
          Explore All Crop Doctor Modules:
        </h4>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
          <button
            onClick={() => onNavigate('field-map')}
            className="p-3 rounded-xl bg-white border border-gray-200 hover:border-emerald-500 text-left transition-all"
          >
            <MapPin className="w-4 h-4 text-emerald-600 mb-1" />
            <strong className="block text-gray-900">Spatial Heat Map</strong>
            <span className="text-[10px] text-gray-500">Precision quadrants</span>
          </button>

          <button
            onClick={() => onNavigate('timeline')}
            className="p-3 rounded-xl bg-white border border-gray-200 hover:border-emerald-500 text-left transition-all"
          >
            <Activity className="w-4 h-4 text-blue-600 mb-1" />
            <strong className="block text-gray-900">Health Timeline</strong>
            <span className="text-[10px] text-gray-500">30-day recovery arc</span>
          </button>

          <button
            onClick={() => onNavigate('assistant')}
            className="p-3 rounded-xl bg-white border border-gray-200 hover:border-emerald-500 text-left transition-all"
          >
            <Bot className="w-4 h-4 text-purple-600 mb-1" />
            <strong className="block text-gray-900">AI Agronomist</strong>
            <span className="text-[10px] text-gray-500">Voice & chat advisory</span>
          </button>

          <button
            onClick={() => onNavigate('report')}
            className="p-3 rounded-xl bg-white border border-gray-200 hover:border-emerald-500 text-left transition-all"
          >
            <ShieldCheck className="w-4 h-4 text-amber-600 mb-1" />
            <strong className="block text-gray-900">Audit Report</strong>
            <span className="text-[10px] text-gray-500">WhatsApp & PDF share</span>
          </button>
        </div>
      </div>
    </div>
  );
};
