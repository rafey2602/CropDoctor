import React, { useState } from 'react';
import { Bot, Send, Mic, Sparkles, User, ArrowRight, ShieldCheck, CornerDownLeft } from 'lucide-react';
import { MOCK_CHAT_MESSAGES } from '../../data/mockData';
import { ChatMessage, SupportedLanguage } from '../../types';

interface AIAssistantScreenProps {
  onOpenVoice: () => void;
  preferredLanguage: SupportedLanguage;
}

export const AIAssistantScreen: React.FC<AIAssistantScreenProps> = ({
  onOpenVoice,
  preferredLanguage
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>(MOCK_CHAT_MESSAGES);
  const [inputText, setInputText] = useState('');

  const quickPrompts = [
    'Can I spray fungicide today with rain expected?',
    'What causes yellowing in cotton leaves?',
    'How do I differentiate leaf spot from zinc deficiency?',
    'What organic remedies work best for fungal leaf spot?'
  ];

  const handleSend = (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text.trim()) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: text,
      timestamp: 'Just now'
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');

    // Simulate agronomic AI response
    setTimeout(() => {
      let reply =
        'Based on your current field parameters in Panvel (82% humidity, 28°C, and rain expected in 36 hours), applying systemic chemical sprays today carries a 40% risk of rainwater wash-off. We recommend inspecting Plot C lower leaves first and applying biological Trichoderma viride or neem formulation during evening hours when dew drying permits.';
      if (text.toLowerCase().includes('spray')) {
        reply =
          'Spraying is NOT recommended within 6 hours of expected showers. If you must apply a protectant spray, use an organic adherence formulation (spreader/sticker agent) during late afternoon when wind speeds stay below 12 km/h.';
      } else if (text.toLowerCase().includes('zinc') || text.toLowerCase().includes('yellow')) {
        reply =
          'Fungal leaf spot creates defined circular necrotic lesions with dark/purplish halos. Zinc deficiency, by contrast, causes interveinal chlorosis (yellowing between veins) on younger upper leaves without discrete circular dead tissue.';
      }

      const botMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: reply,
        timestamp: 'Just now'
      };
      setMessages((prev) => [...prev, botMsg]);
    }, 600);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-4 sm:py-6 space-y-4 animate-fadeIn pb-24 md:pb-12 h-[calc(100vh-140px)] flex flex-col justify-between">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-gray-200 pb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-bold text-gray-900 font-['Outfit']">
              AI Agricultural Agronomist
            </h2>
            <p className="text-xs text-gray-500">
              Field-aware advisory &bull; Calibrated to Panvel cotton crop
            </p>
          </div>
        </div>

        {/* Voice Trigger Button */}
        <button
          onClick={onOpenVoice}
          className="px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold border border-emerald-200 flex items-center gap-1.5 transition-colors"
        >
          <Mic className="w-3.5 h-3.5 text-emerald-600 animate-pulse" />
          <span>Speak Now</span>
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto space-y-3.5 pr-1 text-xs sm:text-sm">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex items-start gap-2.5 ${
              msg.sender === 'user' ? 'justify-end' : 'justify-start'
            }`}
          >
            {msg.sender === 'ai' && (
              <div className="w-7 h-7 rounded-lg bg-[#1B4332] text-white flex items-center justify-center shrink-0 mt-0.5">
                <Bot className="w-4 h-4" />
              </div>
            )}

            <div
              className={`p-3.5 rounded-2xl max-w-[85%] sm:max-w-[75%] leading-relaxed ${
                msg.sender === 'user'
                  ? 'bg-[#1B4332] text-white rounded-br-xs'
                  : 'bg-white text-gray-800 rounded-bl-xs border border-gray-200 shadow-2xs'
              }`}
            >
              <p>{msg.text}</p>
              <span
                className={`text-[9px] block mt-1 ${
                  msg.sender === 'user' ? 'text-emerald-200 text-right' : 'text-gray-400'
                }`}
              >
                {msg.timestamp}
              </span>
            </div>

            {msg.sender === 'user' && (
              <div className="w-7 h-7 rounded-lg bg-gray-200 text-gray-700 flex items-center justify-center shrink-0 mt-0.5">
                <User className="w-4 h-4" />
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Suggested Quick Prompts */}
      <div className="space-y-1.5 pt-1">
        <span className="text-[10px] font-mono text-gray-400 uppercase font-bold">
          Suggested Field Questions:
        </span>
        <div className="flex gap-2 overflow-x-auto pb-1.5 no-scrollbar">
          {quickPrompts.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(prompt)}
              className="text-xs px-3 py-1.5 rounded-full bg-white border border-gray-200 text-gray-700 hover:border-emerald-500 hover:bg-emerald-50/50 whitespace-nowrap transition-all shrink-0"
            >
              {prompt}
            </button>
          ))}
        </div>
      </div>

      {/* Input Bar */}
      <div className="relative flex items-center gap-2 bg-white p-2 rounded-2xl border border-gray-200 shadow-sm">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Ask about symptoms, pesticides, weather..."
          className="flex-1 px-3 py-2 text-xs sm:text-sm outline-none text-gray-900"
        />

        <button
          onClick={onOpenVoice}
          className="p-2 rounded-xl text-gray-500 hover:text-emerald-700 hover:bg-gray-100 transition-colors"
          title="Voice input"
        >
          <Mic className="w-5 h-5" />
        </button>

        <button
          onClick={() => handleSend()}
          disabled={!inputText.trim()}
          className={`p-2.5 rounded-xl text-white transition-all ${
            inputText.trim()
              ? 'bg-[#1B4332] hover:bg-[#255742] shadow-xs'
              : 'bg-gray-300 cursor-not-allowed'
          }`}
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
