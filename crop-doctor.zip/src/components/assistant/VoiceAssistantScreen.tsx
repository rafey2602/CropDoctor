import React, { useState, useEffect } from 'react';
import { Mic, X, Volume2, Sparkles, CheckCircle2, Bot } from 'lucide-react';
import { SupportedLanguage } from '../../types';

interface VoiceAssistantScreenProps {
  isOpen: boolean;
  onClose: () => void;
  language: SupportedLanguage;
}

export const VoiceAssistantScreen: React.FC<VoiceAssistantScreenProps> = ({
  isOpen,
  onClose,
  language
}) => {
  const [isListening, setIsListening] = useState(true);
  const [transcript, setTranscript] = useState('');
  const [spokenAnswer, setSpokenAnswer] = useState('');

  const sampleVoicePrompts: Record<SupportedLanguage, { query: string; answer: string; langLabel: string }> = {
    hi: {
      langLabel: 'हिन्दी',
      query: 'क्या आज कपास में दवा छिड़कना सुरक्षित है?',
      answer: 'आज हवा में 82% नमी है और अगले 36 घंटों में बारिश की संभावना है। अभी कोई भी रासायनिक छिड़काव न करें, दवा धुल जाएगी।'
    },
    mr: {
      langLabel: 'मराठी',
      query: 'माझ्या कपाशीच्या पानांवर तपकिरी ठिपके दिसत आहेत, मी काय करू?',
      answer: 'सध्या पानावरील ठिपके सुरुवातीच्या अवस्थेत (28%) आहेत. ट्रायकोडर्मा किंवा कडुनिंबाचे अर्क फवारा आणि जास्त पाणी देणे टाळा.'
    },
    en: {
      langLabel: 'English',
      query: 'Is it safe to spray fungicide today with rain expected?',
      answer: 'With 82% humidity and rain forecast within 36 hours, avoid chemical spraying today to prevent chemical wash-off. Inspect lower leaves and use organic biocontrol instead.'
    },
    ur: {
      langLabel: 'اردو',
      query: 'کیا آج کیڑے مار دوا کا چھڑکاؤ کرنا محفوظ ہے؟',
      answer: 'نمی بہت زیادہ ہے اور بارش متوقع ہے۔ بارش کے بعد ہی سپرے کریں تاکہ دوا ضائع نہ ہو۔'
    },
    gu: {
      langLabel: 'ગુજરાતી',
      query: 'શું આજે કપાસમાં સ્પ્રે કરી શકાય?',
      answer: 'આજે 82% ભેજ છે અને વરસાદની શક્યતા છે. કેમિકલ સ્પ્રે ટાળો અને ઓર્ગેનિક ટ્રાઇકોડર્મા વાપરો.'
    },
    ta: {
      langLabel: 'தமிழ்',
      query: 'இன்று மருந்து தெளிக்கலாமா?',
      answer: 'மழை பெய்ய வாய்ப்புள்ளதால் இன்று மருந்து தெளிப்பதை தவிர்க்கவும்.'
    },
    te: {
      langLabel: 'తెలుగు',
      query: 'ఈ రోజు పురుగుమందు పిచికారీ చేయవచ్చా?',
      answer: 'వర్షం కురిసే అవకాశం ఉన్నందున ఈరోజు రసాయన మందులు పిచికారీ చేయవద్దు.'
    },
    kn: {
      langLabel: 'ಕನ್ನಡ',
      query: 'ಇಂದು ಕೀಟನಾಶಕ ಸಿಂಪಡಿಸುವುದು ಸುರಕ್ಷಿತವೇ?',
      answer: 'ಮಳೆ ಬರುವ ಸಾಧ್ಯತೆ ಇರುವುದರಿಂದ ಇಂದು ಸಿಂಪಡಿಸಬೇಡಿ.'
    },
    bn: {
      langLabel: 'বাংলা',
      query: 'আজ কি ছত্রাকনাশক স্প্রে করা নিরাপদ?',
      answer: 'বৃষ্টির সম্ভাবনা থাকায় আজ স্প্রে না করাই ভালো।'
    }
  };

  const activeLang = sampleVoicePrompts[language] || sampleVoicePrompts.en;

  useEffect(() => {
    if (isOpen) {
      setIsListening(true);
      setTranscript('');
      setSpokenAnswer('');

      const t1 = setTimeout(() => {
        setTranscript(activeLang.query);
        setIsListening(false);
      }, 1800);

      const t2 = setTimeout(() => {
        setSpokenAnswer(activeLang.answer);
      }, 2600);

      return () => {
        clearTimeout(t1);
        clearTimeout(t2);
      };
    }
  }, [isOpen, language, activeLang.query, activeLang.answer]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-[#0E2016] text-white w-full max-w-md rounded-3xl p-6 sm:p-8 border border-emerald-500/30 relative flex flex-col items-center text-center space-y-6 shadow-2xl">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-gray-300 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Top Status */}
        <div className="space-y-1">
          <span className="text-[11px] font-mono uppercase tracking-wider text-emerald-300 flex items-center justify-center gap-1.5 font-bold">
            <Sparkles className="w-3.5 h-3.5" />
            VOICE AGRO-AI
          </span>
          <h3 className="text-xl font-bold font-['Outfit']">
            Listening in {activeLang.langLabel}…
          </h3>
          <p className="text-xs text-emerald-100/70">
            Speak naturally about your field, pests, or spray questions
          </p>
        </div>

        {/* Giant Pulsing Microphone */}
        <div className="relative my-4">
          {/* Animated pulse rings */}
          {isListening && (
            <>
              <div className="absolute inset-0 rounded-full bg-emerald-500/20 animate-ping" />
              <div className="absolute -inset-4 rounded-full bg-emerald-500/10 animate-pulse" />
            </>
          )}

          <div
            onClick={() => setIsListening(!isListening)}
            className={`w-28 h-28 rounded-full flex items-center justify-center cursor-pointer transition-all shadow-xl relative z-10 ${
              isListening
                ? 'bg-gradient-to-tr from-emerald-600 to-emerald-400 text-white shadow-emerald-500/50 scale-105'
                : 'bg-emerald-900/60 text-emerald-300 border-2 border-emerald-500/40'
            }`}
          >
            <Mic className="w-12 h-12 stroke-[2.5]" />
          </div>
        </div>

        {/* Audio Waveform Feedback */}
        <div className="flex items-center justify-center gap-1 h-8">
          {[40, 70, 95, 60, 80, 100, 65, 85, 50, 75, 45].map((height, idx) => (
            <span
              key={idx}
              className={`w-1 rounded-full transition-all duration-150 ${
                isListening ? 'bg-emerald-400 animate-pulse' : 'bg-emerald-800'
              }`}
              style={{ height: isListening ? `${height}%` : '20%' }}
            />
          ))}
        </div>

        {/* Visual Transcription Card */}
        <div className="w-full bg-white/5 border border-white/10 p-4 rounded-2xl text-left space-y-2">
          <div className="flex items-center justify-between text-[11px] text-emerald-300 font-mono">
            <span>YOU ASKED:</span>
            <span>{activeLang.langLabel}</span>
          </div>

          <p className="text-sm font-medium text-white italic">
            "{transcript || '“Listening to your voice...”'}"
          </p>

          {spokenAnswer && (
            <div className="mt-3 pt-3 border-t border-white/10 space-y-1">
              <span className="text-[11px] text-emerald-300 font-mono flex items-center gap-1 font-bold">
                <Volume2 className="w-3.5 h-3.5" />
                <span>AGRONOMIST SPOKEN ANSWER:</span>
              </span>
              <p className="text-xs sm:text-sm text-emerald-100 leading-relaxed font-sans">
                {spokenAnswer}
              </p>
            </div>
          )}
        </div>

        {/* Done Button */}
        <button
          onClick={onClose}
          className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-colors"
        >
          Close Voice Session
        </button>
      </div>
    </div>
  );
};
