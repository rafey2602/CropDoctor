import React from 'react';
import { Layers, CheckCircle2, ArrowRight, Info, AlertTriangle, ShieldCheck, HelpCircle } from 'lucide-react';
import { DIFFERENTIAL_DIAGNOSIS_DATA } from '../../data/mockData';
import { AppScreen } from '../../types';

interface DifferentialDiagnosisScreenProps {
  onNavigate: (screen: AppScreen) => void;
}

export const DifferentialDiagnosisScreen: React.FC<DifferentialDiagnosisScreenProps> = ({ onNavigate }) => {
  const evidenceList = [
    { text: 'Concentric brown necrotic lesions with purple halo detected on lamina', verified: true },
    { text: 'Symptom distribution concentrated on middle and lower canopy foliage', verified: true },
    { text: 'Microclimate humidity exceeding 80% with sustained night condensation', verified: true },
    { text: 'Recent 12mm rainfall event accelerated pathogen incubation', verified: true },
    { text: 'Cotton crop is at flowering stage (Day 62) where foliar defense is biologically vulnerable', verified: true }
  ];

  return (
    <div className="max-w-2xl mx-auto px-4 py-5 sm:py-7 space-y-6 animate-fadeIn pb-24 md:pb-12">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[11px] font-bold font-mono">
            CORE DIFFERENTIATOR
          </span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-gray-900 font-['Outfit']">
          What's affecting your crop?
        </h2>
        <p className="text-xs text-gray-500 mt-1">
          Differential AI evaluates multiple competing hypotheses rather than forcing a single label.
        </p>
      </div>

      {/* Probability Distribution Cards */}
      <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-xs space-y-4">
        <h3 className="text-xs font-bold text-gray-700 uppercase tracking-wider font-mono">
          Diagnostic Probability Distribution
        </h3>

        <div className="space-y-3">
          {DIFFERENTIAL_DIAGNOSIS_DATA.map((item) => (
            <div key={item.condition} className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-gray-800">{item.condition}</span>
                <span className="font-black text-gray-900 font-mono text-sm">{item.probability}%</span>
              </div>

              {/* Horizontal Probability Bar */}
              <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-1000"
                  style={{
                    width: `${item.probability}%`,
                    backgroundColor: item.color
                  }}
                />
              </div>

              {/* Key Indicators */}
              <div className="flex flex-wrap gap-1 pt-0.5">
                {item.keyIndicators.map((ind, i) => (
                  <span key={i} className="text-[10px] bg-gray-50 text-gray-600 px-2 py-0.5 rounded border border-gray-200">
                    {ind}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* "Why we think this" Evidence Section */}
      <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between border-b border-gray-100 pb-2">
          <h3 className="text-xs font-bold text-gray-800 uppercase tracking-wider font-mono flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Why We Think This</span>
          </h3>
          <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-bold">
            5 / 5 Evidence Validated
          </span>
        </div>

        <p className="text-xs text-gray-600 leading-relaxed">
          This is explainable AI, not a black-box guess. The model weighed foliar lesions against recent local rainfall records:
        </p>

        <ul className="space-y-2 pt-1">
          {evidenceList.map((ev, idx) => (
            <li key={idx} className="flex items-start gap-2.5 text-xs text-gray-700 bg-[#F4F8F5] p-2.5 rounded-xl border border-emerald-100">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span className="leading-snug">{ev.text}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Comparison: Disease vs Deficiency */}
      <div className="bg-blue-50/70 p-4 rounded-2xl border border-blue-200 space-y-2 text-xs">
        <div className="flex items-center gap-2 font-bold text-blue-900">
          <Info className="w-4 h-4 text-blue-700" />
          <span>Why not pure Potassium / Zinc deficiency?</span>
        </div>
        <p className="text-blue-800 leading-relaxed">
          While cotton leaves in Plot C exhibit minor interveinal yellowing (17% probability), the presence of dark circular lesions with purplish margins and distinct halo rings indicates an active fungal pathogen rather than purely physiological nutrient hunger. Spraying only fertilizer would fail to halt fungal spore spread.
        </p>
      </div>

      {/* Action Next */}
      <div className="flex items-center justify-between pt-2">
        <button
          onClick={() => onNavigate('severity')}
          className="text-xs font-bold text-gray-600 hover:text-gray-900 flex items-center gap-1"
        >
          <span>View Severity Analysis</span>
        </button>

        <button
          onClick={() => onNavigate('actions')}
          className="py-3 px-5 rounded-xl bg-[#1B4332] hover:bg-[#255742] text-white font-bold text-xs shadow-sm flex items-center gap-2"
        >
          <span>Go to Action Engine</span>
          <ArrowRight className="w-4 h-4 text-emerald-300" />
        </button>
      </div>
    </div>
  );
};
