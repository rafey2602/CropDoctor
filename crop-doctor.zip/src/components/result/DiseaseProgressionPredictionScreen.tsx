import React from 'react';
import { TrendingUp, AlertTriangle, Clock, ArrowRight, ShieldAlert, Sparkles, CheckCircle2 } from 'lucide-react';
import { PROGRESSION_STEPS } from '../../data/mockData';
import { AppScreen } from '../../types';

interface DiseaseProgressionPredictionScreenProps {
  onNavigate: (screen: AppScreen) => void;
}

export const DiseaseProgressionPredictionScreen: React.FC<DiseaseProgressionPredictionScreenProps> = ({
  onNavigate
}) => {
  return (
    <div className="max-w-2xl mx-auto px-4 py-5 sm:py-7 space-y-6 animate-fadeIn pb-24 md:pb-12">
      {/* Header */}
      <div>
        <span className="px-2.5 py-0.5 rounded-full bg-red-100 text-red-800 text-[11px] font-bold font-mono">
          KEY INNOVATION &bull; TIME-SERIES FORECASTING
        </span>
        <h2 className="text-2xl sm:text-3xl font-black text-gray-900 font-['Outfit'] mt-1">
          What could happen next?
        </h2>
        <p className="text-xs text-gray-500">
          Predicts pathogen multiplication risk trajectory if no preventative intervention is taken.
        </p>
      </div>

      {/* Visual Risk Progression Curve Card */}
      <div className="bg-white p-5 rounded-3xl border border-gray-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-gray-500 uppercase font-mono">
              Trajectory Modeling
            </span>
            <h3 className="text-sm font-black text-gray-900 font-['Outfit']">
              Pathogen Spread Risk Curve (5-Day Horizon)
            </h3>
          </div>
          <span className="px-2 py-0.5 rounded bg-gray-100 text-gray-600 text-[10px] font-mono font-bold">
            AI-estimated risk
          </span>
        </div>

        {/* SVG Dynamic Risk Curve */}
        <div className="relative aspect-[16/8] w-full bg-gray-50 rounded-2xl p-4 border border-gray-100 overflow-hidden">
          <svg className="w-full h-full" viewBox="0 0 400 160">
            {/* Grid lines */}
            <line x1="40" y1="130" x2="380" y2="130" stroke="#E5E7EB" strokeWidth="1" />
            <line x1="40" y1="80" x2="380" y2="80" stroke="#E5E7EB" strokeWidth="1" strokeDasharray="3 3" />
            <line x1="40" y1="30" x2="380" y2="30" stroke="#E5E7EB" strokeWidth="1" strokeDasharray="3 3" />

            {/* Threshold line at 70% */}
            <line x1="40" y1="55" x2="380" y2="55" stroke="#FCA5A5" strokeWidth="1" strokeDasharray="4 2" />
            <text x="45" y="50" fill="#EF4444" fontSize="9" fontWeight="bold">
              High Damage Threshold (70%)
            </text>

            {/* Risk Curve Area Fill */}
            <path
              d="M 60 100 Q 180 70 240 50 T 360 30 L 360 130 L 60 130 Z"
              fill="url(#riskGradient)"
              opacity="0.25"
            />

            {/* Risk Curve Stroke */}
            <path
              d="M 60 100 Q 180 70 240 50 T 360 30"
              fill="none"
              stroke="#EF4444"
              strokeWidth="3.5"
              strokeLinecap="round"
            />

            {/* Node 1: TODAY */}
            <circle cx="60" cy="100" r="6" fill="#F59E0B" stroke="#FFF" strokeWidth="2" />
            <text x="60" y="120" textAnchor="middle" fill="#4B5563" fontSize="10" fontWeight="bold">
              Today (58%)
            </text>

            {/* Node 2: 48 HOURS */}
            <circle cx="210" cy="60" r="6" fill="#EA580C" stroke="#FFF" strokeWidth="2" />
            <text x="210" y="80" textAnchor="middle" fill="#EA580C" fontSize="10" fontWeight="bold">
              48 Hours (74%)
            </text>

            {/* Node 3: 3-5 DAYS */}
            <circle cx="360" cy="30" r="7" fill="#DC2626" stroke="#FFF" strokeWidth="2.5" />
            <text x="360" y="20" textAnchor="middle" fill="#DC2626" fontSize="10" fontWeight="bold">
              3–5 Days (81%)
            </text>

            <defs>
              <linearGradient id="riskGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#EF4444" />
                <stop offset="100%" stopColor="#FEF3C7" />
              </linearGradient>
            </defs>
          </svg>
        </div>

        {/* Disclaimer text */}
        <p className="text-[11px] text-gray-500 italic text-center">
          Based on symptoms, environmental conditions and previous observations. Clearly labeled as AI-estimated risk — not a claim of certainty.
        </p>
      </div>

      {/* Detailed Timeline Steps */}
      <div className="space-y-3">
        {PROGRESSION_STEPS.map((step, idx) => {
          const isHigh = step.riskPercent >= 70;
          return (
            <div
              key={step.timeframe}
              className={`p-4 rounded-2xl border transition-all ${
                idx === 0
                  ? 'bg-amber-50/60 border-amber-200'
                  : isHigh
                  ? 'bg-red-50/60 border-red-200'
                  : 'bg-white border-gray-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-black uppercase font-mono tracking-wider ${
                      idx === 0
                        ? 'bg-amber-600 text-white'
                        : isHigh
                        ? 'bg-red-600 text-white'
                        : 'bg-gray-700 text-white'
                    }`}
                  >
                    {step.timeframe}
                  </span>
                  <span className="text-xs font-bold text-gray-800">{step.visualNote}</span>
                </div>
                <span className="text-sm font-black font-mono text-gray-900">
                  {step.riskPercent}% Risk
                </span>
              </div>

              <p className="text-xs text-gray-600 mt-2 leading-relaxed">
                {step.description}
              </p>

              <div className="mt-2.5 flex items-center justify-between text-[11px] text-gray-500 pt-2 border-t border-gray-100">
                <span>Estimated leaf surface impact: <strong>{step.leafImpactArea}%</strong></span>
                <span className="font-semibold text-emerald-700">
                  {idx === 0 ? 'Intervention stops cycle' : 'Secondary infection window'}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Direct link to Actions */}
      <div className="pt-2">
        <button
          onClick={() => onNavigate('actions')}
          className="w-full py-4 px-6 rounded-2xl bg-[#1B4332] hover:bg-[#255742] text-white font-bold text-sm shadow-md flex items-center justify-center gap-2.5 transition-all"
        >
          <span>Act Now to Break Disease Cycle</span>
          <ArrowRight className="w-4 h-4 text-emerald-300" />
        </button>
      </div>
    </div>
  );
};
