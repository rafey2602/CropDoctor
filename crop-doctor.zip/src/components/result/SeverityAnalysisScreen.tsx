import React, { useState } from 'react';
import { Activity, ArrowRight, ShieldCheck, Eye, Layers, AlertTriangle } from 'lucide-react';
import { AppScreen } from '../../types';

interface SeverityAnalysisScreenProps {
  onNavigate: (screen: AppScreen) => void;
  leafImageUrl?: string;
}

export const SeverityAnalysisScreen: React.FC<SeverityAnalysisScreenProps> = ({
  onNavigate,
  leafImageUrl = 'https://images.unsplash.com/photo-1597848212624-a19eb35e2651?auto=format&fit=crop&w=800&q=80'
}) => {
  const [activeView, setActiveView] = useState<'both' | 'mask' | 'original'>('both');

  const severityStages = [
    { label: 'Healthy', range: '0-5%', color: 'bg-emerald-500' },
    { label: 'Early', range: '5-25%', color: 'bg-yellow-400' },
    { label: 'Moderate', range: '25-50%', color: 'bg-amber-500', isCurrent: true },
    { label: 'Severe', range: '>50%', color: 'bg-red-500' }
  ];

  return (
    <div className="max-w-2xl mx-auto px-4 py-5 sm:py-7 space-y-6 animate-fadeIn pb-24 md:pb-12">
      {/* Header */}
      <div>
        <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-bold font-mono">
          CANOPY BIOMASS IMPACT
        </span>
        <h2 className="text-2xl sm:text-3xl font-black text-gray-900 font-['Outfit'] mt-1">
          Severity Analysis
        </h2>
        <p className="text-xs text-gray-500">
          Quantifies leaf area loss to determine if chemical threshold has been crossed.
        </p>
      </div>

      {/* Visual Leaf & Mask Comparison View */}
      <div className="bg-white p-4 rounded-3xl border border-gray-200 shadow-sm space-y-3">
        <div className="flex items-center justify-between text-xs">
          <span className="font-bold text-gray-700 uppercase font-mono">
            Optical Foliar Segmentation
          </span>
          <div className="flex bg-gray-100 p-0.5 rounded-lg text-[11px] font-medium">
            <button
              onClick={() => setActiveView('both')}
              className={`px-2.5 py-1 rounded-md transition-colors ${activeView === 'both' ? 'bg-white text-gray-900 shadow-xs font-bold' : 'text-gray-500'}`}
            >
              Overlay
            </button>
            <button
              onClick={() => setActiveView('mask')}
              className={`px-2.5 py-1 rounded-md transition-colors ${activeView === 'mask' ? 'bg-white text-gray-900 shadow-xs font-bold' : 'text-gray-500'}`}
            >
              Lesion Mask
            </button>
            <button
              onClick={() => setActiveView('original')}
              className={`px-2.5 py-1 rounded-md transition-colors ${activeView === 'original' ? 'bg-white text-gray-900 shadow-xs font-bold' : 'text-gray-500'}`}
            >
              Original
            </button>
          </div>
        </div>

        <div className="relative aspect-[16/10] rounded-2xl overflow-hidden bg-black border border-gray-200">
          <img
            src={leafImageUrl}
            alt="Leaf severity inspection"
            className={`w-full h-full object-cover transition-opacity duration-300 ${
              activeView === 'mask' ? 'filter brightness-50 contrast-200' : ''
            }`}
          />

          {(activeView === 'both' || activeView === 'mask') && (
            <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 400 250">
              {/* Highlighted Lesion Areas */}
              <circle cx="150" cy="110" r="32" fill="rgba(245, 158, 11, 0.55)" stroke="#F59E0B" strokeWidth="2" />
              <circle cx="250" cy="145" r="28" fill="rgba(239, 68, 68, 0.55)" stroke="#EF4444" strokeWidth="2" />
              <circle cx="190" cy="165" r="15" fill="rgba(245, 158, 11, 0.45)" stroke="#F59E0B" strokeWidth="1.5" />
            </svg>
          )}

          <div className="absolute bottom-3 left-3 bg-black/75 text-white px-3 py-1 rounded-xl text-xs font-mono backdrop-blur-xs flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            <span>Calculated Necrotic Area: <strong>28%</strong></span>
          </div>
        </div>
      </div>

      {/* Metrics & Severity Bar */}
      <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-gray-100 pb-3">
          <div>
            <span className="text-[11px] text-gray-500 block uppercase font-mono">
              Severity Position
            </span>
            <div className="text-xl font-black text-gray-900 font-['Outfit']">
              EARLY / MODERATE (28%)
            </div>
          </div>
          <div className="text-right">
            <span className="inline-block px-3 py-1 rounded-full bg-amber-100 text-amber-800 text-xs font-bold">
              Action Threshold Reached
            </span>
          </div>
        </div>

        {/* Continuous Severity Scale Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-bold text-gray-600">
            <span>Healthy (0%)</span>
            <span>Early (20%)</span>
            <span className="text-amber-700">Moderate (40%)</span>
            <span>Severe (80%+)</span>
          </div>

          <div className="relative w-full h-4 bg-gray-200 rounded-full overflow-hidden flex">
            <div className="w-1/4 bg-emerald-500" />
            <div className="w-1/4 bg-yellow-400" />
            <div className="w-1/4 bg-amber-500" />
            <div className="w-1/4 bg-red-600" />

            {/* Indicator Needle */}
            <div
              className="absolute top-0 bottom-0 w-2.5 bg-white border-2 border-gray-900 shadow-md rounded-full transform -translate-x-1/2"
              style={{ left: '28%' }}
            />
          </div>

          <div className="flex justify-between text-[11px] text-gray-400 font-mono">
            <span>No spray needed</span>
            <span className="text-amber-800 font-bold">▲ Current: 28% (Organic/Biocontrol optimal)</span>
            <span>Chemical rescue</span>
          </div>
        </div>

        {/* Natural Agricultural Explanation */}
        <div className="p-3.5 bg-[#F4F8F5] rounded-xl border border-emerald-200 text-xs text-gray-700 leading-relaxed">
          <p className="font-semibold text-emerald-900 mb-1">
            Why early intervention matters right now:
          </p>
          At 28% foliar damage, the fungal mycelium is still primarily restricted to lower vegetative leaves. Intervening today halts spore migration to higher flowering nodes, maintaining 90%+ boll retention without needing expensive broad-spectrum chemicals.
        </div>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between pt-2">
        <button
          onClick={() => onNavigate('explainable-ai')}
          className="text-xs font-bold text-gray-600 hover:text-gray-900 flex items-center gap-1"
        >
          <span>Why the AI Thinks This</span>
        </button>

        <button
          onClick={() => onNavigate('progression')}
          className="py-3 px-5 rounded-xl bg-[#1B4332] hover:bg-[#255742] text-white font-bold text-xs shadow-sm flex items-center gap-2"
        >
          <span>See Disease Progression Risk</span>
          <ArrowRight className="w-4 h-4 text-emerald-300" />
        </button>
      </div>
    </div>
  );
};
