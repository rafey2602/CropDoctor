import React from 'react';
import { HelpCircle, Eye, CloudSun, Sprout, ShieldCheck, ArrowRight, CheckCircle2 } from 'lucide-react';
import { AppScreen } from '../../types';

interface ExplainableAIScreenProps {
  onNavigate: (screen: AppScreen) => void;
}

export const ExplainableAIScreen: React.FC<ExplainableAIScreenProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-2xl mx-auto px-4 py-5 sm:py-7 space-y-6 animate-fadeIn pb-24 md:pb-12">
      {/* Header */}
      <div>
        <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[11px] font-bold font-mono">
          TRANSPARENT AGRICULTURAL AI
        </span>
        <h2 className="text-2xl sm:text-3xl font-black text-gray-900 font-['Outfit'] mt-1">
          Why did the AI reach this result?
        </h2>
        <p className="text-xs text-gray-500">
          We break down visual evidence, weather patterns, and crop stage so you can trust every recommendation.
        </p>
      </div>

      {/* AI Confidence Banner */}
      <div className="p-4 bg-gradient-to-r from-[#1B4332] to-[#255742] text-white rounded-2xl flex items-center justify-between shadow-sm">
        <div>
          <span className="text-[11px] font-bold text-emerald-300 tracking-wider uppercase font-mono">
            OVERALL MODEL CONFIDENCE
          </span>
          <div className="text-3xl font-black font-['Outfit'] mt-0.5">
            91% High Certainty
          </div>
          <p className="text-xs text-emerald-100/80 mt-0.5">
            Cross-referenced with 45,000+ certified regional cotton crop pathologies.
          </p>
        </div>
        <div className="w-14 h-14 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center font-black text-xl font-mono text-emerald-300">
          91%
        </div>
      </div>

      {/* 3 Pillars of Evidence */}
      <div className="space-y-4">
        {/* 1. VISUAL EVIDENCE */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-gray-900 font-['Outfit']">
            <div className="p-1.5 rounded-lg bg-amber-50 text-amber-700">
              <Eye className="w-4 h-4" />
            </div>
            <span>1. Visual Foliar Evidence</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <div className="p-3 bg-gray-50 rounded-xl text-xs space-y-1">
              <span className="font-bold text-gray-800 block">Circular Leaf Spots</span>
              <p className="text-[11px] text-gray-600">
                1-3mm reddish-brown necrotic centers matching early fungal sporulation.
              </p>
            </div>
            <div className="p-3 bg-gray-50 rounded-xl text-xs space-y-1">
              <span className="font-bold text-gray-800 block">Chlorotic Yellow Halos</span>
              <p className="text-[11px] text-gray-600">
                Toxin release from mycelium causes localized yellowing around spot boundaries.
              </p>
            </div>
            <div className="p-3 bg-gray-50 rounded-xl text-xs space-y-1">
              <span className="font-bold text-gray-800 block">Canopy Distribution</span>
              <p className="text-[11px] text-gray-600">
                Clusters found on lower leaves where humidity lingers longest.
              </p>
            </div>
          </div>
        </div>

        {/* 2. ENVIRONMENTAL EVIDENCE */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-gray-900 font-['Outfit']">
            <div className="p-1.5 rounded-lg bg-cyan-50 text-cyan-700">
              <CloudSun className="w-4 h-4" />
            </div>
            <span>2. Environmental & Weather Context</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <div className="p-3 bg-cyan-50/50 rounded-xl text-xs space-y-1 border border-cyan-100">
              <span className="font-bold text-cyan-950 block">Humidity: 82%</span>
              <p className="text-[11px] text-cyan-900/80">
                Fungal spores require &gt;75% RH for at least 6 hours to penetrate stomata.
              </p>
            </div>
            <div className="p-3 bg-cyan-50/50 rounded-xl text-xs space-y-1 border border-cyan-100">
              <span className="font-bold text-cyan-950 block">Rainfall: 12 mm Recent</span>
              <p className="text-[11px] text-cyan-900/80">
                Water splash physically transports fungal conidia from lower soil to leaves.
              </p>
            </div>
            <div className="p-3 bg-cyan-50/50 rounded-xl text-xs space-y-1 border border-cyan-100">
              <span className="font-bold text-cyan-950 block">Temperature: 28°C</span>
              <p className="text-[11px] text-cyan-900/80">
                Optimal biological multiplication range for Cercospora species (25-30°C).
              </p>
            </div>
          </div>
        </div>

        {/* 3. CROP CONTEXT */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-gray-900 font-['Outfit']">
            <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700">
              <Sprout className="w-4 h-4" />
            </div>
            <span>3. Crop Phenology & Stage Context</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div className="p-3 bg-emerald-50/50 rounded-xl text-xs space-y-1 border border-emerald-100">
              <span className="font-bold text-emerald-950 block">Crop: Cotton (Day 62)</span>
              <p className="text-[11px] text-emerald-900/80">
                Flowering and early boll development redirect plant carbohydrates away from foliar defense.
              </p>
            </div>
            <div className="p-3 bg-emerald-50/50 rounded-xl text-xs space-y-1 border border-emerald-100">
              <span className="font-bold text-emerald-950 block">Canopy Density</span>
              <p className="text-[11px] text-emerald-900/80">
                Dense row spacing restricts morning wind velocity, extending dew dry-off by 3.5 hours.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation CTA */}
      <div className="flex items-center justify-between pt-2">
        <button
          onClick={() => onNavigate('result')}
          className="text-xs font-bold text-gray-600 hover:text-gray-900 flex items-center gap-1"
        >
          <span>&larr; Back to Results</span>
        </button>

        <button
          onClick={() => onNavigate('progression')}
          className="py-3 px-5 rounded-xl bg-[#1B4332] hover:bg-[#255742] text-white font-bold text-xs shadow-sm flex items-center gap-2"
        >
          <span>View Progression Prediction</span>
          <ArrowRight className="w-4 h-4 text-emerald-300" />
        </button>
      </div>
    </div>
  );
};
