import React, { useState } from 'react';
import {
  ArrowRight,
  Sparkles,
  Layers,
  Activity,
  CloudSun,
  ShieldCheck,
  Eye,
  AlertTriangle,
  HelpCircle,
  TrendingUp,
  FileSpreadsheet,
  CheckCircle2,
  RefreshCw
} from 'lucide-react';
import { ScanRecord, AppScreen } from '../../types';

interface CropHealthResultScreenProps {
  result: ScanRecord;
  onNavigate: (screen: AppScreen) => void;
  onScanNew: () => void;
}

export const CropHealthResultScreen: React.FC<CropHealthResultScreenProps> = ({
  result,
  onNavigate,
  onScanNew
}) => {
  const [showSegmentationOverlay, setShowSegmentationOverlay] = useState(true);

  // If this is an unknown condition or low confidence scenario, provide clear visual indicators and direct links
  const isUnknown = result.isUnknownCondition;
  const isLowConf = result.isLowConfidence;

  return (
    <div className="max-w-3xl mx-auto px-4 py-5 sm:py-7 space-y-6 animate-fadeIn pb-24 md:pb-12">
      {/* 1. Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 sm:p-5 rounded-2xl border border-gray-200 shadow-2xs">
        <div>
          <span className="text-[11px] font-mono font-bold text-gray-400 uppercase tracking-wider block">
            CROP HEALTH INTELLIGENCE SUMMARY
          </span>
          <h1 className="text-xl sm:text-2xl font-black text-gray-900 font-['Outfit']">
            Crop Health Analysis
          </h1>
          <p className="text-xs text-gray-500">
            {result.crop} &bull; {result.cropStage} stage &bull; Scanned {result.date}
          </p>
        </div>

        {/* Health Score Pill */}
        <div className="flex items-center gap-3 bg-[#F4F8F5] p-2.5 sm:px-4 rounded-xl border border-emerald-200">
          <div className="text-right">
            <span className="text-[10px] font-bold text-gray-500 block uppercase font-mono">
              Health Score
            </span>
            <span className="text-xs font-bold text-amber-700">
              {result.healthStatus}
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-white border border-emerald-300 flex items-center justify-center font-black text-lg font-['Outfit'] text-gray-900 shadow-2xs">
            {result.healthScore}
          </div>
        </div>
      </div>

      {/* Special Warnings for Unknown or Low Confidence Cases */}
      {isUnknown && (
        <div className="p-4 bg-purple-50 border border-purple-300 rounded-2xl flex items-start gap-3">
          <HelpCircle className="w-5 h-5 text-purple-700 shrink-0 mt-0.5" />
          <div className="text-xs">
            <h4 className="font-bold text-purple-900">Unknown Crop Condition (Anomaly Detected)</h4>
            <p className="text-purple-700 mt-0.5 leading-relaxed">
              This leaf does not sufficiently match our known pathogen database. Crop Doctor refuses to guess a false diagnosis and recommends requesting agronomist verification.
            </p>
            <button
              onClick={() => onNavigate('expert-verification')}
              className="mt-2 text-xs font-bold text-purple-900 underline"
            >
              Request Free KVK Expert Review &rarr;
            </button>
          </div>
        </div>
      )}

      {isLowConf && (
        <div className="p-4 bg-amber-50 border border-amber-300 rounded-2xl flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
          <div className="text-xs">
            <h4 className="font-bold text-amber-900">Low AI Confidence ({result.confidence}%)</h4>
            <p className="text-amber-700 mt-0.5 leading-relaxed">
              Sub-optimal lighting or shadow interference detected. Consider retaking the photo or consult an agricultural officer.
            </p>
            <div className="flex gap-3 mt-2 font-bold">
              <button onClick={onScanNew} className="text-amber-900 underline">
                Retake Photo
              </button>
              <button onClick={() => onNavigate('expert-verification')} className="text-amber-900 underline">
                Agronomist Review
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. Visual Scanned Leaf Image + Segmentation Overlay */}
      <div className="relative aspect-[16/10] sm:aspect-[16/9] rounded-3xl overflow-hidden border-2 border-emerald-600/30 shadow-lg bg-black group">
        <img
          src={result.imageUrl}
          alt={result.primaryFinding}
          className="w-full h-full object-cover"
        />

        {/* Dynamic SVG Disease Segmentation Overlay */}
        {showSegmentationOverlay && (
          <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 400 250">
            {/* Lesion Cluster 1 */}
            <path
              d="M 130 90 Q 150 75 170 95 Q 185 120 160 135 Q 130 140 120 115 Z"
              fill="rgba(245, 158, 11, 0.4)"
              stroke="#F59E0B"
              strokeWidth="2.5"
              strokeDasharray="4 2"
            />
            {/* Halo 1 */}
            <circle cx="150" cy="110" r="35" fill="none" stroke="#FBBF24" strokeWidth="1.5" strokeDasharray="3 3" opacity="0.8" />
            <text x="125" y="80" fill="#FFF" fontSize="10" fontWeight="bold" fontFamily="monospace" className="drop-shadow">
              Cercospora Lesion #1 (~14%)
            </text>

            {/* Lesion Cluster 2 */}
            <path
              d="M 230 120 Q 260 110 275 135 Q 285 160 250 175 Q 220 165 225 140 Z"
              fill="rgba(239, 68, 68, 0.4)"
              stroke="#EF4444"
              strokeWidth="2.5"
            />
            <circle cx="250" cy="145" r="30" fill="none" stroke="#F87171" strokeWidth="1.5" opacity="0.8" />
            <text x="225" y="110" fill="#FFF" fontSize="10" fontWeight="bold" fontFamily="monospace" className="drop-shadow">
              Active Necrosis #2 (~14%)
            </text>
          </svg>
        )}

        {/* Overlay Controls */}
        <div className="absolute top-3 right-3 z-10">
          <button
            onClick={() => setShowSegmentationOverlay(!showSegmentationOverlay)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold backdrop-blur-md transition-all flex items-center gap-1.5 border shadow-sm ${
              showSegmentationOverlay
                ? 'bg-[#1B4332]/85 text-emerald-300 border-emerald-500'
                : 'bg-black/60 text-white border-white/20'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>{showSegmentationOverlay ? 'Hide AI Segmentation' : 'Show AI Segmentation'}</span>
          </button>
        </div>

        {/* Bottom Tag inside Leaf Viewport */}
        <div className="absolute bottom-3 left-3 bg-black/70 backdrop-blur-md text-white px-3 py-1 rounded-xl text-xs font-mono flex items-center gap-2 border border-white/10">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          <span>Symptom Area: {result.affectedAreaEstimate}</span>
        </div>
      </div>

      {/* 3. Primary Finding Card */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-gray-200 shadow-xs space-y-4">
        <div>
          <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider font-mono">
            PRIMARY FINDING
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-gray-900 font-['Outfit'] mt-0.5">
            {result.primaryFinding}
          </h2>
        </div>

        {/* Metrics Row: Confidence, Severity, Affected Area */}
        <div className="grid grid-cols-3 gap-3">
          <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 text-center sm:text-left">
            <span className="text-[11px] text-gray-500 block">AI Confidence</span>
            <span className="text-xl sm:text-2xl font-black text-gray-900 font-['Outfit']">
              {result.confidence}%
            </span>
            <span className="text-[10px] text-emerald-700 font-semibold block">Validated</span>
          </div>

          <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 text-center sm:text-left">
            <span className="text-[11px] text-gray-500 block">Foliar Severity</span>
            <span className="text-xl sm:text-2xl font-black text-amber-700 font-['Outfit']">
              {result.severityPercent}%
            </span>
            <span className="text-[10px] text-gray-600 font-semibold block">Early / Moderate</span>
          </div>

          <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 text-center sm:text-left">
            <span className="text-[11px] text-gray-500 block">Affected Area</span>
            <span className="text-xl sm:text-2xl font-black text-gray-900 font-['Outfit']">
              ~28%
            </span>
            <span className="text-[10px] text-gray-600 font-semibold block">Lower Canopy</span>
          </div>
        </div>

        {/* 4. Three Major Dimensions: Condition, Progression Risk, Weather Suitability */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          {/* Dimension 1: CURRENT CONDITION */}
          <div
            onClick={() => onNavigate('severity')}
            className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200 cursor-pointer hover:bg-amber-100/70 transition-colors"
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-amber-800 uppercase font-mono">
                CURRENT CONDITION
              </span>
              <span className="text-sm">🟡</span>
            </div>
            <div className="text-base font-bold text-amber-950 mt-1 font-['Outfit']">
              Moderate Stress
            </div>
            <p className="text-[11px] text-amber-800/90 mt-0.5">
              Foliar tissue is actively infected but vascular stem intact.
            </p>
          </div>

          {/* Dimension 2: PROGRESSION RISK */}
          <div
            onClick={() => onNavigate('progression')}
            className="p-3.5 rounded-xl bg-red-50/70 border border-red-200 cursor-pointer hover:bg-red-100/70 transition-colors"
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-red-800 uppercase font-mono">
                PROGRESSION RISK
              </span>
              <span className="text-sm">🔴</span>
            </div>
            <div className="text-base font-bold text-red-950 mt-1 font-['Outfit']">
              High (72%)
            </div>
            <p className="text-[11px] text-red-800/90 mt-0.5">
              Predicted to spread to middle nodes within 48-72 hours.
            </p>
          </div>

          {/* Dimension 3: WEATHER SUITABILITY */}
          <div
            onClick={() => onNavigate('weather')}
            className="p-3.5 rounded-xl bg-red-50/70 border border-red-200 cursor-pointer hover:bg-red-100/70 transition-colors"
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-red-800 uppercase font-mono">
                WEATHER SUITABILITY
              </span>
              <span className="text-sm">🔴</span>
            </div>
            <div className="text-base font-bold text-red-950 mt-1 font-['Outfit']">
              High (84/100)
            </div>
            <p className="text-[11px] text-red-800/90 mt-0.5">
              82% RH + 28°C provides ideal spore reproduction environment.
            </p>
          </div>
        </div>

        {/* Main Advisory Message */}
        <div className="p-3.5 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-950 leading-relaxed">
          <strong>Key Insight:</strong> Your crop is showing early symptoms. Current environmental conditions may support rapid disease progression. Intervening now preserves flowering squares and prevents extensive defoliation.
        </div>
      </div>

      {/* 5. Main Action CTA: "See What To Do" */}
      <div className="space-y-3">
        <button
          onClick={() => onNavigate('actions')}
          className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-[#1B4332] to-[#2D6A4F] hover:from-[#15382A] hover:to-[#22573F] text-white font-extrabold text-base shadow-lg shadow-emerald-950/20 flex items-center justify-center gap-2.5 transition-all transform active:scale-98"
        >
          <span>See What To Do Now</span>
          <ArrowRight className="w-5 h-5 text-emerald-300" />
        </button>

        {/* Secondary Sub-Screen Exploration Hub */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
          <button
            onClick={() => onNavigate('differential')}
            className="p-3 bg-white rounded-xl border border-gray-200 hover:border-emerald-500 text-left transition-all"
          >
            <Layers className="w-4 h-4 text-emerald-700 mb-1" />
            <h4 className="text-xs font-bold text-gray-900">Differential</h4>
            <p className="text-[10px] text-gray-500">Disease vs Deficiency</p>
          </button>

          <button
            onClick={() => onNavigate('severity')}
            className="p-3 bg-white rounded-xl border border-gray-200 hover:border-emerald-500 text-left transition-all"
          >
            <Activity className="w-4 h-4 text-amber-600 mb-1" />
            <h4 className="text-xs font-bold text-gray-900">Severity Scale</h4>
            <p className="text-[10px] text-gray-500">Canopy damage %</p>
          </button>

          <button
            onClick={() => onNavigate('explainable-ai')}
            className="p-3 bg-white rounded-xl border border-gray-200 hover:border-emerald-500 text-left transition-all"
          >
            <HelpCircle className="w-4 h-4 text-blue-600 mb-1" />
            <h4 className="text-xs font-bold text-gray-900">Explainable AI</h4>
            <p className="text-[10px] text-gray-500">Why AI made this call</p>
          </button>

          <button
            onClick={() => onNavigate('treatment')}
            className="p-3 bg-white rounded-xl border border-gray-200 hover:border-emerald-500 text-left transition-all"
          >
            <ShieldCheck className="w-4 h-4 text-emerald-600 mb-1" />
            <h4 className="text-xs font-bold text-gray-900">Treatments</h4>
            <p className="text-[10px] text-gray-500">Organic & chemical</p>
          </button>
        </div>
      </div>
    </div>
  );
};
