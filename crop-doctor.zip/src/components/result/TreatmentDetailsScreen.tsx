import React, { useState } from 'react';
import { ShieldCheck, Leaf, FlaskConical, Sprout, AlertTriangle, ArrowRight, Check, Droplets } from 'lucide-react';
import { TREATMENT_OPTIONS } from '../../data/mockData';
import { AppScreen } from '../../types';

interface TreatmentDetailsScreenProps {
  onNavigate: (screen: AppScreen) => void;
}

export const TreatmentDetailsScreen: React.FC<TreatmentDetailsScreenProps> = ({ onNavigate }) => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'organic' | 'prevention' | 'chemical'>('all');

  const filtered = activeCategory === 'all'
    ? TREATMENT_OPTIONS
    : TREATMENT_OPTIONS.filter((t) => t.category === activeCategory);

  const getCategoryBadge = (cat: string) => {
    switch (cat) {
      case 'organic':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'prevention':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'chemical':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-5 sm:py-7 space-y-6 animate-fadeIn pb-24 md:pb-12">
      {/* Header */}
      <div>
        <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-bold font-mono">
          RESPONSIBLE AGROCHEMICAL STEWARDSHIP
        </span>
        <h2 className="text-2xl sm:text-3xl font-black text-gray-900 font-['Outfit'] mt-1">
          Treatment & Management Options
        </h2>
        <p className="text-xs text-gray-500">
          Tailored to your current severity level (28%). Prioritize organic biocontrol before adopting chemical measures.
        </p>
      </div>

      {/* Category Filter Pills */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setActiveCategory('all')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeCategory === 'all'
              ? 'bg-[#1B4332] text-white shadow-sm'
              : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'
          }`}
        >
          All Options ({TREATMENT_OPTIONS.length})
        </button>

        <button
          onClick={() => setActiveCategory('organic')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
            activeCategory === 'organic'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'
          }`}
        >
          <Leaf className="w-3.5 h-3.5" />
          <span>Organic & Biocontrol</span>
        </button>

        <button
          onClick={() => setActiveCategory('prevention')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
            activeCategory === 'prevention'
              ? 'bg-blue-700 text-white shadow-sm'
              : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'
          }`}
        >
          <Sprout className="w-3.5 h-3.5" />
          <span>Agronomic Prevention</span>
        </button>

        <button
          onClick={() => setActiveCategory('chemical')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
            activeCategory === 'chemical'
              ? 'bg-amber-700 text-white shadow-sm'
              : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'
          }`}
        >
          <FlaskConical className="w-3.5 h-3.5" />
          <span>Targeted Chemical (Rescue)</span>
        </button>
      </div>

      {/* Treatment Cards Grid */}
      <div className="space-y-4">
        {filtered.map((item) => (
          <div
            key={item.id}
            className="bg-white p-5 rounded-2xl border border-gray-200 shadow-xs space-y-3"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-gray-100 pb-3">
              <div className="flex items-center gap-2">
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase border ${getCategoryBadge(item.category)}`}>
                  {item.category}
                </span>
                <h3 className="text-base font-bold text-gray-900 font-['Outfit']">
                  {item.title}
                </h3>
              </div>
              <span className="text-xs text-gray-500 font-medium">
                Target: {item.purpose}
              </span>
            </div>

            {/* Grid of structured details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-gray-50 rounded-xl space-y-1">
                <span className="font-bold text-gray-800 block font-mono text-[11px]">
                  WHEN TO USE:
                </span>
                <p className="text-gray-600">{item.whenToUse}</p>
              </div>

              <div className="p-3 bg-emerald-50/50 rounded-xl space-y-1 border border-emerald-100">
                <span className="font-bold text-emerald-900 block font-mono text-[11px]">
                  APPLICATION GUIDANCE:
                </span>
                <p className="text-emerald-800">{item.applicationGuidance}</p>
              </div>

              <div className="p-3 bg-amber-50/50 rounded-xl space-y-1 border border-amber-100">
                <span className="font-bold text-amber-900 block font-mono text-[11px]">
                  PRECAUTIONS & SAFETY:
                </span>
                <p className="text-amber-800">{item.precautions}</p>
              </div>

              <div className="p-3 bg-blue-50/50 rounded-xl space-y-1 border border-blue-100">
                <span className="font-bold text-blue-900 block font-mono text-[11px]">
                  ENVIRONMENTAL CONSIDERATIONS:
                </span>
                <p className="text-blue-800">{item.environmentalConsiderations}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Safety Advisory Banner */}
      <div className="p-4 bg-gray-100 rounded-2xl text-xs text-gray-700 flex items-start gap-2">
        <AlertTriangle className="w-4 h-4 text-gray-600 shrink-0 mt-0.5" />
        <p>
          Always wear personal protective gear (gloves, mask, eye shield) when handling any spray mixture. Never apply sprays near open farm wells or natural water bodies.
        </p>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between pt-1">
        <button
          onClick={() => onNavigate('actions')}
          className="text-xs font-bold text-gray-600 hover:text-gray-900"
        >
          &larr; Back to Actions
        </button>

        <button
          onClick={() => onNavigate('report')}
          className="py-3 px-5 rounded-xl bg-[#1B4332] hover:bg-[#255742] text-white font-bold text-xs shadow-sm flex items-center gap-2"
        >
          <span>Generate Field Report</span>
          <ArrowRight className="w-4 h-4 text-emerald-300" />
        </button>
      </div>
    </div>
  );
};
