import React, { useState } from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  Clock,
  AlertTriangle,
  ArrowRight,
  Eye,
  Wind,
  RefreshCw,
  UserCheck,
  Info
} from 'lucide-react';
import { PRIORITIZED_ACTIONS } from '../../data/mockData';
import { AppScreen, PrioritizedAction } from '../../types';

interface RecommendedActionsScreenProps {
  onNavigate: (screen: AppScreen) => void;
}

export const RecommendedActionsScreen: React.FC<RecommendedActionsScreenProps> = ({ onNavigate }) => {
  const [actions, setActions] = useState<PrioritizedAction[]>(PRIORITIZED_ACTIONS);

  const toggleAction = (id: string) => {
    setActions(actions.map((act) => (act.id === id ? { ...act, isCompleted: !act.isCompleted } : act)));
  };

  const getUrgencyIcon = (level: number) => {
    switch (level) {
      case 1:
        return <Eye className="w-4 h-4 text-red-600" />;
      case 2:
        return <Wind className="w-4 h-4 text-amber-600" />;
      case 3:
        return <RefreshCw className="w-4 h-4 text-blue-600" />;
      default:
        return <UserCheck className="w-4 h-4 text-emerald-600" />;
    }
  };

  const completedCount = actions.filter((a) => a.isCompleted).length;

  return (
    <div className="max-w-2xl mx-auto px-4 py-5 sm:py-7 space-y-6 animate-fadeIn pb-24 md:pb-12">
      {/* Header */}
      <div>
        <div className="flex items-center justify-between">
          <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-bold font-mono">
            ACTION ENGINE
          </span>
          <span className="text-xs text-gray-500 font-semibold font-mono">
            {completedCount} of {actions.length} Completed
          </span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-gray-900 font-['Outfit'] mt-1">
          Your Next Best Actions
        </h2>
        <p className="text-xs text-gray-500">
          Ranked by biological urgency to protect crop yield with minimal chemical expense.
        </p>
      </div>

      {/* Prioritized Action Cards Stack */}
      <div className="space-y-3.5">
        {actions.map((action) => {
          return (
            <div
              key={action.id}
              className={`p-4 sm:p-5 rounded-2xl border transition-all ${
                action.isCompleted
                  ? 'bg-gray-50 border-gray-200 opacity-75'
                  : 'bg-white border-gray-200 hover:border-emerald-500 shadow-xs'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  {/* Interactive Checkbox */}
                  <button
                    onClick={() => toggleAction(action.id)}
                    className={`mt-0.5 w-6 h-6 rounded-lg flex items-center justify-center transition-colors shrink-0 ${
                      action.isCompleted
                        ? 'bg-emerald-600 text-white'
                        : 'border-2 border-gray-300 hover:border-emerald-600'
                    }`}
                  >
                    {action.isCompleted && <CheckCircle2 className="w-4 h-4 stroke-[3]" />}
                  </button>

                  <div>
                    {/* Urgency Badge */}
                    <div className="flex items-center gap-2 mb-1">
                      <span
                        className={`px-2 py-0.5 rounded-md text-[10px] font-black uppercase font-mono tracking-wider border ${action.urgencyBadge}`}
                      >
                        {action.urgencyLabel}
                      </span>
                      <span className="text-[11px] text-gray-400 font-mono">
                        Stage {action.level}
                      </span>
                    </div>

                    <h3
                      className={`text-sm sm:text-base font-bold text-gray-900 font-['Outfit'] ${
                        action.isCompleted ? 'line-through text-gray-500' : ''
                      }`}
                    >
                      {action.title}
                    </h3>

                    <p className="text-xs text-gray-600 mt-1 leading-relaxed">
                      {action.description}
                    </p>

                    <div className="mt-2.5 inline-flex items-center gap-1.5 px-2.5 py-1 bg-[#F4F8F5] rounded-lg text-[11px] text-emerald-800 font-medium">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{action.impact}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Critical Responsible Warning Banner */}
      <div className="p-4 bg-amber-50 rounded-2xl border border-amber-300 flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
        <div className="text-xs text-amber-900 leading-relaxed">
          <strong>Responsible Agro-Safety Notice:</strong> Always verify treatment suitability for your specific crop variety, local district climate, and official state agricultural extension / Krishi Vigyan Kendra guidance before applying any synthetic chemical formulation.
        </div>
      </div>

      {/* Treatment Categories Gateway */}
      <div className="bg-white p-5 rounded-2xl border border-gray-200 space-y-3 shadow-xs">
        <h3 className="text-xs font-bold text-gray-700 uppercase tracking-wider font-mono">
          Explore Solution Portfolios:
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          <button
            onClick={() => onNavigate('treatment')}
            className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl text-left hover:bg-emerald-100 transition-colors"
          >
            <span className="text-xs font-bold text-emerald-950 block">Organic / Bio-Control</span>
            <span className="text-[10px] text-emerald-700">Trichoderma & Neem oil</span>
          </button>

          <button
            onClick={() => onNavigate('treatment')}
            className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl text-left hover:bg-blue-100 transition-colors"
          >
            <span className="text-xs font-bold text-blue-950 block">Preventive Practices</span>
            <span className="text-[10px] text-blue-700">Airflow & canopy spacing</span>
          </button>

          <button
            onClick={() => onNavigate('treatment')}
            className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl text-left hover:bg-amber-100 transition-colors"
          >
            <span className="text-xs font-bold text-amber-950 block">Targeted Fungicides</span>
            <span className="text-[10px] text-amber-700">Threshold-dependent spray</span>
          </button>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between pt-1">
        <button
          onClick={() => onNavigate('result')}
          className="text-xs font-bold text-gray-600 hover:text-gray-900"
        >
          &larr; Back to Diagnostics
        </button>

        <button
          onClick={() => onNavigate('treatment')}
          className="py-3.5 px-6 rounded-xl bg-[#1B4332] hover:bg-[#255742] text-white font-bold text-xs shadow-md flex items-center gap-2"
        >
          <span>Detailed Treatment Options</span>
          <ArrowRight className="w-4 h-4 text-emerald-300" />
        </button>
      </div>
    </div>
  );
};
