import React from 'react';
import { CloudSun, Droplets, Wind, Thermometer, ShieldAlert, ArrowRight, Umbrella, Calendar } from 'lucide-react';
import { WeatherData, AppScreen } from '../../types';

interface WeatherEnvironmentalScreenProps {
  weather: WeatherData;
  onNavigate: (screen: AppScreen) => void;
}

export const WeatherEnvironmentalScreen: React.FC<WeatherEnvironmentalScreenProps> = ({
  weather,
  onNavigate
}) => {
  return (
    <div className="max-w-2xl mx-auto px-4 py-5 sm:py-7 space-y-6 animate-fadeIn pb-24 md:pb-12">
      {/* Header */}
      <div>
        <span className="px-2.5 py-0.5 rounded-full bg-cyan-100 text-cyan-800 text-[11px] font-bold font-mono">
          FIELD MICROCLIMATE INTELLIGENCE
        </span>
        <h2 className="text-2xl sm:text-3xl font-black text-gray-900 font-['Outfit'] mt-1">
          Weather & Environmental Risk
        </h2>
        <p className="text-xs text-gray-500">
          Environmental moisture and temperature dictate whether dormant spores erupt into an active epidemic.
        </p>
      </div>

      {/* Disease Favorability Gauge Card */}
      <div className="bg-gradient-to-br from-[#132A1E] to-[#1E3F2E] text-white p-5 sm:p-6 rounded-3xl border border-emerald-500/30 shadow-lg space-y-4">
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div>
            <span className="text-[11px] font-mono font-bold text-emerald-300 uppercase tracking-wider block">
              DISEASE-FAVORABILITY INDEX
            </span>
            <div className="text-xl sm:text-2xl font-black font-['Outfit'] mt-0.5 flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-red-500 animate-ping" />
              <span>Fungal Growth Conditions: HIGH</span>
            </div>
          </div>
          <div className="w-14 h-14 rounded-2xl bg-red-600/30 border border-red-400 flex items-center justify-center font-black text-xl font-mono text-red-300">
            {weather.diseaseFavorabilityScore}
          </div>
        </div>

        <p className="text-xs text-emerald-100/90 leading-relaxed">
          Current microclimate parameters are currently in the <strong>optimal incubation zone</strong> for Cercospora and Alternaria fungal pathogens. Continuous leaf wetness has persisted for {weather.leafWetnessDuration}.
        </p>

        {/* Contributing Factors Bar Visualization */}
        <div className="space-y-3 pt-2">
          {/* Humidity */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-emerald-200">Relative Humidity</span>
              <span className="font-mono font-bold text-amber-300">82% (Critical &gt;75%)</span>
            </div>
            <div className="w-full h-2.5 bg-white/10 rounded-full overflow-hidden">
              <div className="h-full bg-amber-400 rounded-full" style={{ width: '82%' }} />
            </div>
          </div>

          {/* Rainfall */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-emerald-200">Recent Precipitation & Splash</span>
              <span className="font-mono font-bold text-cyan-300">12 mm (Recent Rain)</span>
            </div>
            <div className="w-full h-2.5 bg-white/10 rounded-full overflow-hidden">
              <div className="h-full bg-cyan-400 rounded-full" style={{ width: '70%' }} />
            </div>
          </div>

          {/* Temperature */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-emerald-200">Ambient Temperature</span>
              <span className="font-mono font-bold text-emerald-300">28°C (Optimal Fungal Band)</span>
            </div>
            <div className="w-full h-2.5 bg-white/10 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-400 rounded-full" style={{ width: '60%' }} />
            </div>
          </div>
        </div>
      </div>

      {/* 4-Card Current Readings */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white p-3.5 rounded-2xl border border-gray-200 text-center">
          <Thermometer className="w-5 h-5 text-amber-600 mx-auto mb-1" />
          <span className="text-[11px] text-gray-500 block">Temperature</span>
          <span className="text-xl font-black text-gray-900 font-['Outfit']">
            {weather.temperature}°C
          </span>
          <span className="text-[10px] text-gray-500 block">Night: 22°C</span>
        </div>

        <div className="bg-white p-3.5 rounded-2xl border border-gray-200 text-center">
          <Droplets className="w-5 h-5 text-cyan-600 mx-auto mb-1" />
          <span className="text-[11px] text-gray-500 block">Humidity</span>
          <span className="text-xl font-black text-cyan-700 font-['Outfit']">
            {weather.humidity}%
          </span>
          <span className="text-[10px] text-amber-700 font-bold block">Dew Point Met</span>
        </div>

        <div className="bg-white p-3.5 rounded-2xl border border-gray-200 text-center">
          <Umbrella className="w-5 h-5 text-blue-600 mx-auto mb-1" />
          <span className="text-[11px] text-gray-500 block">Rain Forecast</span>
          <span className="text-xs font-bold text-gray-900 block mt-1">
            Showers in 36h
          </span>
          <span className="text-[10px] text-blue-700 block">85% Probability</span>
        </div>

        <div className="bg-white p-3.5 rounded-2xl border border-gray-200 text-center">
          <Wind className="w-5 h-5 text-gray-600 mx-auto mb-1" />
          <span className="text-[11px] text-gray-500 block">Wind Velocity</span>
          <span className="text-xl font-black text-gray-900 font-['Outfit']">
            11 <span className="text-xs font-normal">km/h</span>
          </span>
          <span className="text-[10px] text-gray-500 block">Gentle NW</span>
        </div>
      </div>

      {/* Actionable Microclimate Recommendation */}
      <div className="bg-amber-50 p-4 rounded-2xl border border-amber-200 space-y-2 text-xs">
        <div className="flex items-center gap-2 font-bold text-amber-900">
          <ShieldAlert className="w-4 h-4 text-amber-700" />
          <span>Weather-Driven Farming Advisory</span>
        </div>
        <p className="text-amber-800 leading-relaxed">
          Because moderate rainfall is predicted in 36 hours, avoid applying water-soluble systemic sprays within 6 hours of precipitation to prevent chemical runoff. Complete organic preventive bio-control (like Trichoderma) today before twilight so spores colonize leaf surfaces prior to rainy humid conditions.
        </p>
      </div>

      {/* Navigation */}
      <div className="pt-2">
        <button
          onClick={() => onNavigate('actions')}
          className="w-full py-4 px-6 rounded-2xl bg-[#1B4332] hover:bg-[#255742] text-white font-bold text-sm shadow-md flex items-center justify-center gap-2.5 transition-all"
        >
          <span>View Tailored Action Plan</span>
          <ArrowRight className="w-4 h-4 text-emerald-300" />
        </button>
      </div>
    </div>
  );
};
