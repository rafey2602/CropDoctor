import React from 'react';
import { Check, Mic, Globe, ArrowRight } from 'lucide-react';
import { SupportedLanguage } from '../../types';
import { SUPPORTED_LANGUAGES } from '../../data/mockData';

interface LanguageSelectionScreenProps {
  currentLanguage: SupportedLanguage;
  onSelectLanguage: (lang: SupportedLanguage) => void;
  onContinue?: () => void;
}

export const LanguageSelectionScreen: React.FC<LanguageSelectionScreenProps> = ({
  currentLanguage,
  onSelectLanguage,
  onContinue
}) => {
  return (
    <div className="max-w-md mx-auto p-5 sm:p-6 space-y-6">
      {/* Top Header */}
      <div className="text-center space-y-2">
        <div className="w-12 h-12 mx-auto rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center shadow-inner">
          <Globe className="w-6 h-6" />
        </div>
        <h2 className="text-2xl font-extrabold text-gray-900 font-['Outfit']">
          Choose Your Preferred Language
        </h2>
        <p className="text-xs text-gray-500">
          अपनी पसंदीदा भाषा चुनें &bull; आपली भाषा निवडा
        </p>

        {/* Voice Assistance Available Pill */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-full text-xs font-semibold">
          <Mic className="w-3.5 h-3.5 text-emerald-600 animate-pulse" />
          <span>Voice assistance available in all languages</span>
        </div>
      </div>

      {/* Language Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {SUPPORTED_LANGUAGES.map((lang) => {
          const isSelected = currentLanguage === lang.code;
          return (
            <button
              key={lang.code}
              onClick={() => onSelectLanguage(lang.code)}
              className={`p-3.5 rounded-xl border text-left transition-all flex items-center justify-between ${
                isSelected
                  ? 'border-emerald-600 bg-emerald-50/80 ring-2 ring-emerald-500/50 shadow-sm'
                  : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
              }`}
            >
              <div>
                <span className="text-sm font-bold text-gray-900 block font-['Outfit']">
                  {lang.nativeName}
                </span>
                <span className="text-xs text-gray-500">
                  {lang.name} &bull; {lang.subtext}
                </span>
              </div>
              {isSelected ? (
                <div className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
                  <Check className="w-3 h-3 stroke-[3]" />
                </div>
              ) : (
                <div className="w-5 h-5 rounded-full border border-gray-300 shrink-0" />
              )}
            </button>
          );
        })}
      </div>

      {/* Confirmation Button */}
      {onContinue && (
        <div className="pt-2">
          <button
            onClick={onContinue}
            className="w-full py-3.5 px-6 rounded-xl bg-[#1B4332] hover:bg-[#255742] text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 transition-all active:scale-98"
          >
            <span>Confirm & Continue</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};
