import React, { useState } from 'react';
import { User, MapPin, Sprout, Droplets, Calendar, Maximize, CheckCircle2, ShieldCheck } from 'lucide-react';
import { FarmerProfile, SupportedLanguage } from '../../types';
import { SUPPORTED_LANGUAGES } from '../../data/mockData';

interface FarmerProfileScreenProps {
  profile: FarmerProfile;
  onSave: (updated: FarmerProfile) => void;
  onClose?: () => void;
}

export const FarmerProfileScreen: React.FC<FarmerProfileScreenProps> = ({
  profile,
  onSave,
  onClose
}) => {
  const [formData, setFormData] = useState<FarmerProfile>(profile);
  const [isSavedAlert, setIsSavedAlert] = useState(false);

  const cropSuggestions = [
    'Cotton (BT Cotton-II)',
    'Wheat (Sharbati)',
    'Paddy / Rice (Basmati)',
    'Soybean (JS 335)',
    'Sugarcane (Co 86032)',
    'Tomato (Abhinav)'
  ];

  const irrigationOptions: FarmerProfile['irrigationType'][] = [
    'Drip',
    'Flood',
    'Sprinkler',
    'Rainfed'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    setIsSavedAlert(true);
    setTimeout(() => setIsSavedAlert(false), 3000);
    if (onClose) {
      setTimeout(onClose, 800);
    }
  };

  return (
    <div className="max-w-xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 font-['Outfit'] flex items-center gap-2">
            <User className="w-6 h-6 text-[#2D6A4F]" />
            <span>Farmer & Field Profile</span>
          </h2>
          <p className="text-xs text-gray-500 mt-0.5">
            Calibrates disease thresholds and microclimate algorithms to your specific crop.
          </p>
        </div>
        {isSavedAlert && (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-semibold animate-fadeIn">
            <CheckCircle2 className="w-3.5 h-3.5" /> Saved
          </span>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-4 bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
        {/* Farmer Name */}
        <div>
          <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
            Farmer Name
          </label>
          <input
            type="text"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 outline-none"
            placeholder="e.g. Rahul Patil"
            required
          />
        </div>

        {/* Location & State */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1 flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-emerald-600" />
              <span>Location / Village</span>
            </label>
            <input
              type="text"
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 outline-none"
              placeholder="e.g. Panvel, Raigad"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
              State / Region
            </label>
            <input
              type="text"
              value={formData.state}
              onChange={(e) => setFormData({ ...formData, state: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 outline-none"
              placeholder="e.g. Maharashtra"
              required
            />
          </div>
        </div>

        {/* Crop Selection */}
        <div>
          <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1 flex items-center gap-1">
            <Sprout className="w-3.5 h-3.5 text-emerald-600" />
            <span>Primary Crop</span>
          </label>
          <input
            type="text"
            value={formData.crop}
            onChange={(e) => setFormData({ ...formData, crop: e.target.value })}
            className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 outline-none mb-2"
            placeholder="Enter crop name..."
            required
          />

          {/* Quick pills */}
          <div className="flex flex-wrap gap-1.5">
            {cropSuggestions.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setFormData({ ...formData, crop: c })}
                className={`text-[11px] px-2.5 py-1 rounded-full border transition-colors ${
                  formData.crop === c
                    ? 'bg-emerald-600 text-white border-emerald-600 font-semibold'
                    : 'bg-gray-50 text-gray-700 border-gray-200 hover:bg-gray-100'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {/* Variety & Growth Stage */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
              Crop Variety / Hybrid
            </label>
            <input
              type="text"
              value={formData.cropVariety}
              onChange={(e) => setFormData({ ...formData, cropVariety: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 outline-none"
              placeholder="e.g. Kaveri Jadoo"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
              Current Growth Stage
            </label>
            <input
              type="text"
              value={formData.growthStage}
              onChange={(e) => setFormData({ ...formData, growthStage: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 outline-none"
              placeholder="e.g. Flowering & Boll Formation"
            />
          </div>
        </div>

        {/* Field Size & Sowing Date */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1 flex items-center gap-1">
              <Maximize className="w-3.5 h-3.5 text-emerald-600" />
              <span>Approx. Field Size</span>
            </label>
            <input
              type="text"
              value={formData.fieldSize}
              onChange={(e) => setFormData({ ...formData, fieldSize: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 outline-none"
              placeholder="e.g. 4.5 Acres"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-emerald-600" />
              <span>Sowing Date / Age</span>
            </label>
            <input
              type="text"
              value={formData.sowingDate}
              onChange={(e) => setFormData({ ...formData, sowingDate: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 outline-none"
              placeholder="e.g. June 18 (62 days old)"
            />
          </div>
        </div>

        {/* Irrigation Type */}
        <div>
          <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5 flex items-center gap-1">
            <Droplets className="w-3.5 h-3.5 text-emerald-600" />
            <span>Irrigation Type</span>
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {irrigationOptions.map((type) => (
              <button
                key={type}
                type="button"
                onClick={() => setFormData({ ...formData, irrigationType: type })}
                className={`py-2 px-3 rounded-xl border text-xs font-semibold transition-all ${
                  formData.irrigationType === type
                    ? 'bg-[#1B4332] text-white border-[#1B4332] shadow-sm'
                    : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {/* Submit */}
        <div className="pt-3">
          <button
            type="submit"
            className="w-full py-3.5 px-6 rounded-xl bg-[#1B4332] hover:bg-[#255742] text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 transition-all active:scale-98"
          >
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Save Profile & Calibrate Intelligence</span>
          </button>
        </div>
      </form>
    </div>
  );
};
