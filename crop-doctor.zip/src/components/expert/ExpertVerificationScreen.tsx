import React, { useState } from 'react';
import { UserCheck, ShieldCheck, CheckCircle2, Clock, ArrowRight, Building, FileText, Send } from 'lucide-react';
import { ScanRecord, AppScreen } from '../../types';

interface ExpertVerificationScreenProps {
  currentScan: ScanRecord;
  onNavigate: (screen: AppScreen) => void;
}

export const ExpertVerificationScreen: React.FC<ExpertVerificationScreenProps> = ({
  currentScan,
  onNavigate
}) => {
  const [expertType, setExpertType] = useState<'kvk' | 'officer' | 'agronomist'>('kvk');
  const [urgency, setUrgency] = useState<'standard' | 'high'>('high');
  const [notes, setNotes] = useState('Observed spreading on Plot 4B lower leaves after heavy monsoon shower.');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-5 sm:py-7 space-y-6 animate-fadeIn pb-24 md:pb-12">
      {/* Header */}
      <div>
        <span className="px-2.5 py-0.5 rounded-full bg-purple-100 text-purple-800 text-[11px] font-bold font-mono">
          HUMAN-IN-THE-LOOP SAFETY NET
        </span>
        <h2 className="text-2xl sm:text-3xl font-black text-gray-900 font-['Outfit'] mt-1">
          Request Expert Verification
        </h2>
        <p className="text-xs text-gray-500">
          When AI confidence is low or symptoms appear unusual, submit your scan to certified agronomists.
        </p>
      </div>

      {isSubmitted ? (
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-emerald-300 shadow-md text-center space-y-5">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-8 h-8 stroke-[2.5]" />
          </div>

          <div>
            <h3 className="text-xl font-bold text-gray-900 font-['Outfit']">
              Verification Request Dispatched!
            </h3>
            <p className="text-xs text-gray-600 mt-1 max-w-sm mx-auto">
              Reference ID: <strong>#CP-EXP-8942</strong>. A certified Krishi Vigyan Kendra specialist has been assigned to your case.
            </p>
          </div>

          {/* Stepper Status Tracker: Submitted -> Under Review -> Verified */}
          <div className="p-4 bg-gray-50 rounded-2xl border border-gray-200 text-left space-y-3">
            <span className="text-[11px] font-mono text-gray-400 font-bold uppercase block">
              STATUS TRACKER
            </span>
            <div className="space-y-3 text-xs">
              <div className="flex items-center gap-2.5 text-emerald-800 font-bold">
                <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px]">
                  ✓
                </span>
                <span>Submitted with multi-modal telemetry payload</span>
              </div>
              <div className="flex items-center gap-2.5 text-amber-800 font-bold">
                <span className="w-5 h-5 rounded-full bg-amber-500 text-white flex items-center justify-center text-[10px] animate-pulse">
                  ●
                </span>
                <span>Under Review by Regional Agronomist (ETA: 3 hrs)</span>
              </div>
              <div className="flex items-center gap-2.5 text-gray-400">
                <span className="w-5 h-5 rounded-full border border-gray-300 flex items-center justify-center text-[10px]">
                  3
                </span>
                <span>Verified Diagnostic & Countermeasure Prescription</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigate('dashboard')}
            className="w-full py-3 px-4 rounded-xl bg-[#1B4332] text-white font-bold text-xs shadow-sm hover:bg-[#255742]"
          >
            Return to Dashboard
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Summary of Scanned Leaf Payload */}
          <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-2xs flex items-center gap-3.5">
            <img
              src={currentScan.imageUrl}
              alt="Scan"
              className="w-16 h-16 rounded-xl object-cover border border-gray-200 shrink-0"
            />
            <div className="text-xs">
              <span className="text-gray-400 font-mono text-[10px] block">ATTACHED OBSERVATION</span>
              <h4 className="font-bold text-gray-900 text-sm font-['Outfit']">
                {currentScan.primaryFinding}
              </h4>
              <p className="text-gray-500 mt-0.5">
                AI Confidence: <strong>{currentScan.confidence}%</strong> &bull; Severity: <strong>{currentScan.severityPercent}%</strong>
              </p>
            </div>
          </div>

          {/* Expert Selection */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-xs space-y-3">
            <label className="block text-xs font-bold text-gray-700 uppercase font-mono">
              Choose Verification Authority:
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <button
                type="button"
                onClick={() => setExpertType('kvk')}
                className={`p-3 rounded-xl border text-left transition-all ${
                  expertType === 'kvk'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-950 ring-2 ring-emerald-500/40'
                    : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                }`}
              >
                <Building className="w-4 h-4 text-emerald-700 mb-1" />
                <span className="text-xs font-bold block">KVK Scientist</span>
                <span className="text-[10px] text-gray-500">Government research center</span>
              </button>

              <button
                type="button"
                onClick={() => setExpertType('officer')}
                className={`p-3 rounded-xl border text-left transition-all ${
                  expertType === 'officer'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-950 ring-2 ring-emerald-500/40'
                    : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                }`}
              >
                <UserCheck className="w-4 h-4 text-blue-700 mb-1" />
                <span className="text-xs font-bold block">District Agri Officer</span>
                <span className="text-[10px] text-gray-500">Panvel Taluka extension</span>
              </button>

              <button
                type="button"
                onClick={() => setExpertType('agronomist')}
                className={`p-3 rounded-xl border text-left transition-all ${
                  expertType === 'agronomist'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-950 ring-2 ring-emerald-500/40'
                    : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                }`}
              >
                <ShieldCheck className="w-4 h-4 text-purple-700 mb-1" />
                <span className="text-xs font-bold block">Verified Agronomist</span>
                <span className="text-[10px] text-gray-500">Specialist panel review</span>
              </button>
            </div>

            {/* Field notes */}
            <div className="pt-2">
              <label className="block text-xs font-bold text-gray-700 uppercase font-mono mb-1">
                Additional Field Notes / Symptoms:
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={3}
                className="w-full p-3 rounded-xl border border-gray-200 text-xs focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 outline-none"
                placeholder="Note any leaf shedding, wilting, or unusual odors..."
              />
            </div>

            {/* Urgency */}
            <div className="flex items-center gap-3 pt-1">
              <span className="text-xs font-bold text-gray-700 uppercase font-mono">Urgency:</span>
              <button
                type="button"
                onClick={() => setUrgency('standard')}
                className={`px-3 py-1 rounded-lg text-xs font-semibold border ${
                  urgency === 'standard' ? 'bg-gray-800 text-white' : 'bg-gray-50 text-gray-600'
                }`}
              >
                Standard (24h)
              </button>
              <button
                type="button"
                onClick={() => setUrgency('high')}
                className={`px-3 py-1 rounded-lg text-xs font-semibold border ${
                  urgency === 'high' ? 'bg-red-600 text-white border-red-600' : 'bg-gray-50 text-gray-600'
                }`}
              >
                Critical / Rapid Spread (3h)
              </button>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-4 px-6 rounded-2xl bg-[#1B4332] hover:bg-[#255742] text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 transition-all"
          >
            <Send className="w-4 h-4 text-emerald-300" />
            <span>Submit to Agricultural Extension</span>
          </button>
        </form>
      )}
    </div>
  );
};
