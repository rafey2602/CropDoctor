import React from 'react';
import {
  Globe,
  WifiOff,
  Sliders,
  Bell,
  Cloud,
  ShieldCheck,
  Info,
  ChevronRight,
  ArrowRight,
  Sparkles
} from 'lucide-react';
import { SupportedLanguage, AppScreen } from '../../types';
import { SUPPORTED_LANGUAGES } from '../../data/mockData';

interface SettingsScreenProps {
  currentLanguage: SupportedLanguage;
  onSelectLanguage: (lang: SupportedLanguage) => void;
  isOffline: boolean;
  onToggleOffline: () => void;
  onNavigate: (screen: AppScreen) => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  currentLanguage,
  onSelectLanguage,
  isOffline,
  onToggleOffline,
  onNavigate
}) => {
  const currentLangObj = SUPPORTED_LANGUAGES.find((l) => l.code === currentLanguage) || SUPPORTED_LANGUAGES[0];

  return (
    <div className="max-w-2xl mx-auto px-4 py-5 sm:py-7 space-y-6 animate-fadeIn pb-24 md:pb-12">
      {/* Header */}
      <div>
        <span className="px-2.5 py-0.5 rounded-full bg-gray-100 text-gray-800 text-[11px] font-bold font-mono">
          PREFERENCES & SYSTEM
        </span>
        <h2 className="text-2xl sm:text-3xl font-black text-gray-900 font-['Outfit'] mt-1">
          Settings
        </h2>
        <p className="text-xs text-gray-500">
          Configure regional telemetry, offline sync cache, and diagnostic preferences.
        </p>
      </div>

      <div className="space-y-4">
        {/* Language Selection Setting */}
        <div
          onClick={() => onNavigate('language-select')}
          className="bg-white p-4 rounded-2xl border border-gray-200 hover:border-emerald-500 transition-all cursor-pointer shadow-2xs flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-gray-900">App Language</h4>
              <p className="text-xs text-gray-500">
                Currently: <strong>{currentLangObj.name} ({currentLangObj.nativeName})</strong>
              </p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-400" />
        </div>

        {/* Offline Simulation Setting */}
        <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-2xs flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
              <WifiOff className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-gray-900">Offline Field Cache Mode</h4>
              <p className="text-xs text-gray-500">
                Stores edge computer vision models locally for areas with zero cellular connectivity.
              </p>
            </div>
          </div>

          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={isOffline}
              onChange={onToggleOffline}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
          </label>
        </div>

        {/* Farmer Profile Quick Link */}
        <div
          onClick={() => onNavigate('farmer-profile')}
          className="bg-white p-4 rounded-2xl border border-gray-200 hover:border-emerald-500 transition-all cursor-pointer shadow-2xs flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-gray-900">Farm & Crop Profile</h4>
              <p className="text-xs text-gray-500">
                Update crop variety, sowing date, and acreage calibration.
              </p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-400" />
        </div>

        {/* Units Configuration */}
        <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-2xs space-y-3">
          <h4 className="text-xs font-bold text-gray-700 uppercase font-mono">
            Measurement Units
          </h4>
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 bg-gray-50 rounded-xl border border-gray-200 flex items-center justify-between">
              <span>Land Area Unit:</span>
              <strong className="text-gray-900">Acres (ac)</strong>
            </div>
            <div className="p-3 bg-gray-50 rounded-xl border border-gray-200 flex items-center justify-between">
              <span>Temperature Unit:</span>
              <strong className="text-gray-900">Celsius (°C)</strong>
            </div>
          </div>
        </div>

        {/* About Crop Doctor Box */}
        <div className="bg-[#F4F8F5] p-5 rounded-2xl border border-emerald-100 space-y-2 text-xs text-gray-700">
          <div className="flex items-center gap-2 text-emerald-900 font-bold font-['Outfit'] text-sm">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <span>Crop Doctor &bull; See. Understand. Predict. Act.</span>
          </div>
          <p className="leading-relaxed">
            Version 2.4.0 &bull; Built with edge AI models, spatial microclimate inference, and validated against ICAR and Krishi Vigyan Kendra agricultural datasets.
          </p>
        </div>
      </div>
    </div>
  );
};
