import React, { useState } from 'react';
import { MapPin, AlertTriangle, ArrowRight, ShieldCheck, Layers, Info, CheckCircle2 } from 'lucide-react';
import { MOCK_FIELD_ZONES } from '../../data/mockData';
import { AppScreen, FieldZone } from '../../types';

interface CropHealthMapScreenProps {
  onNavigate: (screen: AppScreen) => void;
}

export const CropHealthMapScreen: React.FC<CropHealthMapScreenProps> = ({ onNavigate }) => {
  const [selectedZone, setSelectedZone] = useState<FieldZone>(MOCK_FIELD_ZONES[2]); // Zone C (High Risk) by default

  const getStatusColor = (status: FieldZone['status']) => {
    switch (status) {
      case 'healthy':
        return 'bg-emerald-500 text-white';
      case 'moderate':
        return 'bg-amber-500 text-white';
      case 'high-risk':
        return 'bg-red-500 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-5 sm:py-7 space-y-6 animate-fadeIn pb-24 md:pb-12">
      {/* Header */}
      <div>
        <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-bold font-mono">
          PRECISION SPATIAL MAPPING
        </span>
        <h2 className="text-2xl sm:text-3xl font-black text-gray-900 font-['Outfit'] mt-1">
          Crop Health Field Map
        </h2>
        <p className="text-xs text-gray-500">
          Visual partition of your 4.5-acre field into 4 micro-zones to target interventions where disease is localized.
        </p>
      </div>

      {/* Interactive 2x2 Field Zone Grid Map */}
      <div className="bg-white p-5 rounded-3xl border border-gray-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between text-xs">
          <span className="font-bold text-gray-700 uppercase font-mono">
            Spatial Topography (Plot 4B)
          </span>
          <span className="text-gray-400 font-mono text-[11px]">
            Tap any quadrant to inspect
          </span>
        </div>

        {/* 2x2 Interactive Field Quadrants */}
        <div className="grid grid-cols-2 gap-3 aspect-square sm:aspect-[16/10] p-3 bg-[#E8EFEA] rounded-2xl border-2 border-dashed border-emerald-300">
          {MOCK_FIELD_ZONES.map((zone) => {
            const isSelected = selectedZone.id === zone.id;
            const isCritical = zone.status === 'high-risk';

            return (
              <button
                key={zone.id}
                onClick={() => setSelectedZone(zone)}
                className={`relative p-4 rounded-xl text-left transition-all flex flex-col justify-between overflow-hidden border-2 ${
                  isSelected
                    ? 'ring-4 ring-emerald-600/40 border-emerald-700 shadow-lg'
                    : 'border-transparent hover:border-emerald-400 hover:shadow-xs'
                } ${
                  zone.status === 'healthy'
                    ? 'bg-emerald-100/90 text-emerald-950'
                    : zone.status === 'moderate'
                    ? 'bg-amber-100/90 text-amber-950'
                    : 'bg-red-100/90 text-red-950'
                }`}
              >
                {/* Hotspot Pulse animation for high risk */}
                {isCritical && (
                  <div className="absolute top-2 right-2 flex items-center gap-1 bg-red-600 text-white text-[9px] font-mono px-1.5 py-0.5 rounded font-bold">
                    <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                    <span>HOTSPOT</span>
                  </div>
                )}

                <div>
                  <span className="text-xs font-mono font-bold uppercase tracking-wider block opacity-75">
                    {zone.id.toUpperCase()} &bull; {zone.area}
                  </span>
                  <h4 className="text-base sm:text-lg font-black font-['Outfit'] mt-0.5">
                    {zone.name}
                  </h4>
                </div>

                <div className="mt-3 flex items-end justify-between">
                  <div>
                    <span className="text-[10px] block opacity-80">Health Index</span>
                    <span className="text-2xl font-black font-['Outfit']">
                      {zone.healthScore}
                    </span>
                  </div>

                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${getStatusColor(
                      zone.status
                    )}`}
                  >
                    {zone.status === 'high-risk'
                      ? 'High Risk'
                      : zone.status === 'moderate'
                      ? 'Moderate'
                      : 'Healthy'}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center justify-center gap-4 text-[11px] font-mono text-gray-600 pt-1">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
            <span>Healthy (&gt;80)</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
            <span>Moderate Stress (60-80)</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
            <span>High Risk (&lt;60)</span>
          </span>
        </div>
      </div>

      {/* Selected Zone Deep Dive Card */}
      <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between border-b border-gray-100 pb-2.5">
          <div>
            <span className="text-[10px] font-mono font-bold text-gray-400 uppercase">
              Inspecting Selected Zone
            </span>
            <h3 className="text-lg font-bold text-gray-900 font-['Outfit']">
              {selectedZone.name} ({selectedZone.area})
            </h3>
          </div>
          <span className="text-xs font-mono font-bold text-gray-500">
            Last Checked: {selectedZone.lastScanned}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="p-3 bg-gray-50 rounded-xl">
            <span className="font-bold text-gray-700 block font-mono text-[10px] uppercase">
              Current Finding:
            </span>
            <p className="text-gray-900 font-medium mt-0.5">{selectedZone.notes}</p>
          </div>

          <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-100">
            <span className="font-bold text-emerald-900 block font-mono text-[10px] uppercase">
              Recommended Spatial Action:
            </span>
            <p className="text-emerald-800 font-medium mt-0.5">
              {selectedZone.status === 'high-risk'
                ? 'Target spray only in this quadrant to save chemical costs and prevent pesticide drift.'
                : 'Maintain current drip schedule. Monitor perimeter boundary for spore migration.'}
            </p>
          </div>
        </div>

        {selectedZone.status === 'high-risk' && (
          <button
            onClick={() => onNavigate('actions')}
            className="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold text-xs transition-colors flex items-center justify-center gap-1.5"
          >
            <AlertTriangle className="w-4 h-4" />
            <span>Deploy Action Plan for {selectedZone.name}</span>
          </button>
        )}
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between pt-1">
        <button
          onClick={() => onNavigate('dashboard')}
          className="text-xs font-bold text-gray-600 hover:text-gray-900"
        >
          &larr; Back to Dashboard
        </button>

        <button
          onClick={() => onNavigate('alerts')}
          className="py-3 px-5 rounded-xl bg-[#1B4332] hover:bg-[#255742] text-white font-bold text-xs shadow-sm flex items-center gap-2"
        >
          <span>View Early Warning Alerts</span>
          <ArrowRight className="w-4 h-4 text-emerald-300" />
        </button>
      </div>
    </div>
  );
};
