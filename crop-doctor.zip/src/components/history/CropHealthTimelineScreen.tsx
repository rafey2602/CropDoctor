import React from 'react';
import { Activity, TrendingDown, ArrowRight, Calendar, AlertTriangle, CheckCircle2, ChevronRight } from 'lucide-react';
import { TIMELINE_EVENTS } from '../../data/mockData';
import { AppScreen } from '../../types';

interface CropHealthTimelineScreenProps {
  onNavigate: (screen: AppScreen) => void;
}

export const CropHealthTimelineScreen: React.FC<CropHealthTimelineScreenProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-3xl mx-auto px-4 py-5 sm:py-7 space-y-6 animate-fadeIn pb-24 md:pb-12">
      {/* Header */}
      <div>
        <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-bold font-mono">
          LONGITUDINAL RECOVERY MONITOR
        </span>
        <h2 className="text-2xl sm:text-3xl font-black text-gray-900 font-['Outfit'] mt-1">
          Crop Health Timeline
        </h2>
        <p className="text-xs text-gray-500">
          Track the trajectory of your field over the 30-day vegetative cycle to see if intervention stops the drop.
        </p>
      </div>

      {/* Trajectory Trend Line Chart Card */}
      <div className="bg-white p-5 rounded-3xl border border-gray-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[11px] text-gray-500 uppercase font-mono block">
              30-Day Health Trend
            </span>
            <div className="text-lg font-black text-gray-900 font-['Outfit']">
              Health Score: 92 &rarr; 74 (Down 18 pts)
            </div>
          </div>
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-100 text-amber-800 text-xs font-bold">
            <TrendingDown className="w-3.5 h-3.5" />
            <span>Down 8% Last 7 Days</span>
          </span>
        </div>

        {/* SVG Health Trend Graph */}
        <div className="relative aspect-[16/7] w-full bg-[#F4F8F5] rounded-2xl p-4 border border-emerald-100">
          <svg className="w-full h-full" viewBox="0 0 400 140">
            {/* Guide Gridlines */}
            <line x1="40" y1="20" x2="380" y2="20" stroke="#E5E7EB" strokeWidth="1" strokeDasharray="3 3" />
            <line x1="40" y1="60" x2="380" y2="60" stroke="#E5E7EB" strokeWidth="1" strokeDasharray="3 3" />
            <line x1="40" y1="100" x2="380" y2="100" stroke="#E5E7EB" strokeWidth="1" strokeDasharray="3 3" />

            <text x="35" y="25" fill="#9CA3AF" fontSize="9" textAnchor="end">95</text>
            <text x="35" y="65" fill="#9CA3AF" fontSize="9" textAnchor="end">85</text>
            <text x="35" y="105" fill="#9CA3AF" fontSize="9" textAnchor="end">75</text>

            {/* Area under curve */}
            <path
              d="M 60 25 L 160 40 L 270 85 L 360 102 L 360 130 L 60 130 Z"
              fill="rgba(16, 185, 129, 0.15)"
            />

            {/* Trend Line */}
            <path
              d="M 60 25 L 160 40 L 270 85 L 360 102"
              fill="none"
              stroke="#2D6A4F"
              strokeWidth="3.5"
              strokeLinecap="round"
            />

            {/* Nodes */}
            <circle cx="60" cy="25" r="5" fill="#10B981" stroke="#FFF" strokeWidth="2" />
            <text x="60" y="15" textAnchor="middle" fill="#065F46" fontSize="9" fontWeight="bold">Day 1 (92)</text>

            <circle cx="160" cy="40" r="5" fill="#10B981" stroke="#FFF" strokeWidth="2" />
            <text x="160" y="32" textAnchor="middle" fill="#065F46" fontSize="9" fontWeight="bold">Day 14 (87)</text>

            <circle cx="270" cy="85" r="5" fill="#F59E0B" stroke="#FFF" strokeWidth="2" />
            <text x="270" y="77" textAnchor="middle" fill="#B45309" fontSize="9" fontWeight="bold">Day 28 (78)</text>

            <circle cx="360" cy="102" r="6" fill="#EF4444" stroke="#FFF" strokeWidth="2.5" />
            <text x="360" y="120" textAnchor="middle" fill="#B91C1C" fontSize="9" fontWeight="bold">Today (74)</text>
          </svg>
        </div>
      </div>

      {/* Sequential Timeline Events Cards */}
      <div className="relative pl-6 sm:pl-8 border-l-2 border-emerald-200 space-y-6">
        {TIMELINE_EVENTS.map((event) => (
          <div key={event.id} className="relative group">
            {/* Timeline bullet icon */}
            <div className="absolute -left-[31px] sm:-left-[39px] top-1.5 w-6 h-6 rounded-full bg-white border-2 border-emerald-600 flex items-center justify-center">
              <span className="w-2 h-2 rounded-full bg-emerald-600" />
            </div>

            <div className="bg-white p-4 sm:p-5 rounded-2xl border border-gray-200 shadow-2xs hover:border-emerald-400 transition-all">
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-bold text-gray-500 flex items-center gap-1 font-mono">
                  <Calendar className="w-3.5 h-3.5" />
                  {event.date} ({event.day})
                </span>
                <span className="font-black text-gray-900 font-['Outfit'] text-sm">
                  Score: {event.score}/100
                </span>
              </div>

              <h4 className="text-base font-bold text-gray-900 font-['Outfit']">
                {event.title}
              </h4>
              <p className="text-xs text-gray-600 mt-1">
                {event.description}
              </p>

              {event.actionTaken && (
                <div className="mt-2.5 p-2 bg-emerald-50 rounded-lg text-xs text-emerald-900 font-medium">
                  <strong>Action Logged:</strong> {event.actionTaken}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between pt-2">
        <button
          onClick={() => onNavigate('dashboard')}
          className="text-xs font-bold text-gray-600 hover:text-gray-900"
        >
          &larr; Back to Dashboard
        </button>

        <button
          onClick={() => onNavigate('field-map')}
          className="py-3 px-5 rounded-xl bg-[#1B4332] hover:bg-[#255742] text-white font-bold text-xs shadow-sm flex items-center gap-2"
        >
          <span>View Spatial Field Map</span>
          <ArrowRight className="w-4 h-4 text-emerald-300" />
        </button>
      </div>
    </div>
  );
};
