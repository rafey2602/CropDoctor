import React, { useState } from 'react';
import { Search, Filter, Calendar, ArrowRight, Activity, ChevronRight, Sprout } from 'lucide-react';
import { MOCK_HISTORY_RECORDS } from '../../data/mockData';
import { AppScreen, ScanRecord } from '../../types';

interface CropHistoryScreenProps {
  onNavigate: (screen: AppScreen) => void;
  onSelectRecord: (record: ScanRecord) => void;
}

export const CropHistoryScreen: React.FC<CropHistoryScreenProps> = ({
  onNavigate,
  onSelectRecord
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCrop, setSelectedCrop] = useState('all');
  const [selectedSeverity, setSelectedSeverity] = useState('all');

  const filtered = MOCK_HISTORY_RECORDS.filter((rec) => {
    const matchesSearch =
      rec.primaryFinding.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.crop.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCrop = selectedCrop === 'all' || rec.crop.toLowerCase().includes(selectedCrop.toLowerCase());
    const matchesSeverity =
      selectedSeverity === 'all' ||
      (selectedSeverity === 'low' && rec.severityPercent < 20) ||
      (selectedSeverity === 'moderate' && rec.severityPercent >= 20 && rec.severityPercent <= 45) ||
      (selectedSeverity === 'high' && rec.severityPercent > 45);

    return matchesSearch && matchesCrop && matchesSeverity;
  });

  return (
    <div className="max-w-3xl mx-auto px-4 py-5 sm:py-7 space-y-5 animate-fadeIn pb-24 md:pb-12">
      {/* Header */}
      <div>
        <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-bold font-mono">
          AUDITABLE FIELD ARCHIVE
        </span>
        <h2 className="text-2xl sm:text-3xl font-black text-gray-900 font-['Outfit'] mt-1">
          Crop Scan History
        </h2>
        <p className="text-xs text-gray-500">
          Review all logged leaf and canopy observations with differential diagnoses.
        </p>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-2xs space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Search by disease, leaf symptom, or crop..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-gray-200 text-xs sm:text-sm focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 outline-none"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="text-gray-400 text-[11px] font-mono uppercase font-bold flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" /> Filter:
          </span>

          <select
            value={selectedCrop}
            onChange={(e) => setSelectedCrop(e.target.value)}
            className="px-2.5 py-1.5 rounded-lg border border-gray-200 bg-gray-50 text-gray-700 outline-none text-xs"
          >
            <option value="all">All Crops</option>
            <option value="cotton">Cotton</option>
            <option value="wheat">Wheat</option>
            <option value="rice">Rice</option>
            <option value="tomato">Tomato</option>
          </select>

          <select
            value={selectedSeverity}
            onChange={(e) => setSelectedSeverity(e.target.value)}
            className="px-2.5 py-1.5 rounded-lg border border-gray-200 bg-gray-50 text-gray-700 outline-none text-xs"
          >
            <option value="all">All Severities</option>
            <option value="low">Low (&lt; 20%)</option>
            <option value="moderate">Moderate (20-45%)</option>
            <option value="high">High (&gt; 45%)</option>
          </select>
        </div>
      </div>

      {/* History Records List */}
      <div className="space-y-3">
        {filtered.map((record) => (
          <div
            key={record.id}
            onClick={() => {
              onSelectRecord(record);
              onNavigate('result');
            }}
            className="p-4 bg-white rounded-2xl border border-gray-200 hover:border-emerald-500 shadow-2xs hover:shadow-xs transition-all cursor-pointer flex items-center justify-between gap-4 group"
          >
            <div className="flex items-center gap-3.5">
              {/* Thumbnail */}
              <div className="relative w-16 h-16 rounded-xl overflow-hidden bg-black shrink-0 border border-gray-200">
                <img
                  src={record.imageUrl}
                  alt={record.primaryFinding}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <span className="absolute bottom-1 right-1 bg-black/75 text-white font-mono text-[9px] px-1 rounded">
                  {record.healthScore}
                </span>
              </div>

              {/* Finding & Meta */}
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-gray-900 font-['Outfit']">
                    {record.crop}
                  </span>
                  <span className="text-gray-300">&bull;</span>
                  <span className="text-[11px] text-gray-500 font-mono flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-gray-400" />
                    {record.date}
                  </span>
                </div>

                <h4 className="text-sm font-bold text-emerald-950 mt-0.5 group-hover:text-emerald-700 transition-colors">
                  {record.primaryFinding}
                </h4>

                <div className="flex items-center gap-2 mt-1 text-[11px]">
                  <span
                    className={`px-1.5 py-0.2 rounded font-semibold ${
                      record.severityPercent > 40
                        ? 'bg-red-100 text-red-800'
                        : record.severityPercent > 20
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    Severity: {record.severityPercent}%
                  </span>
                  <span className="text-gray-400">&bull;</span>
                  <span className="text-gray-600">Conf: {record.confidence}%</span>
                </div>
              </div>
            </div>

            {/* Right arrow CTA */}
            <div className="text-gray-400 group-hover:text-emerald-700 transition-colors shrink-0">
              <ChevronRight className="w-5 h-5" />
            </div>
          </div>
        ))}

        {filtered.length === 0 && (
          <div className="text-center py-10 bg-white rounded-2xl border border-gray-200 text-gray-500 text-xs">
            No matching scans found for query "{searchQuery}".
          </div>
        )}
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between pt-2">
        <button
          onClick={() => onNavigate('dashboard')}
          className="text-xs font-bold text-gray-600 hover:text-gray-900"
        >
          &larr; Back to Dashboard
        </button>

        <button
          onClick={() => onNavigate('scan')}
          className="py-3 px-5 rounded-xl bg-[#1B4332] hover:bg-[#255742] text-white font-bold text-xs shadow-sm flex items-center gap-2"
        >
          <span>Take New Crop Scan</span>
          <ArrowRight className="w-4 h-4 text-emerald-300" />
        </button>
      </div>
    </div>
  );
};
