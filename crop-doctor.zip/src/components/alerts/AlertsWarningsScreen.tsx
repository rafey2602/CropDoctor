import React, { useState } from 'react';
import { AlertTriangle, Bell, ArrowRight, ShieldCheck, CheckCircle2, ChevronRight, CloudRain, Bug } from 'lucide-react';
import { MOCK_ALERTS } from '../../data/mockData';
import { AppScreen, EarlyWarningAlert } from '../../types';

interface AlertsWarningsScreenProps {
  onNavigate: (screen: AppScreen) => void;
}

export const AlertsWarningsScreen: React.FC<AlertsWarningsScreenProps> = ({ onNavigate }) => {
  const [alerts, setAlerts] = useState<EarlyWarningAlert[]>(MOCK_ALERTS);

  const toggleRead = (id: string) => {
    setAlerts(alerts.map((a) => (a.id === id ? { ...a, isRead: true } : a)));
  };

  const getSeverityBadge = (sev: EarlyWarningAlert['severity']) => {
    switch (sev) {
      case 'high':
        return 'bg-red-100 text-red-800 border-red-300';
      case 'moderate':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      default:
        return 'bg-blue-100 text-blue-800 border-blue-300';
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-5 sm:py-7 space-y-6 animate-fadeIn pb-24 md:pb-12">
      {/* Header */}
      <div>
        <span className="px-2.5 py-0.5 rounded-full bg-red-100 text-red-800 text-[11px] font-bold font-mono">
          PREVENTIVE THRESHOLDS
        </span>
        <h2 className="text-2xl sm:text-3xl font-black text-gray-900 font-['Outfit'] mt-1">
          Alerts & Early Warnings
        </h2>
        <p className="text-xs text-gray-500">
          Proactive notifications triggered by microclimate anomaly sensors and regional outbreak reports.
        </p>
      </div>

      {/* Alerts Stack */}
      <div className="space-y-3.5">
        {alerts.map((alert) => (
          <div
            key={alert.id}
            className={`p-4 sm:p-5 rounded-2xl border transition-all ${
              alert.isRead
                ? 'bg-white border-gray-200'
                : 'bg-red-50/50 border-red-200 shadow-xs'
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div
                  className={`p-2.5 rounded-xl shrink-0 ${
                    alert.severity === 'high'
                      ? 'bg-red-100 text-red-700'
                      : alert.severity === 'moderate'
                      ? 'bg-amber-100 text-amber-700'
                      : 'bg-blue-100 text-blue-700'
                  }`}
                >
                  <AlertTriangle className="w-5 h-5" />
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-bold uppercase border ${getSeverityBadge(
                        alert.severity
                      )}`}
                    >
                      {alert.severity} Urgency
                    </span>
                    <span className="text-[11px] text-gray-400 font-mono">
                      {alert.time}
                    </span>
                  </div>

                  <h3 className="text-sm sm:text-base font-bold text-gray-900 font-['Outfit']">
                    {alert.title}
                  </h3>

                  <p className="text-xs text-gray-600 mt-1 leading-relaxed">
                    {alert.description}
                  </p>

                  <div className="mt-2.5 p-2.5 bg-white rounded-xl border border-gray-100 text-xs text-emerald-900 font-medium">
                    <span className="font-bold block text-[10px] text-gray-400 uppercase font-mono mb-0.5">
                      Recommended Countermeasure:
                    </span>
                    {alert.recommendedAction}
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-3 pt-3 border-t border-gray-100 flex items-center justify-between text-xs">
              {!alert.isRead ? (
                <button
                  onClick={() => toggleRead(alert.id)}
                  className="text-xs text-gray-500 hover:text-gray-900 font-medium"
                >
                  Mark as Read
                </button>
              ) : (
                <span className="text-emerald-700 text-xs font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Reviewed
                </span>
              )}

              <button
                onClick={() => onNavigate('actions')}
                className="text-xs font-bold text-emerald-800 hover:text-emerald-950 flex items-center gap-1"
              >
                <span>Take Action</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between pt-2">
        <button
          onClick={() => onNavigate('dashboard')}
          className="text-xs font-bold text-gray-600 hover:text-gray-900"
        >
          &larr; Back to Dashboard
        </button>

        <button
          onClick={() => onNavigate('assistant')}
          className="py-3 px-5 rounded-xl bg-[#1B4332] hover:bg-[#255742] text-white font-bold text-xs shadow-sm flex items-center gap-2"
        >
          <span>Ask AI Agronomist</span>
          <ArrowRight className="w-4 h-4 text-emerald-300" />
        </button>
      </div>
    </div>
  );
};
