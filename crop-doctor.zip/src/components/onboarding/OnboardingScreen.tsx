import React, { useState } from 'react';
import { ArrowRight, Check, ChevronRight, Activity, CloudSun, Calendar, ShieldCheck, Sparkles } from 'lucide-react';

interface OnboardingScreenProps {
  onComplete: () => void;
  onSkip?: () => void;
  currentLanguage?: string;
}

export const OnboardingScreen: React.FC<OnboardingScreenProps> = ({
  onComplete,
  onSkip = onComplete
}) => {
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    {
      title: 'Know your crop before the damage spreads.',
      subtitle: 'Early stress is reversible. Late disease is expensive.',
      description:
        'Traditional plant apps only identify visible decay when yield loss has already occurred. Crop Doctor detects micro-symptoms, stomatal closure, and invisible early stress before spores multiply across the field.',
      renderVisual: () => (
        <div className="w-full max-w-sm bg-[#163627] p-5 rounded-2xl border border-emerald-500/20 shadow-xl space-y-4">
          <div className="text-xs font-bold text-emerald-300 tracking-wider uppercase font-mono">
            Early Action Window
          </div>
          <div className="grid grid-cols-3 gap-2 text-center">
            {/* Stage 1 */}
            <div className="p-3 bg-[#1F4A36] rounded-xl border border-emerald-500/30">
              <div className="w-8 h-8 mx-auto rounded-full bg-emerald-500/20 text-emerald-300 flex items-center justify-center font-bold text-xs mb-1">
                94
              </div>
              <span className="block text-[11px] font-bold text-emerald-200">Healthy</span>
              <span className="text-[10px] text-emerald-400/80">Canopy Vigor</span>
            </div>
            {/* Stage 2 */}
            <div className="p-3 bg-amber-950/40 rounded-xl border border-amber-500/40 ring-2 ring-amber-400/40">
              <div className="w-8 h-8 mx-auto rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center font-bold text-xs mb-1">
                74
              </div>
              <span className="block text-[11px] font-bold text-amber-300">Stressed</span>
              <span className="text-[10px] text-amber-400">Intervene Now</span>
            </div>
            {/* Stage 3 */}
            <div className="p-3 bg-red-950/40 rounded-xl border border-red-500/30 opacity-60">
              <div className="w-8 h-8 mx-auto rounded-full bg-red-500/20 text-red-400 flex items-center justify-center font-bold text-xs mb-1">
                42
              </div>
              <span className="block text-[11px] font-bold text-red-300">Diseased</span>
              <span className="text-[10px] text-red-400">Severe Damage</span>
            </div>
          </div>
          <div className="p-2.5 bg-[#0F261B] rounded-lg text-[11px] text-emerald-200 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping shrink-0" />
            <span>Targeting the <strong>Stressed Window</strong> cuts chemical usage by up to 60%.</span>
          </div>
        </div>
      )
    },
    {
      title: 'AI that looks beyond the leaf.',
      subtitle: 'Multimodal intelligence connects leaf images with field reality.',
      description:
        'A leaf spot cannot be diagnosed in isolation. Crop Doctor merges computer vision with local microclimate humidity, soil water saturation, crop growth stage, and historical trajectory into one definitive health index.',
      renderVisual: () => (
        <div className="w-full max-w-sm bg-[#163627] p-5 rounded-2xl border border-emerald-500/20 shadow-xl space-y-3">
          <div className="text-xs font-bold text-emerald-300 tracking-wider uppercase font-mono mb-1">
            Data Fusion Engine
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between p-2.5 bg-[#1C4331] rounded-lg text-xs">
              <div className="flex items-center gap-2 text-emerald-200">
                <Activity className="w-4 h-4 text-emerald-400" />
                <span>Leaf Vision & Lesion Extraction</span>
              </div>
              <span className="text-[11px] font-mono text-emerald-300 font-bold">✓ 91% match</span>
            </div>

            <div className="flex items-center justify-between p-2.5 bg-[#1C4331] rounded-lg text-xs">
              <div className="flex items-center gap-2 text-emerald-200">
                <CloudSun className="w-4 h-4 text-cyan-400" />
                <span>Microclimate (82% RH, 28°C)</span>
              </div>
              <span className="text-[11px] font-mono text-cyan-300 font-bold">Fungal High</span>
            </div>

            <div className="flex items-center justify-between p-2.5 bg-[#1C4331] rounded-lg text-xs">
              <div className="flex items-center gap-2 text-emerald-200">
                <Calendar className="w-4 h-4 text-amber-400" />
                <span>Crop Stage (Flowering Day 62)</span>
              </div>
              <span className="text-[11px] font-mono text-amber-300 font-bold">Susceptible</span>
            </div>
          </div>

          <div className="pt-2 flex items-center justify-center gap-2 text-xs font-bold text-white bg-emerald-700/60 p-2 rounded-xl border border-emerald-400/30">
            <Sparkles className="w-4 h-4 text-emerald-300 animate-spin" />
            <span>Unified Crop Health Score: 74 / 100</span>
          </div>
        </div>
      )
    },
    {
      title: 'Turn detection into action.',
      subtitle: 'From classification to prioritized field action.',
      description:
        'Instead of an overwhelming list of expensive sprays, get ranked, actionable guidance: What to do right now, what to inspect within 24 hours, what to monitor, and when to seek district agronomist help.',
      renderVisual: () => (
        <div className="w-full max-w-sm bg-[#163627] p-5 rounded-2xl border border-emerald-500/20 shadow-xl space-y-2.5">
          <div className="text-xs font-bold text-emerald-300 tracking-wider uppercase font-mono mb-2">
            Prioritized Action Stack
          </div>

          <div className="p-2.5 bg-red-950/40 border border-red-500/30 rounded-xl flex items-start gap-2.5">
            <span className="px-1.5 py-0.5 bg-red-600 text-white rounded text-[10px] font-extrabold uppercase shrink-0">
              1 DO NOW
            </span>
            <p className="text-xs text-red-100 leading-tight">
              Inspect nearby 20 plants for circular halo spots.
            </p>
          </div>

          <div className="p-2.5 bg-amber-950/40 border border-amber-500/30 rounded-xl flex items-start gap-2.5">
            <span className="px-1.5 py-0.5 bg-amber-600 text-white rounded text-[10px] font-extrabold uppercase shrink-0">
              2 24 HOURS
            </span>
            <p className="text-xs text-amber-100 leading-tight">
              Improve furrow airflow; pause overhead flood irrigation.
            </p>
          </div>

          <div className="p-2.5 bg-blue-950/40 border border-blue-500/30 rounded-xl flex items-start gap-2.5">
            <span className="px-1.5 py-0.5 bg-blue-600 text-white rounded text-[10px] font-extrabold uppercase shrink-0">
              3 MONITOR
            </span>
            <p className="text-xs text-blue-100 leading-tight">
              Re-scan marked leaf in 48h to evaluate lesion spread.
            </p>
          </div>
        </div>
      )
    }
  ];

  const current = steps[currentStep];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
    }
  };

  return (
    <div className="min-h-[90vh] bg-[#0E2419] text-white flex flex-col justify-between p-6 sm:p-10 max-w-lg mx-auto">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <span className="text-xs font-bold text-emerald-400 tracking-wider">CROP DOCTOR</span>
          <span className="text-gray-500">&bull;</span>
          <span className="text-xs text-gray-400">Step {currentStep + 1} of 3</span>
        </div>
        <button
          onClick={onSkip}
          className="text-xs text-gray-400 hover:text-emerald-300 font-medium py-1 px-2"
        >
          Skip
        </button>
      </div>

      {/* Visual in center */}
      <div className="my-6 flex items-center justify-center">
        {current.renderVisual()}
      </div>

      {/* Text Info */}
      <div className="space-y-2.5">
        <h2 className="text-2xl sm:text-3xl font-bold font-['Outfit'] text-white leading-tight">
          {current.title}
        </h2>
        <p className="text-sm font-semibold text-emerald-300">
          {current.subtitle}
        </p>
        <p className="text-xs text-gray-300 leading-relaxed">
          {current.description}
        </p>
      </div>

      {/* Navigation Indicators & CTA */}
      <div className="pt-8 space-y-4">
        {/* Step dots */}
        <div className="flex items-center justify-center gap-2">
          {steps.map((_, i) => (
            <div
              key={i}
              className={`h-1.5 rounded-full transition-all ${
                i === currentStep
                  ? 'w-7 bg-emerald-400'
                  : 'w-2 bg-emerald-950/80 border border-emerald-800'
              }`}
            />
          ))}
        </div>

        <button
          onClick={handleNext}
          className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 text-[#0E2419] font-bold text-sm shadow-lg flex items-center justify-center gap-2 transition-all active:scale-98"
        >
          <span>{currentStep === steps.length - 1 ? 'Get Started' : 'Continue'}</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
