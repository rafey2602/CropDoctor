import React, { useEffect } from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';

interface SplashScreenProps {
  onComplete?: () => void;
  onFinish?: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete, onFinish }) => {
  const handleProceed = onComplete || onFinish || (() => {});
  useEffect(() => {
    const timer = setTimeout(() => {
      // Auto advance or allow clicking
    }, 4000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="fixed inset-0 z-50 bg-[#0F241A] text-white flex flex-col items-center justify-between p-6 sm:p-12 overflow-hidden select-none">
      {/* Background ambient botanical glow */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-emerald-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-emerald-800/10 rounded-full blur-2xl pointer-events-none" />

      {/* Top subtle pipeline statement */}
      <div className="pt-6 text-center animate-fadeIn">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1A382B] text-emerald-300 text-xs font-semibold tracking-wider uppercase border border-emerald-500/20">
          <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
          Agricultural AI Intelligence Platform
        </span>
      </div>

      {/* Center: Signature Leaf to Digital Pulse Animation */}
      <div className="flex flex-col items-center justify-center text-center my-auto max-w-md w-full relative z-10">
        {/* Animated Botanical & Pulse Wave SVG */}
        <div className="relative w-44 h-44 mb-8 flex items-center justify-center">
          {/* Subtle concentric field rings */}
          <div className="absolute inset-0 rounded-full border border-emerald-500/20 animate-ping opacity-30 duration-1000" />
          <div className="absolute -inset-4 rounded-full border border-emerald-500/10" />

          {/* Core SVG: Leaf contour transitioning into a dynamic digital health pulse */}
          <svg
            viewBox="0 0 200 200"
            className="w-40 h-40 drop-shadow-[0_0_20px_rgba(52,211,153,0.35)]"
          >
            {/* Elegant Botanical Leaf Outline */}
            <path
              d="M100 20 C145 45 175 95 160 145 C150 168 125 180 100 180 C75 180 50 168 40 145 C25 95 55 45 100 20 Z"
              fill="none"
              stroke="#2D6A4F"
              strokeWidth="3"
              strokeDasharray="4 2"
              className="opacity-60"
            />
            {/* Primary Stem */}
            <path
              d="M100 25 L100 178"
              fill="none"
              stroke="#34D399"
              strokeWidth="2"
              className="opacity-70"
            />
            {/* Secondary Biological Leaf Veins */}
            <path
              d="M100 65 Q125 80 145 75 M100 95 Q135 110 152 105 M100 125 Q130 140 142 135"
              fill="none"
              stroke="#34D399"
              strokeWidth="1.5"
              className="opacity-50"
            />
            <path
              d="M100 65 Q75 80 55 75 M100 95 Q65 110 48 105 M100 125 Q70 140 58 135"
              fill="none"
              stroke="#34D399"
              strokeWidth="1.5"
              className="opacity-50"
            />

            {/* Glowing Digital Health Pulse Wave intersecting through the leaf stem */}
            <path
              d="M20 100 L65 100 L75 85 L85 115 L95 65 L105 135 L115 88 L125 108 L135 100 L180 100"
              fill="none"
              stroke="#10B981"
              strokeWidth="3.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="animate-pulse"
            />

            {/* Glowing sensor nodes */}
            <circle cx="95" cy="65" r="4" fill="#6EE7B7" className="animate-ping" />
            <circle cx="105" cy="135" r="4.5" fill="#34D399" />
            <circle cx="100" cy="22" r="3.5" fill="#10B981" />
          </svg>
        </div>

        {/* Brand Name */}
        <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-white font-['Outfit'] mb-3">
          CROP <span className="text-emerald-400 font-extrabold">DOCTOR</span>
        </h1>

        {/* Tagline */}
        <p className="text-lg sm:text-xl font-medium text-emerald-200 tracking-wide mb-2">
          “See. Understand. Predict. Act.”
        </p>

        <p className="text-xs text-gray-400 max-w-xs leading-relaxed">
          From disease detection to continuous crop health intelligence & early action.
        </p>
      </div>

      {/* Bottom Action */}
      <div className="w-full max-w-sm flex flex-col items-center gap-3 pb-4 relative z-10">
        <button
          onClick={handleProceed}
          className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-[#0F241A] font-bold text-base shadow-lg shadow-emerald-900/40 flex items-center justify-center gap-2 transition-all transform active:scale-98"
        >
          <span>Enter Crop Doctor</span>
          <ArrowRight className="w-5 h-5" />
        </button>
        <span className="text-[11px] text-gray-400">
          Designed for smallholder farmers & agronomists
        </span>
      </div>
    </div>
  );
};
