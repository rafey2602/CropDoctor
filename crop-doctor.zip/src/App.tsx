import React, { useState } from 'react';
import {
  AppScreen,
  FarmerProfile,
  SupportedLanguage,
  ScanRecord,
  WeatherData
} from './types';
import {
  DEFAULT_FARMER_PROFILE,
  DEFAULT_WEATHER,
  PRESET_SCENARIOS,
  MOCK_HISTORY_RECORDS
} from './data/mockData';

// Common Layout Components
import { TopAppBar } from './components/common/TopAppBar';
import { BottomNavigation } from './components/common/BottomNavigation';
import { DesktopSidebar } from './components/common/DesktopSidebar';
import { ScenarioModal } from './components/common/ScenarioModal';
import { ProductArchitectureScreen } from './components/common/ProductArchitectureScreen';

// Screens
import { SplashScreen } from './components/onboarding/SplashScreen';
import { OnboardingScreen } from './components/onboarding/OnboardingScreen';
import { LanguageSelectionScreen } from './components/profile/LanguageSelectionScreen';
import { FarmerProfileScreen } from './components/profile/FarmerProfileScreen';
import { HomeDashboard } from './components/dashboard/HomeDashboard';
import { ScanCropScreen } from './components/scan/ScanCropScreen';
import { ImageQualityCheck } from './components/scan/ImageQualityCheck';
import { AIAnalysisLoading } from './components/scan/AIAnalysisLoading';
import { CropHealthResultScreen } from './components/result/CropHealthResultScreen';
import { DifferentialDiagnosisScreen } from './components/result/DifferentialDiagnosisScreen';
import { SeverityAnalysisScreen } from './components/result/SeverityAnalysisScreen';
import { ExplainableAIScreen } from './components/result/ExplainableAIScreen';
import { DiseaseProgressionPredictionScreen } from './components/result/DiseaseProgressionPredictionScreen';
import { WeatherEnvironmentalScreen } from './components/result/WeatherEnvironmentalScreen';
import { RecommendedActionsScreen } from './components/result/RecommendedActionsScreen';
import { TreatmentDetailsScreen } from './components/result/TreatmentDetailsScreen';
import { CropHealthTimelineScreen } from './components/history/CropHealthTimelineScreen';
import { CropHistoryScreen } from './components/history/CropHistoryScreen';
import { CropHealthMapScreen } from './components/history/CropHealthMapScreen';
import { AlertsWarningsScreen } from './components/alerts/AlertsWarningsScreen';
import { AIAssistantScreen } from './components/assistant/AIAssistantScreen';
import { VoiceAssistantScreen } from './components/assistant/VoiceAssistantScreen';
import { ExpertVerificationScreen } from './components/expert/ExpertVerificationScreen';
import { ReportSummaryScreen } from './components/report/ReportSummaryScreen';
import { SettingsScreen } from './components/settings/SettingsScreen';

export default function App() {
  // Screen state
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('splash');

  // Application data states
  const [farmerProfile, setFarmerProfile] = useState<FarmerProfile>(DEFAULT_FARMER_PROFILE);
  const [weather, setWeather] = useState<WeatherData>(DEFAULT_WEATHER);
  const [activeScenario, setActiveScenario] = useState<ScanRecord>(PRESET_SCENARIOS.default_early_leaf_spot);

  // Temporary scan session state
  const [tempCapturedImage, setTempCapturedImage] = useState<string>(
    PRESET_SCENARIOS.default_early_leaf_spot.imageUrl
  );

  // Flags & Modals
  const [isOffline, setIsOffline] = useState<boolean>(false);
  const [isScenarioModalOpen, setIsScenarioModalOpen] = useState<boolean>(false);
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState<boolean>(false);

  // Navigation Helper
  const handleNavigate = (screen: AppScreen) => {
    setCurrentScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Language Change
  const handleLanguageSelect = (lang: SupportedLanguage) => {
    setFarmerProfile((prev) => ({ ...prev, preferredLanguage: lang }));
  };

  // Scenario Switcher
  const handleSelectScenario = (scenario: ScanRecord) => {
    setActiveScenario(scenario);
    setTempCapturedImage(scenario.imageUrl);
  };

  // Image Captured from Camera/Upload
  const handleImageCaptured = (imageSrc: string, customData?: Partial<ScanRecord>) => {
    setTempCapturedImage(imageSrc);
    if (customData) {
      setActiveScenario((prev) => ({ ...prev, ...customData }));
    }
    setCurrentScreen('quality-check');
  };

  // Screen layout determines whether TopBar & Navigation are rendered
  const isFullScreenMode =
    currentScreen === 'splash' ||
    currentScreen === 'onboarding';

  return (
    <div className="min-h-screen bg-[#F8FAF6] text-[#1E2922] flex flex-col selection:bg-[#2D6A4F] selection:text-white">
      {/* Top Application Bar */}
      {!isFullScreenMode && (
        <TopAppBar
          currentScreen={currentScreen}
          onNavigate={handleNavigate}
          language={farmerProfile.preferredLanguage}
          currentLanguage={farmerProfile.preferredLanguage}
          onOpenLanguage={() => handleNavigate('language-select')}
          farmerName={farmerProfile.name}
          location={farmerProfile.location}
          farmerProfile={farmerProfile}
          isOffline={isOffline}
          onToggleOffline={() => setIsOffline(!isOffline)}
          onOpenVoice={() => setIsVoiceModalOpen(true)}
          onOpenScenarioModal={() => setIsScenarioModalOpen(true)}
          onOpenSettings={() => handleNavigate('settings')}
          onOpenAlerts={() => handleNavigate('alerts')}
          unreadAlertsCount={3}
        />
      )}

      {/* Main Content Layout with Responsive Sidebar */}
      <div className="flex-1 flex w-full">
        {/* Desktop Sidebar (visible on md+ screens) */}
        {!isFullScreenMode && (
          <DesktopSidebar
            currentScreen={currentScreen}
            onNavigate={handleNavigate}
            farmerProfile={farmerProfile}
            unreadAlertsCount={3}
          />
        )}

        {/* Dynamic Screen Viewport */}
        <main className="flex-1 min-w-0 pb-16 md:pb-0">
          {/* 1. Splash Screen */}
          {currentScreen === 'splash' && (
            <SplashScreen
              onComplete={() => handleNavigate('onboarding')}
              onFinish={() => handleNavigate('onboarding')}
            />
          )}

          {/* 2. Onboarding Screen */}
          {currentScreen === 'onboarding' && (
            <OnboardingScreen
              onComplete={() => handleNavigate('dashboard')}
              onSkip={() => handleNavigate('dashboard')}
              currentLanguage={farmerProfile.preferredLanguage}
            />
          )}

          {/* Product Architecture & Story Presentation Screen */}
          {currentScreen === 'landing' && (
            <ProductArchitectureScreen onNavigate={handleNavigate} />
          )}

          {/* 3. Language Selection Screen */}
          {(currentScreen === 'language-select' || currentScreen === 'language') && (
            <LanguageSelectionScreen
              currentLanguage={farmerProfile.preferredLanguage}
              onSelectLanguage={handleLanguageSelect}
              onContinue={() => handleNavigate('dashboard')}
            />
          )}

          {/* 4. Farmer Profile Screen */}
          {(currentScreen === 'farmer-profile' || currentScreen === 'profile') && (
            <FarmerProfileScreen
              profile={farmerProfile}
              onSave={(updated) => setFarmerProfile(updated)}
              onClose={() => handleNavigate('dashboard')}
            />
          )}

          {/* 5. Home Dashboard */}
          {currentScreen === 'dashboard' && (
            <HomeDashboard
              farmerProfile={farmerProfile}
              weather={weather}
              activeScenario={activeScenario}
              onNavigate={handleNavigate}
              onOpenVoice={() => setIsVoiceModalOpen(true)}
              onOpenScenarioModal={() => setIsScenarioModalOpen(true)}
            />
          )}

          {/* 6. Scan Crop Screen */}
          {currentScreen === 'scan' && (
            <ScanCropScreen
              onImageCaptured={handleImageCaptured}
              onBack={() => handleNavigate('dashboard')}
            />
          )}

          {/* 7. Image Quality Check */}
          {currentScreen === 'quality-check' && (
            <ImageQualityCheck
              capturedImage={tempCapturedImage}
              onProceed={() => handleNavigate('loading')}
              onRetake={() => handleNavigate('scan')}
            />
          )}

          {/* 8. AI Analysis Loading Animation */}
          {(currentScreen === 'loading' || currentScreen === 'analysis-loading') && (
            <AIAnalysisLoading
              leafImage={tempCapturedImage}
              onComplete={() => handleNavigate('result')}
            />
          )}

          {/* 9. Main Signature Crop Health Result Screen */}
          {currentScreen === 'result' && (
            <CropHealthResultScreen
              result={activeScenario}
              onNavigate={handleNavigate}
              onScanNew={() => handleNavigate('scan')}
            />
          )}

          {/* 10. Differential Diagnosis Screen */}
          {currentScreen === 'differential' && (
            <DifferentialDiagnosisScreen onNavigate={handleNavigate} />
          )}

          {/* 11. Severity Analysis Screen */}
          {currentScreen === 'severity' && (
            <SeverityAnalysisScreen
              leafImageUrl={activeScenario.imageUrl}
              onNavigate={handleNavigate}
            />
          )}

          {/* 12. Explainable AI Screen */}
          {currentScreen === 'explainable-ai' && (
            <ExplainableAIScreen onNavigate={handleNavigate} />
          )}

          {/* 13. Disease Progression Prediction Screen */}
          {currentScreen === 'progression' && (
            <DiseaseProgressionPredictionScreen onNavigate={handleNavigate} />
          )}

          {/* 14. Weather & Environmental Risk Screen */}
          {currentScreen === 'weather' && (
            <WeatherEnvironmentalScreen
              weather={weather}
              onNavigate={handleNavigate}
            />
          )}

          {/* 15. Recommended Action Engine Screen */}
          {currentScreen === 'actions' && (
            <RecommendedActionsScreen onNavigate={handleNavigate} />
          )}

          {/* 16. Treatment Details Screen */}
          {currentScreen === 'treatment' && (
            <TreatmentDetailsScreen onNavigate={handleNavigate} />
          )}

          {/* 17. Crop Health Timeline Screen */}
          {currentScreen === 'timeline' && (
            <CropHealthTimelineScreen onNavigate={handleNavigate} />
          )}

          {/* 18. Crop History Screen */}
          {currentScreen === 'history' && (
            <CropHistoryScreen
              onNavigate={handleNavigate}
              onSelectRecord={(rec) => setActiveScenario(rec)}
            />
          )}

          {/* 19. Crop Health Spatial Map Screen */}
          {currentScreen === 'field-map' && (
            <CropHealthMapScreen onNavigate={handleNavigate} />
          )}

          {/* 20. Alerts & Early Warnings Screen */}
          {currentScreen === 'alerts' && (
            <AlertsWarningsScreen onNavigate={handleNavigate} />
          )}

          {/* 21. AI Agricultural Assistant Screen */}
          {currentScreen === 'assistant' && (
            <AIAssistantScreen
              onOpenVoice={() => setIsVoiceModalOpen(true)}
              preferredLanguage={farmerProfile.preferredLanguage}
            />
          )}

          {/* 22. Expert Verification Request Screen */}
          {currentScreen === 'expert-verification' && (
            <ExpertVerificationScreen
              currentScan={activeScenario}
              onNavigate={handleNavigate}
            />
          )}

          {/* 23. Report & Summary Screen */}
          {currentScreen === 'report' && (
            <ReportSummaryScreen
              farmer={farmerProfile}
              scan={activeScenario}
              weather={weather}
              onNavigate={handleNavigate}
            />
          )}

          {/* 24. Settings Screen */}
          {currentScreen === 'settings' && (
            <SettingsScreen
              currentLanguage={farmerProfile.preferredLanguage}
              onSelectLanguage={handleLanguageSelect}
              isOffline={isOffline}
              onToggleOffline={() => setIsOffline(!isOffline)}
              onNavigate={handleNavigate}
            />
          )}
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar (hidden on desktop md+) */}
      {!isFullScreenMode && (
        <BottomNavigation
          currentScreen={currentScreen}
          onNavigate={handleNavigate}
          notificationCount={3}
        />
      )}

      {/* Interactive Scenario Switcher Modal (Allows testing any diagnostic state) */}
      <ScenarioModal
        isOpen={isScenarioModalOpen}
        onClose={() => setIsScenarioModalOpen(false)}
        activeScenarioId={activeScenario.id}
        onSelectScenario={handleSelectScenario}
      />

      {/* Voice Assistant Modal Overlay */}
      <VoiceAssistantScreen
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        language={farmerProfile.preferredLanguage}
      />
    </div>
  );
}
